import 'package:flutter/material.dart';

/// کلیدِ ناوبری سراسری؛ برای بازکردنِ صفحه از ویجت‌های بالای Navigator (مثل دکمه‌ی رهگشا).
final GlobalKey<NavigatorState> luxNavKey = GlobalKey<NavigatorState>();
