import 'dart:ui' show PlatformDispatcher;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:dynamic_color/dynamic_color.dart';
import '../data/database.dart';
import 'material_you.dart';
import 'palette.dart';

/// تنظیمات ظاهری برنامه: تم، حالت روشن/تیره، اندازه‌ی متن و انیمیشن ورود.
class AppTheme extends ChangeNotifier {
  AppTheme._();
  static final AppTheme instance = AppTheme._();

  static const List<double> textScales = <double>[0.9, 1.0, 1.12];
  static const List<String> textScaleNames = <String>['کوچک', 'متوسط', 'بزرگ'];

  int themeIndex = 0;
  int mode = 2; // 0 روشن، 1 خودکار (مثل سیستم)، 2 تیره، 3 شب و روز (طبق ساعت)
  int textScaleIndex = 1;
  bool splash = true;
  Brightness _system = Brightness.dark;

  // حالتِ «شب و روز»: از [nightFrom] تا [nightTo] (دقیقه از نیمه‌شب) تیره، بقیه‌ی روز روشن.
  int nightFrom = 18 * 60 + 30;
  int nightTo = 6 * 60;
  Brightness _sched = Brightness.dark;

  // شخصی‌سازیِ تمِ متریال
  int mySource = 0; // 0 از والپیپر، 1 رنگ دلخواه
  int mySeed = 0xFF0B57D0;
  int myVariant = 0;
  int myContrast = 0;
  int myRound = 2;
  int myCard = 0;
  bool myAmoled = false;
  Color? wallpaperSeed;
  bool wallpaperSupported = false;

  Color get mySeedColor => Color(mySeed);
  bool get isMaterial => theme.id == MaterialYou.id;

  double get textScale => textScales[textScaleIndex.clamp(0, textScales.length - 1)];

  Brightness get brightness {
    switch (mode) {
      case 0:
        return Brightness.light;
      case 2:
        return Brightness.dark;
      case 3:
        return _sched;
      default:
        return _system;
    }
  }

  /// آیا لحظه‌ی [t] در بازه‌ی شب است؟
  bool isNightAt(DateTime t) {
    if (nightFrom == nightTo) return false;
    final m = t.hour * 60 + t.minute;
    if (nightFrom < nightTo) return m >= nightFrom && m < nightTo;
    return m >= nightFrom || m < nightTo;
  }

  Brightness get scheduledNow => isNightAt(DateTime.now()) ? Brightness.dark : Brightness.light;

  /// زمانِ نزدیک‌ترین تغییرِ شب/روز (برای زمان‌سنج)؛ اگر حالتِ شب و روز فعال نباشد null.
  DateTime? nextScheduleChange() {
    if (mode != 3 || nightFrom == nightTo) return null;
    final now = DateTime.now();
    DateTime? best;
    for (var d = 0; d <= 1; d++) {
      for (final m in <int>[nightFrom, nightTo]) {
        final t = DateTime(now.year, now.month, now.day + d, m ~/ 60, m % 60);
        if (t.isAfter(now) && (best == null || t.isBefore(best))) best = t;
      }
    }
    return best;
  }

  /// اگر لازم باشد روشن/تیره را طبقِ ساعت عوض می‌کند (کلِ برنامه دوباره ساخته می‌شود).
  bool refreshSchedule() {
    if (mode != 3) return false;
    final want = scheduledNow;
    if (want == _sched) return false;
    _sched = want;
    _apply();
    notifyListeners();
    return true;
  }

  Future<void> setNight({int? from, int? to}) async {
    final db = LuxDb.instance;
    if (from != null) {
      nightFrom = from.clamp(0, 1439);
      await db.kvSet('ui_night_from', nightFrom.toString());
    }
    if (to != null) {
      nightTo = to.clamp(0, 1439);
      await db.kvSet('ui_night_to', nightTo.toString());
    }
    _sched = scheduledNow;
    _apply();
    notifyListeners();
  }

  /// با عوض‌شدنِ این کلید، کلِ برنامه با رنگ‌های تازه ساخته می‌شود.
  String get key =>
      '$themeIndex-${brightness == Brightness.dark ? 'd' : 'l'}-$textScaleIndex'
      '${isMaterial ? '-$mySource-$mySeed-$myVariant-$myContrast-$myRound-$myCard-$myAmoled-${wallpaperSeed?.value ?? 0}' : ''}';

  LuxThemeDef get theme => LuxThemes.all[themeIndex.clamp(0, LuxThemes.all.length - 1)];

  Future<void> load() async {
    final db = LuxDb.instance;
    themeIndex = (int.tryParse(await db.kvGet('ui_theme') ?? '') ?? 0).clamp(0, LuxThemes.all.length - 1);
    mode = (int.tryParse(await db.kvGet('ui_mode') ?? '') ?? 2).clamp(0, 3);
    nightFrom = (int.tryParse(await db.kvGet('ui_night_from') ?? '') ?? (18 * 60 + 30)).clamp(0, 1439);
    nightTo = (int.tryParse(await db.kvGet('ui_night_to') ?? '') ?? (6 * 60)).clamp(0, 1439);
    _sched = scheduledNow;
    textScaleIndex = (int.tryParse(await db.kvGet('ui_text') ?? '') ?? 1).clamp(0, textScales.length - 1);
    splash = (await db.kvGet('ui_splash') ?? '1') == '1';
    mySource = (int.tryParse(await db.kvGet('ui_my_src') ?? '') ?? 0).clamp(0, 1);
    mySeed = int.tryParse(await db.kvGet('ui_my_seed') ?? '') ?? 0xFF0B57D0;
    myVariant = (int.tryParse(await db.kvGet('ui_my_var') ?? '') ?? 0).clamp(0, MaterialYou.variants.length - 1);
    myContrast = (int.tryParse(await db.kvGet('ui_my_con') ?? '') ?? 0).clamp(0, MaterialYou.contrasts.length - 1);
    myRound = (int.tryParse(await db.kvGet('ui_my_round') ?? '') ?? 2).clamp(0, MaterialYou.rounds.length - 1);
    myCard = (int.tryParse(await db.kvGet('ui_my_card') ?? '') ?? 0).clamp(0, 2);
    myAmoled = (await db.kvGet('ui_my_amoled') ?? '0') == '1';
    await _readWallpaper();
    _system = PlatformDispatcher.instance.platformBrightness;
    _apply();
  }

  void _apply() {
    if (isMaterial) {
      LuxColors.current = MaterialYou.build(
        seed: mySource == 0 ? (wallpaperSeed ?? MaterialYou.googleBlue) : mySeedColor,
        brightness: brightness,
        variant: myVariant,
        contrast: myContrast,
        round: myRound,
        card: myCard,
        amoled: myAmoled,
      );
    } else {
      LuxColors.current = theme.of(brightness);
    }
  }

  /// رنگِ والپیپر را (اندروید ۱۲ به بالا) می‌خواند؛ اگر نشد، null می‌ماند.
  Future<bool> _readWallpaper() async {
    final before = wallpaperSeed?.value;
    try {
      final pal = await DynamicColorPlugin.getCorePalette();
      if (pal == null) {
        wallpaperSeed = null;
        wallpaperSupported = false;
      } else {
        wallpaperSeed = Color(pal.primary.get(40));
        wallpaperSupported = true;
      }
    } catch (_) {
      wallpaperSeed = null;
      wallpaperSupported = false;
    }
    return before != wallpaperSeed?.value;
  }

  /// وقتی برنامه به جلو برگشت: اگر والپیپر عوض شده بود، رنگ‌ها را به‌روز می‌کند.
  Future<void> refreshWallpaper() async {
    final changed = await _readWallpaper();
    if (changed && isMaterial && mySource == 0) {
      _apply();
      notifyListeners();
    }
  }

  Future<void> setMy({int? source, Color? seed, int? variant, int? contrast, int? round, int? card, bool? amoled}) async {
    final db = LuxDb.instance;
    if (source != null) {
      mySource = source.clamp(0, 1);
      await db.kvSet('ui_my_src', mySource.toString());
    }
    if (seed != null) {
      mySeed = seed.value;
      await db.kvSet('ui_my_seed', mySeed.toString());
    }
    if (variant != null) {
      myVariant = variant.clamp(0, MaterialYou.variants.length - 1);
      await db.kvSet('ui_my_var', myVariant.toString());
    }
    if (contrast != null) {
      myContrast = contrast.clamp(0, MaterialYou.contrasts.length - 1);
      await db.kvSet('ui_my_con', myContrast.toString());
    }
    if (round != null) {
      myRound = round.clamp(0, MaterialYou.rounds.length - 1);
      await db.kvSet('ui_my_round', myRound.toString());
    }
    if (card != null) {
      myCard = card.clamp(0, 2);
      await db.kvSet('ui_my_card', myCard.toString());
    }
    if (amoled != null) {
      myAmoled = amoled;
      await db.kvSet('ui_my_amoled', amoled ? '1' : '0');
    }
    _apply();
    notifyListeners();
  }

  Future<void> resetMy() async {
    await setMy(source: 0, seed: MaterialYou.googleBlue, variant: 0, contrast: 0, round: 2, card: 0, amoled: false);
  }

  Future<void> setTheme(int i) async {
    themeIndex = i.clamp(0, LuxThemes.all.length - 1);
    await LuxDb.instance.kvSet('ui_theme', themeIndex.toString());
    _apply();
    notifyListeners();
  }

  Future<void> setMode(int m) async {
    mode = m.clamp(0, 3);
    await LuxDb.instance.kvSet('ui_mode', mode.toString());
    if (mode == 3) _sched = scheduledNow;
    _apply();
    notifyListeners();
  }

  Future<void> setTextScale(int i) async {
    textScaleIndex = i.clamp(0, textScales.length - 1);
    await LuxDb.instance.kvSet('ui_text', textScaleIndex.toString());
    notifyListeners();
  }

  Future<void> setSplash(bool v) async {
    splash = v;
    await LuxDb.instance.kvSet('ui_splash', v ? '1' : '0');
    notifyListeners();
  }

  /// وقتی سیستم بین روشن و تیره عوض شد (فقط در حالت «خودکار» اثر دارد)
  void systemChanged(Brightness b) {
    if (_system == b) return;
    _system = b;
    if (mode == 1) {
      _apply();
      notifyListeners();
    }
  }
}
