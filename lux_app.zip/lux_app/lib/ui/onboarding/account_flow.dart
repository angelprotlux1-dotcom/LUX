import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/account.dart';
import '../../core/app_bus.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/backup.dart';
import '../../data/profile_repo.dart';
import '../../services/file_bridge.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';

enum _S { menu, login, forgot, wait, reset, usedBefore, register, privacy }

/// نمایش متنِ حریم خصوصیِ یک‌باره بعد از ورود. فعلاً خاموش است (تصمیمِ جای بهترِ آن بعداً گرفته می‌شود).
/// برای برگرداندن کافی است true شود.
const bool kShowPrivacyNotice = false;

/// ورود به حسابِ آنلاین: ورود، ساخت حساب، ورود با JSON، فراموشی رمز و متنِ حریم خصوصی.
class AccountFlow extends StatefulWidget {
  /// وقتی کاربر قبلاً داده‌ی محلی دارد و فقط باید به حساب وصل شود.
  final bool gateOnly;

  /// حساب وصل شد؛ مراحلِ بعدیِ ثبت‌نام (یا ورود به برنامه) ادامه پیدا کند.
  final VoidCallback onLoggedIn;

  /// همه‌ی داده‌ها برگشت؛ ثبت‌نام لازم نیست. آرگومان: نامِ کاربر برای «خوش برگشتی».
  final void Function(String name) onRestored;

  const AccountFlow({super.key, required this.gateOnly, required this.onLoggedIn, required this.onRestored});

  @override
  State<AccountFlow> createState() => _AccountFlowState();
}

class _AccountFlowState extends State<AccountFlow> {
  _S _s = _S.menu;
  bool _busy = false;
  String? _err;

  final _id = TextEditingController();
  final _pw = TextEditingController();
  final _contact = TextEditingController();
  bool _showPw = false;

  String? _oldJson; // پشتیبانِ قبلیِ کاربر هنگام ساخت حساب
  bool? _idFree;
  Timer? _idTimer;

  int? _rid;
  String? _poll;
  Timer? _pollTimer;
  String _forgotStatus = 'pending';

  VoidCallback? _afterPrivacy;

  @override
  void dispose() {
    _id.dispose();
    _pw.dispose();
    _contact.dispose();
    _idTimer?.cancel();
    _pollTimer?.cancel();
    super.dispose();
  }

  void _go(_S s) {
    setState(() {
      _s = s;
      _err = null;
      _busy = false;
    });
  }

  Future<T?> _run<T>(Future<T> Function() f) async {
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      final r = await f();
      if (mounted) setState(() => _busy = false);
      return r;
    } catch (e) {
      if (mounted) {
        Haptic.heavy();
        setState(() {
          _busy = false;
          _err = e is FormatException ? e.message : e.toString();
        });
      }
      return null;
    }
  }

  // ───── قواعدِ رمز ─────
  int _count(RegExp r) => r.allMatches(_pw.text).length;
  bool get _hasUpper => _count(RegExp(r'[A-Z]')) >= 1;
  bool get _hasDigits => _count(RegExp(r'\d')) >= 2;
  bool get _hasLower => _count(RegExp(r'[a-z]')) >= 4;
  bool get _pwOk => _hasUpper && _hasDigits && _hasLower && _pw.text.length <= 64;
  bool get _idOk => RegExp(r'^[A-Za-z0-9_]{4,20}$').hasMatch(_id.text.trim());

  void _onIdChanged() {
    _idFree = null;
    _idTimer?.cancel();
    if (!_idOk) {
      setState(() {});
      return;
    }
    _idTimer = Timer(const Duration(milliseconds: 600), () async {
      try {
        final ok = await Account.idAvailable(_id.text.trim());
        if (mounted) setState(() => _idFree = ok);
      } catch (_) {}
    });
    setState(() {});
  }

  // ───── بعد از موفقیتِ حساب ─────
  Future<void> _afterAccount({required VoidCallback proceed}) async {
    if (kShowPrivacyNotice && await Account.needsConsent()) {
      _afterPrivacy = proceed;
      _go(_S.privacy);
    } else {
      proceed();
    }
  }

  Future<void> _afterLoginNormal() async {
    // نصبِ تازه و حسابِ قدیمی: اگر پشتیبانی روی سرور هست برگردان
    if (!widget.gateOnly) {
      final snap = await Account.pullSnapshot();
      if (snap != null) {
        try {
          await Backup.importJson(snap);
          await ProfileRepo.markOnboarded();
          AppBus.bump();
          await _afterAccount(proceed: () => widget.onRestored(Account.id ?? ''));
          return;
        } catch (_) {}
      }
    }
    await _afterAccount(proceed: widget.onLoggedIn);
  }

  // ───── کارها ─────
  Future<void> _doLogin() async {
    final ok = await _run(() async {
      await Account.login(_id.text.trim(), _pw.text);
      return true;
    });
    if (ok == true) await _afterLoginNormal();
  }

  Future<void> _doRegister() async {
    final ok = await _run(() async {
      await Account.register(_id.text.trim(), _pw.text);
      return true;
    });
    if (ok != true) return;
    if (_oldJson != null) {
      try {
        await Backup.importJson(_oldJson!);
        await ProfileRepo.markOnboarded();
        AppBus.bump();
      } catch (_) {}
      unawaited(Account.pushSnapshot());
      await _afterAccount(proceed: () => widget.onRestored(Account.id ?? ''));
    } else {
      if (widget.gateOnly) unawaited(Account.pushSnapshot());
      await _afterAccount(proceed: widget.onLoggedIn);
    }
  }

  Future<String?> _pickJsonText() async {
    final path = await FileBridge.pick();
    if (path == null) return null;
    return File(path).readAsString();
  }

  Future<void> _doJsonLogin() async {
    final r = await _run<bool>(() async {
      final text = await _pickJsonText();
      if (text == null) return false;
      Map<String, dynamic> m;
      try {
        m = jsonDecode(text) as Map<String, dynamic>;
        if (m['app'] != 'LUX') throw const FormatException();
      } catch (_) {
        throw const FormatException('این فایل پشتیبانِ LUX نیست.');
      }
      final link = m['lux_link'] as String?;
      final found = link != null && await Account.jsonLogin(link);
      if (!found) {
        throw 'این فایل به حسابِ آنلاینی وصل نیست. «ساخت حساب جدید» را بزن و بگو قبلاً از لوکس استفاده کرده‌ای.';
      }
      await Backup.importJson(text);
      await ProfileRepo.markOnboarded();
      AppBus.bump();
      return true;
    });
    if (r == true) await _afterAccount(proceed: () => widget.onRestored(Account.id ?? ''));
  }

  Future<void> _doForgot() async {
    final r = await _run(() => Account.forgot(_id.text.trim(), _contact.text.trim()));
    if (r == null) return;
    _rid = r['request_id'] as int?;
    _poll = r['poll_key'] as String?;
    _forgotStatus = 'pending';
    _go(_S.wait);
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      try {
        final st = await Account.forgotStatus(_rid!, _poll!);
        if (!mounted) return;
        if (st != _forgotStatus) setState(() => _forgotStatus = st);
        if (st == 'approved' || st == 'denied') {
          _pollTimer?.cancel();
          if (st == 'approved') {
            _pw.clear();
            _go(_S.reset);
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _doReset() async {
    final ok = await _run(() async {
      await Account.reset(_rid!, _poll!, _pw.text);
      return true;
    });
    if (ok == true) await _afterLoginNormal();
  }

  Future<void> _doConsent() async {
    await Account.acceptConsent();
    final f = _afterPrivacy;
    if (f != null) f();
  }

  // ───── رابط ─────
  Widget _heading(String t, {String? sub}) => Column(
        children: [
          Text(t, style: LuxText.title.copyWith(fontSize: 24), textAlign: TextAlign.center),
          if (sub != null) ...[
            const SizedBox(height: 8),
            Text(sub, style: LuxText.caption.copyWith(fontSize: 13), textAlign: TextAlign.center),
          ],
          const SizedBox(height: 22),
        ],
      );

  Widget _errText() => _err == null
      ? const SizedBox.shrink()
      : Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(_err!, style: LuxText.caption.copyWith(color: LuxColors.danger), textAlign: TextAlign.center),
        );

  Widget _field(TextEditingController c, String hint, {bool pw = false, VoidCallback? onChanged, TextInputType? type}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          obscureText: pw && !_showPw,
          keyboardType: type,
          textDirection: TextDirection.ltr,
          textAlign: TextAlign.center,
          autocorrect: false,
          enableSuggestions: false,
          style: LuxText.body,
          decoration: LuxInput.decoration(hint).copyWith(
            suffixIcon: pw
                ? IconButton(
                    icon: Icon(_showPw ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: LuxColors.textDim, size: 20),
                    onPressed: () => setState(() => _showPw = !_showPw),
                  )
                : null,
          ),
          onChanged: (_) {
            onChanged?.call();
            setState(() {});
          },
        ),
      );

  Widget _rule(String t, bool ok) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Icon(ok ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, size: 16, color: ok ? LuxColors.accent : LuxColors.textDim),
            const SizedBox(width: 8),
            Text(t, style: LuxText.caption.copyWith(color: ok ? LuxColors.text : LuxColors.textDim)),
          ],
        ),
      );

  Widget _menu() => Column(
        children: [
          _heading('ورود به لوکس', sub: 'یکی از سه راه را انتخاب کن'),
          LuxButton(label: 'ورود به حساب', onPressed: () => _go(_S.login)),
          const SizedBox(height: 12),
          LuxButton(label: 'ساخت حساب جدید', filled: false, onPressed: () => _go(widget.gateOnly ? _S.register : _S.usedBefore)),
          const SizedBox(height: 12),
          if (!widget.gateOnly) LuxButton(label: 'ورود با فایل JSON', filled: false, onPressed: _busy ? null : _doJsonLogin),
          _errText(),
          if (_busy) const Padding(padding: EdgeInsets.only(top: 16), child: CircularProgressIndicator()),
        ],
      );

  Widget _login() => Column(
        children: [
          _heading('ورود به حساب'),
          _field(_id, 'آیدی'),
          _field(_pw, 'رمز', pw: true),
          _errText(),
          const SizedBox(height: 14),
          LuxButton(label: _busy ? 'کمی صبر کن…' : 'ورود', onPressed: (_busy || _id.text.trim().isEmpty || _pw.text.isEmpty) ? null : _doLogin),
          const SizedBox(height: 8),
          TextButton(onPressed: () => _go(_S.forgot), child: Text('رمز یا آیدی‌ام را فراموش کرده‌ام', style: LuxText.caption.copyWith(color: LuxColors.accent))),
          TextButton(onPressed: () => _go(_S.menu), child: Text('بازگشت', style: LuxText.caption)),
        ],
      );

  Widget _forgot() => Column(
        children: [
          _heading('فراموشی رمز', sub: 'درخواستت برای سازنده می‌رود و بعد از تأییدش می‌توانی رمز تازه بگذاری'),
          _field(_id, 'آیدی (اگر آیدی را هم فراموش کرده‌ای، اسمت را بنویس)'),
          _field(_contact, 'راه تماس (مثلاً آیدی تلگرام)'),
          _errText(),
          const SizedBox(height: 14),
          LuxButton(label: _busy ? 'کمی صبر کن…' : 'ارسال درخواست', onPressed: (_busy || _id.text.trim().isEmpty) ? null : _doForgot),
          TextButton(onPressed: () => _go(_S.login), child: Text('بازگشت', style: LuxText.caption)),
        ],
      );

  Widget _wait() => Column(
        children: [
          _heading(_forgotStatus == 'denied' ? 'درخواست رد شد' : 'منتظر تأیید',
              sub: _forgotStatus == 'denied' ? 'با سازنده صحبت کن.' : 'درخواستت فرستاده شد. همین صفحه را باز نگه دار؛ به‌محض تأیید ادامه می‌دهیم.'),
          if (_forgotStatus != 'denied') const CircularProgressIndicator(),
          const SizedBox(height: 18),
          TextButton(
            onPressed: () {
              _pollTimer?.cancel();
              _go(_S.menu);
            },
            child: Text('بازگشت', style: LuxText.caption),
          ),
        ],
      );

  Widget _reset() => Column(
        children: [
          _heading('رمز تازه', sub: 'تأیید شد. یک رمز تازه بگذار.'),
          _field(_pw, 'رمز تازه', pw: true),
          _rules(),
          _errText(),
          const SizedBox(height: 14),
          LuxButton(label: _busy ? 'کمی صبر کن…' : 'ثبت رمز', onPressed: (_busy || !_pwOk) ? null : _doReset),
        ],
      );

  Widget _rules() => Align(
        alignment: Alignment.centerRight,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rule('حداقل ۱ حرف بزرگ انگلیسی', _hasUpper),
            _rule('حداقل ۲ عدد', _hasDigits),
            _rule('حداقل ۴ حرف کوچک انگلیسی', _hasLower),
          ],
        ),
      );

  Widget _usedBefore() => Column(
        children: [
          _heading('قبلاً از لوکس استفاده کرده‌ای؟', sub: 'اگر فایل پشتیبان داری، همه‌چیزت به حساب جدید می‌پیوندد'),
          LuxButton(
            label: 'بله، قبلاً استفاده کرده‌ام',
            onPressed: _busy
                ? null
                : () async {
                    final t = await _run<String?>(() async {
                      final text = await _pickJsonText();
                      if (text == null) return null;
                      final m = jsonDecode(text);
                      if (m is! Map || m['app'] != 'LUX') throw const FormatException('این فایل پشتیبانِ LUX نیست.');
                      return text;
                    });
                    if (t != null) {
                      _oldJson = t;
                      _go(_S.register);
                    }
                  },
          ),
          const SizedBox(height: 12),
          LuxButton(
            label: 'نه، تازه‌وارد هستم',
            filled: false,
            onPressed: () {
              _oldJson = null;
              _go(_S.register);
            },
          ),
          _errText(),
          TextButton(onPressed: () => _go(_S.menu), child: Text('بازگشت', style: LuxText.caption)),
        ],
      );

  Widget _register() {
    final idHint = !_idOk
        ? '۴ تا ۲۰ حرف انگلیسی، عدد یا _'
        : (_idFree == null ? 'در حال بررسی…' : (_idFree! ? 'این آیدی آزاد است' : 'این آیدی قبلاً گرفته شده'));
    return Column(
      children: [
        _heading('ساخت حساب', sub: _oldJson != null ? 'پشتیبانِ قبلی‌ات آماده‌ی پیوستن است' : null),
        _field(_id, 'آیدی', onChanged: _onIdChanged),
        Align(
          alignment: Alignment.centerRight,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(idHint, style: LuxText.caption.copyWith(color: _idFree == false ? LuxColors.danger : (_idFree == true ? LuxColors.accent : LuxColors.textDim))),
          ),
        ),
        _field(_pw, 'رمز', pw: true),
        _rules(),
        _errText(),
        const SizedBox(height: 14),
        LuxButton(label: _busy ? 'کمی صبر کن…' : 'ساخت حساب', onPressed: (_busy || !_idOk || _idFree == false || !_pwOk) ? null : _doRegister),
        TextButton(onPressed: () => _go(widget.gateOnly ? _S.menu : _S.usedBefore), child: Text('بازگشت', style: LuxText.caption)),
      ],
    );
  }

  Widget _privacy() => Column(
        children: [
          _heading('قبل از شروع'),
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'لوکس برای اینکه اطلاعاتت گم نشود، روی گوشی‌های مختلف برگردد و رهگشا بتواند کمکت کند، این چیزها را روی سرور نگه می‌دارد:',
                  style: LuxText.body.copyWith(height: 1.9),
                ),
                const SizedBox(height: 10),
                for (final t in const [
                  'همه‌ی چیزهایی که در لوکس ثبت می‌کنی: پروفایل، درس‌ها، نمره‌ها، برنامه‌ها، رقبا (همان محتوای فایل JSON).',
                  'پیام‌هایت با رهگشا.',
                  'اینکه چه قابلیت‌هایی را چقدر و کِی استفاده می‌کنی، و آخرین ورودت (همراه با آی‌پی).',
                  'رهگشا برای جواب دادن، بخشی از اطلاعات و پیام‌هایت را برای گوگل (Gemini) می‌فرستد.',
                  'سازنده‌ی برنامه (آقای کریمی) می‌تواند همه‌ی این اطلاعات را ببیند.',
                ])
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(padding: const EdgeInsets.only(top: 9, left: 8), child: Icon(Icons.circle, size: 6, color: LuxColors.accent)),
                        Expanded(child: Text(t, style: LuxText.body.copyWith(height: 1.8))),
                      ],
                    ),
                  ),
                const SizedBox(height: 4),
                Text('این توضیح فقط یک‌بار نشان داده می‌شود.', style: LuxText.caption),
              ],
            ),
          ),
          const SizedBox(height: 18),
          LuxButton(label: 'ادامه', onPressed: _doConsent),
          const SizedBox(height: 4),
          TextButton(
            onPressed: () => SystemNavigator.pop(),
            child: Text('خروج', style: LuxText.caption),
          ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    switch (_s) {
      case _S.menu:
        return _menu();
      case _S.login:
        return _login();
      case _S.forgot:
        return _forgot();
      case _S.wait:
        return _wait();
      case _S.reset:
        return _reset();
      case _S.usedBefore:
        return _usedBefore();
      case _S.register:
        return _register();
      case _S.privacy:
        return _privacy();
    }
  }
}
