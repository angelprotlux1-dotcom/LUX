import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';

/// امضای پایین پروفایل: لوگوی پیشوا + «By Pishva System»
class PishvaCredit extends StatefulWidget {
  final String? versionLine;
  const PishvaCredit({super.key, this.versionLine});

  @override
  State<PishvaCredit> createState() => _PishvaCreditState();
}

class _PishvaCreditState extends State<PishvaCredit> with SingleTickerProviderStateMixin {
  // یک چرخه‌ی ۴ ثانیه‌ای: درخششِ عبوری روی متن، نفس‌کشیدنِ نورِ لوگو، موجِ خط بالا
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  String? get versionLine => widget.versionLine;

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(child: AnimatedBuilder(animation: _c, builder: (context, _) => _body(context)));
  }

  Widget _body(BuildContext context) {
    final t = _c.value;
    final breathe = 0.5 + 0.5 * math.sin(t * 2 * math.pi); // ۰..۱
    final sweep = -0.4 + 1.8 * t; // موقعیتِ درخشش روی متن
    return Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 8),
      child: Column(
        children: [
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 48),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  LuxColors.alpha(LuxColors.accent, 0.0),
                  LuxColors.alpha(LuxColors.accent, 0.35 + 0.4 * breathe),
                  LuxColors.alpha(LuxColors.accent, 0.0),
                ],
              ),
            ),
          ),
          const SizedBox(height: 26),
          // لوگوی پیشوا سفید/نقره‌ای است؛ روی پس‌زمینه‌ی روشن روی یک تخته‌ی تیره می‌نشیند.
          Transform.translate(
            offset: Offset(0, -3 * breathe),
            child: Container(
            padding: LuxColors.isDark ? EdgeInsets.zero : const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: LuxColors.isDark ? null : const Color(0xFF0C1117),
              borderRadius: BorderRadius.circular(LuxColors.r(28)),
              boxShadow: [
                BoxShadow(color: LuxColors.alpha(LuxColors.accent, 0.10 + 0.22 * breathe), blurRadius: 26 + 16 * breathe, spreadRadius: 1),
              ],
            ),
            child: Image.asset(
              'assets/logo/pishva_logo.png',
              width: 150,
              height: 150,
              cacheWidth: 450,
              filterQuality: FilterQuality.high,
            ),
          ),
          ),
          const SizedBox(height: 12),
          Directionality(
            textDirection: TextDirection.ltr,
            child: ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (r) => LinearGradient(
                colors: [LuxColors.silver, LuxColors.accent, Colors.white, LuxColors.accent, LuxColors.silver],
                stops: [
                  0.0,
                  (sweep - 0.25).clamp(0.0, 1.0),
                  sweep.clamp(0.0, 1.0),
                  (sweep + 0.25).clamp(0.0, 1.0),
                  1.0,
                ],
              ).createShader(r),
              child: Text(
                'By Pishva System',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: LuxText.fontCredit,
                  fontFamilyFallback: <String>['monospace'],
                  fontSize: 17,
                  letterSpacing: 3.2,
                  color: Colors.white,
                  height: 1.2,
                ),
              ),
            ),
          ),
          if (widget.versionLine != null) ...[
            const SizedBox(height: 10),
            Text(widget.versionLine!, style: LuxText.caption.copyWith(color: LuxColors.silverDim)),
          ],
        ],
      ),
    );
  }
}
