import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../services/rival_watch.dart';
import '../pages/command_room_page.dart';
import '../pages/war_room_page.dart';
import 'lux_card.dart';
import 'lux_kit.dart';

/// کارتِ «اتاق فرمان» بالای صفحه‌ی امروز: رتبه، مأموریت و مهم‌ترین هشدارها.
class CommandCard extends StatefulWidget {
  const CommandCard({super.key});

  @override
  State<CommandCard> createState() => _CommandCardState();
}

class _CommandCardState extends State<CommandCard> {
  @override
  void initState() {
    super.initState();
    RivalWatch.init();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<WatchState?>(
      valueListenable: RivalWatch.state,
      builder: (context, s, _) {
        if (s == null) return const SizedBox.shrink();
        final open = () => pushPage<void>(context, const WarRoomPage());
        if (!s.rivalryOn || s.rivalCount == 0) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: LuxCard(
              onTap: open,
              child: Row(children: [
                Icon(Icons.rocket_launch_rounded, color: LuxColors.accent, size: 30),
                const SizedBox(width: 14),
                Expanded(child: Text('اتاق فرمانِ اول‌شدن را روشن کن', style: LuxText.body.copyWith(fontWeight: FontWeight.w700))),
                Icon(Icons.chevron_left_rounded, color: LuxColors.textDim),
              ]),
            ),
          );
        }
        final top = s.alerts.take(2).toList();
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: LuxCard(
            onTap: open,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.rocket_launch_rounded, color: LuxColors.accent, size: 20),
                  const SizedBox(width: 8),
                  Text('اتاق فرمان', style: LuxText.caption.copyWith(color: LuxColors.accent, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  if (s.rank > 0) Text('رتبه ${faDigits(s.rank)}${s.total > 0 ? ' از ${faDigits(s.total)}' : ''}', style: LuxText.body.copyWith(fontWeight: FontWeight.w800)),
                  if (s.rankDelta != 0) Padding(padding: const EdgeInsets.only(right: 6), child: Text(s.rankDelta > 0 ? '▲' : '▼', style: TextStyle(color: s.rankDelta > 0 ? LuxColors.accent : LuxColors.danger))),
                ]),
                if (s.mission != null) ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Icon(s.missionDone ? Icons.check_circle_rounded : Icons.flag_rounded, size: 18, color: s.missionDone ? LuxColors.accent : LuxColors.text),
                    const SizedBox(width: 8),
                    Expanded(child: Text(s.missionDone ? 'مأموریتِ امروز انجام شد' : s.mission!.title, style: LuxText.body.copyWith(fontWeight: FontWeight.w700))),
                  ]),
                ],
                for (final a in top) AlertTile(a),
                const SizedBox(height: 2),
                Text(top.isEmpty && s.mission == null ? 'برای دیدنِ تحلیل، لمس کن' : 'همه‌ی هشدارها و جزئیات ←', style: LuxText.caption.copyWith(color: LuxColors.textDim)),
              ],
            ),
          ),
        );
      },
    );
  }
}
