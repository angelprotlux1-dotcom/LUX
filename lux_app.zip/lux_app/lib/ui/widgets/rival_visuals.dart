import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/jalali_utils.dart';
import '../../core/util.dart';

/// رنگِ نمره (۰ تا ۲۰): قرمز ← زرد ← سبز
Color scoreColor(double v) {
  final t = ((v - 8) / 12).clamp(0.0, 1.0).toDouble();
  if (t < 0.5) return Color.lerp(LuxColors.danger, LuxColors.warn, t * 2)!;
  return Color.lerp(LuxColors.warn, LuxColors.ok, (t - 0.5) * 2)!;
}

Color _on(Color bg) => ThemeData.estimateBrightnessForColor(bg) == Brightness.dark ? Colors.white : const Color(0xFF111111);

/// نشانِ روند: ▲ صعود، ▼ افت، ► ثابت
class TrendBadge extends StatelessWidget {
  final String state; // rise | fall | flat | unknown
  final double? delta;
  const TrendBadge({super.key, required this.state, this.delta});

  @override
  Widget build(BuildContext context) {
    IconData icon;
    Color c;
    switch (state) {
      case 'rise':
        icon = Icons.trending_up_rounded;
        c = LuxColors.ok;
        break;
      case 'fall':
        icon = Icons.trending_down_rounded;
        c = LuxColors.danger;
        break;
      case 'flat':
        icon = Icons.trending_flat_rounded;
        c = LuxColors.silverDim;
        break;
      default:
        icon = Icons.remove_rounded;
        c = LuxColors.textDim;
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 18, color: c),
        if (delta != null) ...[
          const SizedBox(width: 3),
          Text(
            delta! >= 0 ? '+${fmtNum(delta!, dec: 1)}' : fmtNum(delta!, dec: 1),
            style: LuxText.caption.copyWith(color: c, fontWeight: FontWeight.w700),
          ),
        ],
      ],
    );
  }
}

class HeatPerson {
  final String name;
  final Color color;
  final bool isMe;
  final List<double?> values;
  const HeatPerson(this.name, this.color, this.isMe, this.values);
}

/// نقشه‌ی حرارتیِ میانگینِ هر نفر در هر درس
class RivalHeatmap extends StatelessWidget {
  final List<String> columns;
  final List<HeatPerson> rows;
  const RivalHeatmap({super.key, required this.columns, required this.rows});

  static const double _nameW = 84;
  static const double _cellW = 58;
  static const double _cellH = 44;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const SizedBox(width: _nameW),
              for (final c in columns)
                SizedBox(
                  width: _cellW,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Text(c, style: LuxText.caption, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis),
                  ),
                ),
            ],
          ),
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                children: [
                  SizedBox(
                    width: _nameW,
                    child: Row(
                      children: [
                        Container(width: 8, height: 8, decoration: BoxDecoration(color: r.color, shape: BoxShape.circle)),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            r.name,
                            style: LuxText.label.copyWith(fontWeight: r.isMe ? FontWeight.w800 : FontWeight.w600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                  for (final v in r.values)
                    Container(
                      width: _cellW - 4,
                      height: _cellH,
                      margin: const EdgeInsets.only(right: 2, left: 2),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: v == null ? LuxColors.cardHi : LuxColors.alpha(scoreColor(v), 0.9),
                        borderRadius: BorderRadius.circular(LuxColors.r(12)),
                        border: r.isMe ? Border.all(color: LuxColors.accent, width: 1.6) : null,
                      ),
                      child: Text(
                        v == null ? '—' : fmtNum(v, dec: 1),
                        style: LuxText.label.copyWith(
                          color: v == null ? LuxColors.textDim : _on(scoreColor(v)),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class RadarSeries {
  final String name;
  final Color color;
  final List<double?> values;
  const RadarSeries(this.name, this.color, this.values);
}

/// نمودارِ راداری: هر محور یک درس (۰ تا ۲۰)
class RivalRadar extends StatelessWidget {
  final List<String> labels;
  final List<RadarSeries> series;
  final double height;
  const RivalRadar({super.key, required this.labels, required this.series, this.height = 300});

  @override
  Widget build(BuildContext context) {
    if (labels.length < 3) {
      return SizedBox(
        height: 80,
        child: Center(child: Text('برای رادار حداقل سه درس لازم است.', style: LuxText.caption)),
      );
    }
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _RadarPainter(
          labels,
          series,
          LuxColors.alpha(LuxColors.stroke, 0.7),
          LuxColors.textDim,
        ),
      ),
    );
  }
}

class _RadarPainter extends CustomPainter {
  final List<String> labels;
  final List<RadarSeries> series;
  final Color grid;
  final Color text;
  _RadarPainter(this.labels, this.series, this.grid, this.text);

  @override
  void paint(Canvas canvas, Size size) {
    final n = labels.length;
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2 - 42;
    if (r <= 10) return;
    Offset pt(int i, double v) {
      final a = -math.pi / 2 + 2 * math.pi * i / n;
      final k = (v / 20).clamp(0.0, 1.0) * r;
      return Offset(c.dx + k * math.cos(a), c.dy + k * math.sin(a));
    }

    final gp = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = grid;
    for (final ring in <double>[5, 10, 15, 20]) {
      final path = Path();
      for (var i = 0; i < n; i++) {
        final p = pt(i, ring);
        if (i == 0) {
          path.moveTo(p.dx, p.dy);
        } else {
          path.lineTo(p.dx, p.dy);
        }
      }
      path.close();
      canvas.drawPath(path, gp);
    }
    for (var i = 0; i < n; i++) {
      canvas.drawLine(c, pt(i, 20), gp);
      final a = -math.pi / 2 + 2 * math.pi * i / n;
      final lp = Offset(c.dx + (r + 22) * math.cos(a), c.dy + (r + 18) * math.sin(a));
      final label = labels[i].length > 10 ? '${labels[i].substring(0, 10)}…' : labels[i];
      final tp = TextPainter(
        text: TextSpan(text: label, style: TextStyle(fontSize: 11, color: text, fontFamily: LuxText.fontText)),
        textDirection: TextDirection.rtl,
        maxLines: 1,
      )..layout();
      tp.paint(canvas, Offset(lp.dx - tp.width / 2, lp.dy - tp.height / 2));
    }
    for (final s in series) {
      final path = Path();
      for (var i = 0; i < n; i++) {
        final p = pt(i, i < s.values.length ? (s.values[i] ?? 0) : 0);
        if (i == 0) {
          path.moveTo(p.dx, p.dy);
        } else {
          path.lineTo(p.dx, p.dy);
        }
      }
      path.close();
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.fill
          ..color = LuxColors.alpha(s.color, 0.16),
      );
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.2
          ..strokeJoin = StrokeJoin.round
          ..color = s.color,
      );
      for (var i = 0; i < n; i++) {
        final v = i < s.values.length ? s.values[i] : null;
        if (v == null) continue;
        canvas.drawCircle(pt(i, v), 3.2, Paint()..color = s.color);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RadarPainter old) => true;
}

class MomentumItem {
  final String name;
  final Color color;
  final double? delta;
  final bool isMe;
  const MomentumItem(this.name, this.color, this.delta, this.isMe);
}

/// میله‌های شتاب: چپِ صفر = افت، راستِ صفر = صعود (اخیر − قدیمی)
class MomentumBars extends StatelessWidget {
  final List<MomentumItem> items;
  const MomentumBars({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    var maxAbs = 1.0;
    for (final i in items) {
      if (i.delta != null && i.delta!.abs() > maxAbs) maxAbs = i.delta!.abs();
    }
    return Column(
      children: [
        for (final it in items)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              children: [
                SizedBox(
                  width: 78,
                  child: Text(
                    it.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: LuxText.label.copyWith(fontWeight: it.isMe ? FontWeight.w800 : FontWeight.w600),
                  ),
                ),
                Expanded(
                  child: Directionality(
                    textDirection: TextDirection.ltr,
                    child: SizedBox(
                      height: 22,
                      child: LayoutBuilder(builder: (context, cons) {
                        final half = cons.maxWidth / 2;
                        final d = it.delta;
                        final len = d == null ? 0.0 : (d.abs() / maxAbs) * (half - 4);
                        return Stack(
                          children: [
                            Positioned(left: half - 0.5, top: 0, bottom: 0, child: Container(width: 1, color: LuxColors.stroke)),
                            if (d != null)
                              Positioned(
                                left: d >= 0 ? half : half - len,
                                top: 3,
                                bottom: 3,
                                width: len < 3 ? 3.0 : len,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: d >= 0 ? LuxColors.ok : LuxColors.danger,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                ),
                              ),
                          ],
                        );
                      }),
                    ),
                  ),
                ),
                SizedBox(
                  width: 46,
                  child: Text(
                    it.delta == null ? '—' : (it.delta! >= 0 ? '+${fmtNum(it.delta!, dec: 1)}' : fmtNum(it.delta!, dec: 1)),
                    textAlign: TextAlign.end,
                    style: LuxText.caption.copyWith(
                      color: it.delta == null ? LuxColors.textDim : (it.delta! >= 0 ? LuxColors.ok : LuxColors.danger),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

/// مسیرِ رتبه‌ی من در طولِ امتحان‌ها (رتبه‌ی ۱ بالاست)
class RankLine extends StatelessWidget {
  final List<int?> ranks;
  final List<int> totals;
  final double height;
  const RankLine({super.key, required this.ranks, required this.totals, this.height = 150});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _RankPainter(ranks, totals, LuxColors.accent, LuxColors.alpha(LuxColors.stroke, 0.7), LuxColors.textDim),
      ),
    );
  }
}

class _RankPainter extends CustomPainter {
  final List<int?> ranks;
  final List<int> totals;
  final Color line;
  final Color grid;
  final Color text;
  _RankPainter(this.ranks, this.totals, this.line, this.grid, this.text);

  @override
  void paint(Canvas canvas, Size size) {
    if (ranks.isEmpty) return;
    var maxRank = 2;
    for (final t in totals) {
      if (t > maxRank) maxRank = t;
    }
    const padL = 26.0, padR = 14.0, padT = 14.0, padB = 12.0;
    final w = size.width - padL - padR;
    final h = size.height - padT - padB;
    double yOf(int rank) => padT + (maxRank == 1 ? 0 : (rank - 1) / (maxRank - 1)) * h;
    final gp = Paint()
      ..color = grid
      ..strokeWidth = 1;
    for (var r = 1; r <= maxRank; r++) {
      final y = yOf(r);
      canvas.drawLine(Offset(padL, y), Offset(size.width - padR, y), gp);
      final tp = TextPainter(
        text: TextSpan(text: faDigits(r), style: TextStyle(fontSize: 10.5, color: text, fontFamily: LuxText.fontText)),
        textDirection: TextDirection.rtl,
      )..layout();
      tp.paint(canvas, Offset(2, y - tp.height / 2));
    }
    final n = ranks.length;
    // زمان از راست به چپ (مثل بقیه‌ی نمودارها)
    double xOf(int i) => n == 1 ? padL + w / 2 : size.width - padR - (i / (n - 1)) * w;
    final path = Path();
    var started = false;
    for (var i = 0; i < n; i++) {
      final r = ranks[i];
      if (r == null) continue;
      final p = Offset(xOf(i), yOf(r));
      if (!started) {
        path.moveTo(p.dx, p.dy);
        started = true;
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeJoin = StrokeJoin.round
        ..strokeCap = StrokeCap.round
        ..color = line,
    );
    for (var i = 0; i < n; i++) {
      final r = ranks[i];
      if (r == null) continue;
      final p = Offset(xOf(i), yOf(r));
      canvas.drawCircle(p, 5, Paint()..color = r == 1 ? LuxColors.ok : line);
      canvas.drawCircle(p, 2.2, Paint()..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(covariant _RankPainter old) => true;
}
