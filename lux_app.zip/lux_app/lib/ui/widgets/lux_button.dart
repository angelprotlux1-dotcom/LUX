import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

class LuxButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool filled;
  final IconData? icon;
  final bool expand;
  final bool compact;

  const LuxButton({
    super.key,
    required this.label,
    this.onPressed,
    this.filled = true,
    this.icon,
    this.expand = true,
    this.compact = false,
  });

  @override
  State<LuxButton> createState() => _LuxButtonState();
}

class _LuxButtonState extends State<LuxButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null;
    final glow = enabled && widget.filled && !LuxColors.hardShadow;
    final bg = !enabled
        ? LuxColors.cardHi
        : (widget.filled ? LuxColors.accent : LuxColors.alpha(LuxColors.accent, 0.12));
    final fg = !enabled
        ? LuxColors.textDim
        : (widget.filled ? LuxColors.onAccent : LuxColors.accent);
    final labelStyle = widget.compact
        ? LuxText.label.copyWith(color: fg, fontWeight: FontWeight.w700)
        : LuxText.heading.copyWith(color: fg);
    final child = FittedBox(
      fit: BoxFit.scaleDown,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (widget.icon != null) ...[Icon(widget.icon, size: 20, color: fg), const SizedBox(width: 8)],
          Text(widget.label, style: labelStyle, textAlign: TextAlign.center),
        ],
      ),
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => setState(() => _down = true) : null,
      onTapCancel: enabled ? () => setState(() => _down = false) : null,
      onTapUp: enabled ? (_) => setState(() => _down = false) : null,
      onTap: enabled
          ? () {
              Haptic.light();
              widget.onPressed!();
            }
          : null,
      child: AnimatedScale(
        scale: _down ? 0.96 : 1,
        duration: _down ? const Duration(milliseconds: 90) : const Duration(milliseconds: 320),
        curve: _down ? Curves.easeOut : Curves.easeOutBack,
        child: Container(
          height: widget.compact ? 44 : 56,
          padding: EdgeInsets.symmetric(horizontal: widget.compact ? 8 : 26),
          decoration: BoxDecoration(
            color: bg,
            gradient: glow
                ? LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color.lerp(LuxColors.accent, Colors.white, 0.14)!, LuxColors.accent],
                  )
                : null,
            borderRadius: BorderRadius.circular(LuxColors.r(28)),
            border: LuxColors.hardShadow
                ? Border.all(color: LuxColors.stroke, width: LuxColors.strokeW)
                : (enabled && !widget.filled ? Border.all(color: LuxColors.alpha(LuxColors.accent, 0.35), width: 1) : null),
            boxShadow: !enabled
                ? const <BoxShadow>[]
                : (LuxColors.hardShadow
                    ? LuxColors.shadow(d: 2.5)
                    : (widget.filled
                        ? [BoxShadow(color: LuxColors.alpha(LuxColors.accent, _down ? 0.2 : 0.38), blurRadius: _down ? 10 : 22, offset: Offset(0, _down ? 3 : 9))]
                        : const <BoxShadow>[])),
          ),
          alignment: Alignment.center,
          child: child,
        ),
      ),
    );
  }
}
