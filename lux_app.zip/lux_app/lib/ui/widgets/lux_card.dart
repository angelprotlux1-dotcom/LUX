import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

/// کارتِ گردِ پایه با افکت فشار (بدون بلور و سایه‌ی سنگین — سبک و روان).
class LuxCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;
  final double radius;
  final Border? border;

  const LuxCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.onTap,
    this.color,
    this.radius = 28,
    this.border,
  });

  @override
  State<LuxCard> createState() => _LuxCardState();
}

class _LuxCardState extends State<LuxCard> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final dark = LuxColors.isDark;
    final base = widget.color ?? LuxColors.card;
    final glass = widget.color == null && !LuxColors.hardShadow;
    final box = Container(
      padding: widget.padding,
      decoration: BoxDecoration(
        color: base,
        // سطحِ شیشه‌ای: روشن‌تر در بالا، رنگِ اصلی در پایین
        gradient: glass
            ? LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color.lerp(base, dark ? Colors.white : LuxColors.accent, dark ? 0.05 : 0.025)!, base],
              )
            : null,
        borderRadius: BorderRadius.circular(LuxColors.r(widget.radius)),
        border: widget.border ??
            (LuxColors.hardShadow
                ? Border.all(color: LuxColors.strokeColor, width: LuxColors.strokeW)
                : Border.all(color: dark ? const Color(0x14FFFFFF) : LuxColors.alpha(LuxColors.stroke, 0.55), width: 1)),
        boxShadow: LuxColors.hardShadow
            ? LuxColors.shadow()
            : (dark
                ? const <BoxShadow>[BoxShadow(color: Color(0x40000000), blurRadius: 26, offset: Offset(0, 12))]
                : const <BoxShadow>[BoxShadow(color: Color(0x120F1720), blurRadius: 26, offset: Offset(0, 10))]),
      ),
      child: widget.child,
    );
    if (widget.onTap == null) return box;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: () {
        Haptic.tap();
        widget.onTap!();
      },
      child: AnimatedScale(
        scale: _down ? 0.965 : 1.0,
        duration: _down ? const Duration(milliseconds: 90) : const Duration(milliseconds: 320),
        curve: _down ? Curves.easeOut : Curves.easeOutBack,
        child: box,
      ),
    );
  }
}
