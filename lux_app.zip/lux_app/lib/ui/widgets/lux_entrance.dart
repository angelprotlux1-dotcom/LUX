import 'dart:async';
import 'package:flutter/material.dart';

/// ورودِ نرم و پله‌پله‌ی هر ردیف: محو شدن + بالا آمدنِ کوتاه. فقط یک‌بار برای هر ردیف پخش می‌شود.
class LuxEntrance extends StatefulWidget {
  final Widget child;
  final int index;
  const LuxEntrance({super.key, required this.child, this.index = 0});

  @override
  State<LuxEntrance> createState() => _LuxEntranceState();
}

class _LuxEntranceState extends State<LuxEntrance> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 560));
  late final Animation<double> _a = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
  Timer? _t;

  @override
  void initState() {
    super.initState();
    final i = widget.index.clamp(0, 9).toInt();
    _t = Timer(Duration(milliseconds: 40 * i), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _a,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.07), end: Offset.zero).animate(_a),
        child: widget.child,
      ),
    );
  }
}
