import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';

double _iv(double t, double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

/// «خوش برگشتی» با حلقه‌های بازشونده و ذرات؛ بعد از بازیابی از JSON یا حساب.
class WelcomeBack extends StatefulWidget {
  final String name;
  final VoidCallback onDone;
  const WelcomeBack({super.key, required this.name, required this.onDone});

  @override
  State<WelcomeBack> createState() => _WelcomeBackState();
}

class _WelcomeBackState extends State<WelcomeBack> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 3600));

  @override
  void initState() {
    super.initState();
    _c.forward().whenComplete(() {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AbsorbPointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          final inT = Curves.easeOutCubic.transform(_iv(t, 0, 0.18));
          final out = Curves.easeIn.transform(_iv(t, 0.82, 1));
          final logoP = Curves.easeOutBack.transform(_iv(t, 0.1, 0.4));
          final textP = Curves.easeOutCubic.transform(_iv(t, 0.32, 0.6));
          return Opacity(
            opacity: (inT * (1 - out)).clamp(0.0, 1.0),
            child: Container(
              color: LuxColors.bg,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned.fill(child: CustomPaint(painter: _RingsPainter(t))),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Transform.scale(
                        scale: 0.5 + 0.5 * logoP,
                        child: Opacity(opacity: logoP.clamp(0.0, 1.0), child: Image.asset('assets/logo/lux_logo.png', width: 130, height: 130, cacheWidth: 400)),
                      ),
                      const SizedBox(height: 28),
                      Opacity(
                        opacity: textP,
                        child: Transform.translate(
                          offset: Offset(0, 16 * (1 - textP)),
                          child: Text('خوش برگشتی', style: LuxText.title.copyWith(fontSize: 32), textAlign: TextAlign.center),
                        ),
                      ),
                      if (widget.name.isNotEmpty)
                        Opacity(
                          opacity: Curves.easeOut.transform(_iv(t, 0.45, 0.7)),
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Directionality(textDirection: TextDirection.ltr, child: Text(widget.name, style: LuxText.body.copyWith(color: LuxColors.accent, fontSize: 18))),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _RingsPainter extends CustomPainter {
  final double t;
  _RingsPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final maxR = math.sqrt(size.width * size.width + size.height * size.height) / 2;
    for (var i = 0; i < 3; i++) {
      final p = _iv(t, 0.12 + i * 0.09, 0.7 + i * 0.09);
      if (p <= 0) continue;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0
        ..color = LuxColors.accent.withOpacity((1 - p) * 0.35);
      canvas.drawCircle(c, maxR * Curves.easeOutCubic.transform(p) * 0.9, paint);
    }
    final rnd = math.Random(7);
    for (var i = 0; i < 22; i++) {
      final ang = rnd.nextDouble() * math.pi * 2;
      final speed = 0.35 + rnd.nextDouble() * 0.6;
      final p = _iv(t, 0.25, 0.85);
      if (p <= 0) continue;
      final r = maxR * 0.9 * speed * Curves.easeOutCubic.transform(p);
      final pos = c + Offset(math.cos(ang), math.sin(ang)) * r;
      final paint = Paint()..color = LuxColors.accent.withOpacity((1 - p) * 0.8);
      canvas.drawCircle(pos, 2.5 + rnd.nextDouble() * 2.5, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _RingsPainter old) => old.t != t;
}
