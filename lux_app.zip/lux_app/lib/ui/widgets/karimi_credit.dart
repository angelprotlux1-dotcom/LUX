import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';

double _iv(double t, double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

/// متنِ لاتین که حرف‌به‌حرف از پایین بالا می‌آید و بعد برقِ نقره‌ای از رویش رد می‌شود.
class _LetterReveal extends StatelessWidget {
  final String text;
  final double t; // ۰..۱ پیشرفتِ ورود
  final double shine; // موقعیت برق (-0.4..1.4)
  final double size;
  final double spacing;
  const _LetterReveal({required this.text, required this.t, required this.shine, required this.size, required this.spacing});

  @override
  Widget build(BuildContext context) {
    final n = text.length;
    final letters = <Widget>[];
    for (var i = 0; i < n; i++) {
      final a = (i / n) * 0.6;
      final p = Curves.easeOutCubic.transform(_iv(t, a, a + 0.4));
      letters.add(Opacity(
        opacity: p,
        child: Transform.translate(
          offset: Offset(0, (1 - p) * 10),
          child: Text(text[i], style: TextStyle(fontFamily: LuxText.fontCredit, fontFamilyFallback: const <String>['monospace'], fontSize: size, letterSpacing: spacing, color: Colors.white, height: 1.2)),
        ),
      ));
    }
    return Directionality(
      textDirection: TextDirection.ltr,
      child: ShaderMask(
        blendMode: BlendMode.srcIn,
        shaderCallback: (r) => LinearGradient(
          colors: [LuxColors.silver, LuxColors.accent, Colors.white, LuxColors.accent, LuxColors.silver],
          stops: [0.0, (shine - 0.25).clamp(0.0, 1.0), shine.clamp(0.0, 1.0), (shine + 0.25).clamp(0.0, 1.0), 1.0],
        ).createShader(r),
        child: Row(mainAxisSize: MainAxisSize.min, children: letters),
      ),
    );
  }
}

/// نوشته‌ی بالای مرحله‌ی ورود: «By Mr Karimi» و زیرش «Pishva System».
class KarimiHeader extends StatefulWidget {
  const KarimiHeader({super.key});

  @override
  State<KarimiHeader> createState() => _KarimiHeaderState();
}

class _KarimiHeaderState extends State<KarimiHeader> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 6000))..repeat();
  late final DateTime _t0 = DateTime.now();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) {
            final enter = _iv(DateTime.now().difference(_t0).inMilliseconds / 1800.0, 0, 1);
            final shine = -0.4 + 1.8 * _c.value;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _LetterReveal(text: 'By Mr Karimi', t: enter, shine: shine, size: 13, spacing: 3.0),
                const SizedBox(height: 5),
                Opacity(
                  opacity: Curves.easeOut.transform(_iv(enter, 0.4, 1.0)),
                  child: _LetterReveal(text: 'PISHVA SYSTEM', t: _iv(enter, 0.3, 1.0), shine: (shine + 0.2) % 1.8, size: 9.5, spacing: 4.2),
                ),
                const SizedBox(height: 8),
                Container(
                  height: 1,
                  width: 90 * Curves.easeOutCubic.transform(_iv(enter, 0.2, 1.0)),
                  decoration: BoxDecoration(gradient: LinearGradient(colors: [LuxColors.alpha(LuxColors.accent, 0), LuxColors.alpha(LuxColors.accent, 0.7), LuxColors.alpha(LuxColors.accent, 0)])),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// صحنه‌ی پایانیِ ورود: نوشته + لوگوها روی کل صفحه، بعد با یک دایره‌ی بازشونده ناپدید می‌شود
/// و LUX پشتش دیده می‌شود.
class CreditFinale extends StatefulWidget {
  final VoidCallback onDone;
  const CreditFinale({super.key, required this.onDone});

  @override
  State<CreditFinale> createState() => _CreditFinaleState();
}

class _CreditFinaleState extends State<CreditFinale> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 4600));

  @override
  void initState() {
    super.initState();
    _c.forward().whenComplete(() {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AbsorbPointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          final size = MediaQuery.of(context).size;
          final diag = math.sqrt(size.width * size.width + size.height * size.height);
          final inT = Curves.easeOutCubic.transform(_iv(t, 0.0, 0.22));
          final logoP = Curves.easeOutBack.transform(_iv(t, 0.08, 0.38));
          final textT = _iv(t, 0.28, 0.62);
          final shine = -0.4 + 1.8 * _iv(t, 0.34, 0.78);
          final out = Curves.easeInCubic.transform(_iv(t, 0.78, 1.0));
          final breathe = 0.5 + 0.5 * math.sin(t * math.pi * 6);
          return ClipPath(
            clipper: _HoleClipper(out * diag * 0.62),
            child: Container(
              color: LuxColors.bg,
              alignment: Alignment.center,
              child: Opacity(
                opacity: (inT * (1 - out * 0.9)).clamp(0.0, 1.0),
                child: Transform.scale(
                  scale: 1.0 + 0.45 * out,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 230,
                        height: 230,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 230,
                              height: 230,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(colors: [
                                  LuxColors.alpha(LuxColors.accent, 0.20 + 0.18 * breathe),
                                  LuxColors.alpha(LuxColors.accent, 0.0),
                                ]),
                              ),
                            ),
                            Transform.scale(
                              scale: 0.6 + 0.4 * logoP,
                              child: Opacity(
                                opacity: logoP.clamp(0.0, 1.0),
                                child: Image.asset('assets/logo/lux_logo.png', width: 150, height: 150, cacheWidth: 450),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 26),
                      _LetterReveal(text: 'By Mr Karimi', t: textT, shine: shine, size: 19, spacing: 4.0),
                      const SizedBox(height: 22),
                      Opacity(
                        opacity: Curves.easeOut.transform(_iv(t, 0.40, 0.62)),
                        child: Transform.translate(
                          offset: Offset(0, 8 * (1 - _iv(t, 0.40, 0.62))),
                          child: Container(
                            padding: LuxColors.isDark ? EdgeInsets.zero : const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: LuxColors.isDark ? null : const Color(0xFF0C1117),
                              borderRadius: BorderRadius.circular(LuxColors.r(24)),
                            ),
                            child: Image.asset('assets/logo/pishva_logo.png', width: 96, height: 96, cacheWidth: 300),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      _LetterReveal(text: 'PISHVA SYSTEM', t: _iv(t, 0.45, 0.72), shine: shine, size: 12, spacing: 5.0),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// تمامِ صفحه را می‌پوشاند به جز یک دایره‌ی سوراخ در وسط (برای دیده‌شدنِ پشتش).
class _HoleClipper extends CustomClipper<Path> {
  final double r;
  _HoleClipper(this.r);

  @override
  Path getClip(Size size) {
    final p = Path()..fillType = PathFillType.evenOdd;
    p.addRect(Offset.zero & size);
    if (r > 0) p.addOval(Rect.fromCircle(center: size.center(Offset.zero), radius: r));
    return p;
  }

  @override
  bool shouldReclip(covariant _HoleClipper old) => old.r != r;
}
