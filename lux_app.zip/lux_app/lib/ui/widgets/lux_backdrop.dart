import 'package:flutter/material.dart';
import '../../core/palette.dart';

/// پس‌زمینه‌ی زنده‌ی ملایم: دو هاله‌ی نورِ رنگی در گوشه‌ها (سبک و بدونِ بلور).
class LuxBackdrop extends StatelessWidget {
  const LuxBackdrop({super.key});

  Widget _glow(Color c, double d, double a) => Container(
        width: d,
        height: d,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [LuxColors.alpha(c, a), LuxColors.alpha(c, 0)]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (LuxColors.hardShadow) return const SizedBox.shrink();
    final dark = LuxColors.isDark;
    return IgnorePointer(
      child: RepaintBoundary(
        child: Stack(
          children: [
            Positioned(top: -150, right: -100, child: _glow(LuxColors.accent, 380, dark ? 0.20 : 0.13)),
            Positioned(bottom: -190, left: -140, child: _glow(LuxColors.accentDim, 420, dark ? 0.14 : 0.08)),
          ],
        ),
      ),
    );
  }
}
