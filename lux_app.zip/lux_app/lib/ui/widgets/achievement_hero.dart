import 'package:flutter/material.dart';
import '../../core/achievements.dart';
import '../../core/nav.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../pages/achievements_page.dart';
import 'lux_card.dart';

/// کارتِ رتبه و امتیاز بالای پروفایل؛ با لمس، کارنامه‌ی افتخارات باز می‌شود.
class AchievementHero extends StatefulWidget {
  const AchievementHero({super.key});

  @override
  State<AchievementHero> createState() => _AchievementHeroState();
}

class _AchievementHeroState extends State<AchievementHero> {
  @override
  void initState() {
    super.initState();
    Achievements.evaluate();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AchSummary?>(
      valueListenable: Achievements.summary,
      builder: (context, s, _) {
        final tiers = s == null ? 0 : s.items.fold<int>(0, (a, b) => a + b.tier);
        return LuxCard(
          onTap: () => luxNavKey.currentState?.push(MaterialPageRoute<void>(builder: (_) => const AchievementsPage())),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [LuxColors.accent, LuxColors.accentDim])),
                child: Icon(Icons.military_tech_rounded, color: LuxColors.onAccent, size: 34),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s == null ? 'کارنامه‌ی افتخارات' : 'رتبه‌ی ${kRankNames[s.rank]}', style: LuxText.title.copyWith(fontSize: 18)),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(value: s?.rankProgress ?? 0, minHeight: 8, backgroundColor: LuxColors.stroke, color: LuxColors.accent),
                    ),
                    const SizedBox(height: 6),
                    Text(s == null ? 'در حال محاسبه…' : '${s.xp} امتیاز · $tiers نشان', style: LuxText.caption),
                  ],
                ),
              ),
              Icon(Icons.chevron_left_rounded, color: LuxColors.textDim),
            ],
          ),
        );
      },
    );
  }
}
