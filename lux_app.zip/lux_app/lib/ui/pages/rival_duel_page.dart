import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/rivalry_repo.dart';
import '../../engine/rivalry.dart';
import '../charts/chart_base.dart';
import '../charts/compare.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_hub.dart';
import '../widgets/lux_kit.dart';

String _sd(DateTime d) {
  final j = Jalali.fromDateTime(d);
  return '${faDigits(j.day)} ${jalaliMonths[j.month - 1]}';
}

class _CourseGap {
  final String name;
  final double mine;
  final double his;
  const _CourseGap(this.name, this.mine, this.his);
  double get diff => mine - his;
}

/// مقایسه‌ی تک‌به‌تکِ من و یک رقیب: سطحِ کلی، درس‌به‌درس، نقاط قوت و ضعفِ هر دو، نمودار و سابقه‌ی امتحان‌ها.
class RivalDuelPage extends StatefulWidget {
  final int rivalId;
  final String rivalName;
  final Color rivalColor;
  final List<RivalExam> raw; // قبل از اعمالِ سیاستِ نمره‌ی ثبت‌نشده
  final Map<int, double> coef;
  final Map<int, Map<int, double>> behavior;
  final String defaultPolicy;

  const RivalDuelPage({
    super.key,
    required this.rivalId,
    required this.rivalName,
    required this.rivalColor,
    required this.raw,
    required this.coef,
    required this.behavior,
    required this.defaultPolicy,
  });

  @override
  State<RivalDuelPage> createState() => _RivalDuelPageState();
}

class _RivalDuelPageState extends State<RivalDuelPage> {
  /// null = از پیش‌فرضِ رقابت پیروی کن
  String? _override;
  bool _ready = false;

  static const List<String> _keys = <String>['skip', 'avg', 'zero'];

  @override
  void initState() {
    super.initState();
    RivalryRepo.rivalOverride(widget.rivalId).then((v) {
      if (mounted) {
        setState(() {
          _override = v;
          _ready = true;
        });
      }
    });
  }

  String get _policy => _override ?? widget.defaultPolicy;

  Future<void> _setPolicy(int seg) async {
    // سگمنت: ۰ = پیش‌فرض، ۱..۳ = نادیده/میانگین/صفر
    final v = seg == 0 ? null : _keys[seg - 1];
    setState(() => _override = v);
    await RivalryRepo.setRivalOverride(widget.rivalId, v);
    AppBus.bump();
  }

  Widget _heading(String t, [String? sub]) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(t, style: LuxText.heading),
            if (sub != null) ...[const SizedBox(height: 2), Text(sub, style: LuxText.caption)],
          ],
        ),
      );

  Widget _bigNumber(String who, double? v, Color c) {
    return Expanded(
      child: Column(
        children: [
          Text(who, style: LuxText.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 6),
          Text(v == null ? '—' : fmtNum(v, dec: 2), style: LuxText.dot(34, color: c)),
        ],
      ),
    );
  }

  Widget _bar(double? v, Color c) {
    return Row(
      children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: v == null ? 0 : (v / 20).clamp(0.0, 1.0).toDouble(),
              minHeight: 8,
              color: c,
              backgroundColor: LuxColors.cardHi,
            ),
          ),
        ),
        SizedBox(width: 46, child: Text(v == null ? '—' : fmtNum(v, dec: 2), textAlign: TextAlign.end, style: LuxText.caption)),
      ],
    );
  }

  Widget _courseRow(_CourseGap g) {
    final lead = g.diff;
    final tag = lead.abs() < 0.005 ? 'مساوی' : (lead > 0 ? '+${fmtNum(lead, dec: 2)}' : fmtNum(lead, dec: 2));
    final tagColor = lead.abs() < 0.005 ? LuxColors.textDim : (lead > 0 ? LuxColors.ok : LuxColors.danger);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: Text(g.name, style: LuxText.label)),
              Text(tag, style: LuxText.label.copyWith(color: tagColor)),
            ],
          ),
          const SizedBox(height: 6),
          _bar(g.mine, LuxColors.accent),
          const SizedBox(height: 4),
          _bar(g.his, widget.rivalColor),
        ],
      ),
    );
  }

  Widget _strengthLine(String label, List<_CourseGap> list, {required bool mineSide}) {
    if (list.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Text(label, style: LuxText.caption),
          for (final g in list.take(4))
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
              decoration: BoxDecoration(
                color: LuxColors.alpha(mineSide ? LuxColors.ok : LuxColors.danger, 0.14),
                borderRadius: BorderRadius.circular(LuxColors.r(14)),
              ),
              child: Text('${g.name}  ${fmtNum(g.diff.abs(), dec: 1)}', style: LuxText.caption.copyWith(color: LuxColors.text)),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final rid = widget.rivalId;
    const me = RivalryCalc.me;
    final exams = RivalryCalc.fillMissing(widget.raw, <int, String>{rid: _policy});
    final steps = [for (final e in exams) if (!e.isConference) e];

    final myAll = RivalryCalc.overall(exams, me, widget.coef, behavior: widget.behavior);
    final hisAll = RivalryCalc.overall(exams, rid, widget.coef, behavior: widget.behavior);

    // درس‌ها
    final names = <int, String>{};
    for (final e in exams) {
      names.putIfAbsent(e.courseId, () => e.courseName);
    }
    final both = <_CourseGap>[];
    final hisOnly = <MapEntry<String, double>>[];
    names.forEach((cid, n) {
      final a = RivalryCalc.courseAverage(exams, cid, me, behavior: widget.behavior);
      final b = RivalryCalc.courseAverage(exams, cid, rid, behavior: widget.behavior);
      if (a != null && b != null) both.add(_CourseGap(n, a, b));
      if (b != null) hisOnly.add(MapEntry(n, b));
    });
    final myLead = [for (final g in both) if (g.diff > 0.005) g]..sort((a, b) => b.diff.compareTo(a.diff));
    final hisLead = [for (final g in both) if (g.diff < -0.005) g]..sort((a, b) => a.diff.compareTo(b.diff));
    hisOnly.sort((a, b) => b.value.compareTo(a.value));

    // سابقه‌ی امتحان‌ها
    var win = 0, tie = 0, lose = 0;
    final history = <RivalExam>[];
    for (final e in steps) {
      final a = e.norm(me), b = e.norm(rid);
      if (a == null || b == null) continue;
      history.add(e);
      if ((a - b).abs() < 0.005) {
        tie++;
      } else if (a > b) {
        win++;
      } else {
        lose++;
      }
    }

    final ahead = myAll != null && hisAll != null ? myAll - hisAll : null;

    final children = <Widget>[
      // ── خلاصه ──
      LuxCard(
        radius: 28,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                _bigNumber('من', myAll, LuxColors.accent),
                Column(
                  children: [
                    Text('در برابر', style: LuxText.caption),
                    const SizedBox(height: 8),
                    Icon(Icons.swap_horiz_rounded, color: LuxColors.silverDim),
                  ],
                ),
                _bigNumber(widget.rivalName, hisAll, widget.rivalColor),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              ahead == null
                  ? 'برای مقایسه، نمره‌ی هر دو نفر لازم است.'
                  : (ahead.abs() < 0.005
                      ? 'سطحِ کلی‌تان یکی است.'
                      : (ahead > 0
                          ? '${fmtNum(ahead, dec: 2)} نمره جلویی.'
                          : '${fmtNum(-ahead, dec: 2)} نمره عقب‌تری.')),
              textAlign: TextAlign.center,
              style: LuxText.label.copyWith(color: ahead == null ? LuxColors.textDim : (ahead >= 0 ? LuxColors.ok : LuxColors.danger)),
            ),
          ],
        ),
      ),
      const SizedBox(height: 14),

      // ── نمره‌ی ثبت‌نشده ──
      LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _heading('اگر نمره‌ی ${widget.rivalName} ثبت نشده بود',
                _override == null ? 'همان پیش‌فرضِ رقابت اعمال می‌شود.' : 'فقط برای همین رقیب، جدا از پیش‌فرض.'),
            LuxSegmented(
              names: const ['پیش‌فرض', 'نادیده', 'میانگین خودش', 'صفر'],
              index: !_ready || _override == null ? 0 : _keys.indexOf(_override!) + 1,
              onChanged: _setPolicy,
            ),
            const SizedBox(height: 8),
            Text(
              _policy == 'skip'
                  ? 'امتحان‌های بدون نمره‌ی او حساب نمی‌شود.'
                  : (_policy == 'avg' ? 'به‌جای نمره‌ی خالی، میانگینِ خودش در همان درس می‌نشیند.' : 'نمره‌ی خالی صفر حساب می‌شود.'),
              style: LuxText.caption,
            ),
          ],
        ),
      ),
      const SizedBox(height: 14),
    ];

    if (both.isEmpty && steps.isEmpty) {
      children.add(LuxCard(
        child: LuxEmpty(
          icon: Icons.compare_arrows_rounded,
          title: 'هنوز چیزی برای مقایسه نیست',
          hint: 'نمره‌ی چند امتحانِ ${widget.rivalName} را ثبت کن (یا نمره‌های گذشته‌اش را از صفحه‌ی رقابت وارد کن).',
        ),
      ));
    } else {
      // ── نمودارِ سطح کلی ──
      if (steps.isNotEmpty) {
        final series = <GapSeries>[
          GapSeries('من', RivalryCalc.overallSeries(exams, me, widget.coef, behavior: widget.behavior), LuxColors.accent, primary: true),
          GapSeries(widget.rivalName, RivalryCalc.overallSeries(exams, rid, widget.coef, behavior: widget.behavior), widget.rivalColor),
        ];
        children.add(LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _heading('روندِ سطحِ کلی', 'بعد از هر امتحان، از ۲۰'),
              PolylineChart(
                labels: [for (final e in steps) e.courseName],
                details: [for (final e in steps) '${e.title} — ${_sd(e.at)}'],
                series: series,
              ),
              const SizedBox(height: 12),
              ChartLegend(
                labels: [for (final s in series) s.name],
                colors: [for (final s in series) s.color],
                trailing: [for (final s in series) s.values.isEmpty || s.values.last == null ? '—' : fmtNum(s.values.last!, dec: 2)],
              ),
            ],
          ),
        ));
        children.add(const SizedBox(height: 14));
      }

      // ── سابقه‌ی امتحان‌ها ──
      if (history.isNotEmpty) {
        final total = win + tie + lose;
        children.add(LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _heading('سابقه‌ی امتحان‌های مشترک', '${faDigits(total)} امتحان که هر دو نمره داریم'),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  height: 14,
                  child: Row(
                    children: [
                      if (win > 0) Expanded(flex: win, child: Container(color: LuxColors.ok)),
                      if (tie > 0) Expanded(flex: tie, child: Container(color: LuxColors.silverDim)),
                      if (lose > 0) Expanded(flex: lose, child: Container(color: LuxColors.danger)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text('برد ${faDigits(win)}', style: LuxText.label.copyWith(color: LuxColors.ok)),
                  Text('مساوی ${faDigits(tie)}', style: LuxText.label.copyWith(color: LuxColors.textDim)),
                  Text('باخت ${faDigits(lose)}', style: LuxText.label.copyWith(color: LuxColors.danger)),
                ],
              ),
              const SizedBox(height: 12),
              for (final e in history.reversed.take(8))
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: Row(
                    children: [
                      Expanded(child: Text(e.title, style: LuxText.body, maxLines: 1, overflow: TextOverflow.ellipsis)),
                      Text('${fmtNum(e.norm(me)!, dec: 1)} : ${fmtNum(e.norm(rid)!, dec: 1)}', style: LuxText.label),
                    ],
                  ),
                ),
            ],
          ),
        ));
        children.add(const SizedBox(height: 14));
      }

      // ── درس‌به‌درس ──
      if (both.isNotEmpty) {
        children.add(LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _heading('درس‌به‌درس', 'میله‌ی بالا من، میله‌ی پایین ${widget.rivalName}؛ عدد = اختلافِ من با او'),
              for (final g in both) _courseRow(g),
            ],
          ),
        ));
        children.add(const SizedBox(height: 14));

        // ── نقاط قوت و ضعف ──
        children.add(LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _heading('نقاط قوت و ضعف'),
              Text('تو', style: LuxText.label.copyWith(color: LuxColors.accent)),
              _strengthLine('جلوتری در', myLead, mineSide: true),
              _strengthLine('عقب‌تری در', hisLead, mineSide: false),
              if (myLead.isEmpty && hisLead.isEmpty) Text('درسِ مشترکِ قابلِ مقایسه نیست.', style: LuxText.caption),
              const SizedBox(height: 14),
              Text(widget.rivalName, style: LuxText.label.copyWith(color: widget.rivalColor)),
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text('قوی در', style: LuxText.caption),
                    for (final e in hisOnly.take(3))
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                        decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.ok, 0.14), borderRadius: BorderRadius.circular(LuxColors.r(14))),
                        child: Text('${e.key}  ${fmtNum(e.value, dec: 1)}', style: LuxText.caption.copyWith(color: LuxColors.text)),
                      ),
                  ],
                ),
              ),
              if (hisOnly.length > 3)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Text('ضعیف در', style: LuxText.caption),
                      for (final e in hisOnly.reversed.take(3))
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                          decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.danger, 0.14), borderRadius: BorderRadius.circular(LuxColors.r(14))),
                          child: Text('${e.key}  ${fmtNum(e.value, dec: 1)}', style: LuxText.caption.copyWith(color: LuxColors.text)),
                        ),
                    ],
                  ),
                ),
            ],
          ),
        ));
      }
    }

    return LuxSubPage(title: 'من در برابر ${widget.rivalName}', children: children);
  }
}
