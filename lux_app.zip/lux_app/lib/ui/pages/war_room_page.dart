import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';

import '../../core/features.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../engine/rival_intel.dart';
import '../../engine/rivalry.dart';
import '../../engine/war_room.dart';
import '../../services/rival_watch.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_backdrop.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_entrance.dart';
import '../widgets/lux_kit.dart';
import 'command_room_page.dart';
import 'rivalry_page.dart';

const List<String> _months = <String>['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

String _n(double v, [int dec = 1]) => faDigits(v.toStringAsFixed(dec));
String _pct(double v) => '${faDigits((v * 100).round())}٪';
String _dateLabel(DateTime d) {
  final j = Jalali.fromDateTime(d);
  return '${faDigits(j.day)} ${_months[j.month - 1]}';
}

double _c01(double v) => v < 0 ? 0 : (v > 1 ? 1 : v);

Color _colorOf(WrPerson p) => p.isMe ? LuxColors.accent : LuxColors.seriesAt(p.colorIdx);

TextPainter _tp(String s, double size, Color c, {FontWeight w = FontWeight.w500, double? maxW, TextAlign align = TextAlign.center}) {
  final t = TextPainter(
    text: TextSpan(text: s, style: TextStyle(fontFamily: LuxText.fontText, fontFamilyFallback: LuxText.fontFallback, fontSize: size, color: c, fontWeight: w, height: 1.2)),
    textDirection: TextDirection.rtl,
    textAlign: align,
    maxLines: 2,
    ellipsis: '…',
  );
  t.layout(maxWidth: maxW ?? double.infinity);
  return t;
}

void _dash(Canvas c, Path p, Paint paint, {double on = 7, double off = 5}) {
  for (final m in p.computeMetrics()) {
    var d = 0.0;
    while (d < m.length) {
      final e = math.min(d + on, m.length);
      c.drawPath(m.extractPath(d, e), paint);
      d += on + off;
    }
  }
}

// ───────────────────────── صفحه ─────────────────────────

class WarRoomPage extends StatefulWidget {
  const WarRoomPage({super.key});

  @override
  State<WarRoomPage> createState() => _WarRoomPageState();
}

class _WarRoomPageState extends State<WarRoomPage> {
  WrResult? _r;
  IntelReport? _rep;
  int _h = 4;
  double? _meMu;
  double? _rivalMu;
  int? _duelId;
  final Set<int> _shown = <int>{};
  bool _inited = false;

  @override
  void initState() {
    super.initState();
    RivalWatch.state.addListener(_recompute);
    RivalWatch.refresh();
    _recompute();
  }

  @override
  void dispose() {
    RivalWatch.state.removeListener(_recompute);
    super.dispose();
  }

  void _recompute() {
    final rep = RivalWatch.state.value?.report;
    if (rep == null) {
      if (mounted) setState(() {
        _rep = null;
        _r = null;
      });
      return;
    }
    final r = WarRoom.build(rep, horizon: _h, meMu: _meMu, rivalMu: _rivalMu, rivalOverrideId: rep.mainRivalId);
    if (!_inited && r != null) {
      _inited = true;
      _shown.add(RivalryCalc.me);
      if (r.mainRivalId != null) _shown.add(r.mainRivalId!);
      if (r.threatId != null) _shown.add(r.threatId!);
      final top = r.people.where((p) => !p.isMe).toList()..sort((a, b) => b.avg.compareTo(a.avg));
      for (final p in top) {
        if (_shown.length >= 4) break;
        _shown.add(p.id);
      }
      _duelId = r.mainRivalId ?? (top.isEmpty ? null : top.first.id);
    }
    if (mounted) setState(() {
      _rep = rep;
      _r = r;
    });
  }

  // ───── قطعه‌های رابط ─────
  Widget _panel(String title, String? sub, Widget child, {Widget? trailing}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: LuxCard(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text(title, style: LuxText.title.copyWith(fontSize: 17))),
              if (trailing != null) trailing,
            ]),
            if (sub != null) Padding(padding: const EdgeInsets.only(top: 3), child: Text(sub, style: LuxText.caption.copyWith(height: 1.6))),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }

  Widget _tile(String label, String value, Color c, {String? foot}) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          decoration: BoxDecoration(color: LuxColors.alpha(c, 0.10), borderRadius: BorderRadius.circular(LuxColors.r(20)), border: Border.all(color: LuxColors.alpha(c, 0.28))),
          child: Column(children: [
            Text(label, style: LuxText.caption, textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(value, style: LuxText.title.copyWith(fontSize: 24, color: c)),
            if (foot != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(foot, style: LuxText.caption.copyWith(fontSize: 10.5), textAlign: TextAlign.center)),
          ]),
        ),
      );

  Widget _hBar(String label, double v01, String valueText, Color c, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(label, style: LuxText.body.copyWith(fontWeight: bold ? FontWeight.w800 : FontWeight.w500))),
            const SizedBox(width: 8),
            Text(valueText, style: LuxText.body.copyWith(color: c, fontWeight: FontWeight.w800)),
          ]),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              height: 10,
              child: Stack(children: [
                Container(color: LuxColors.alpha(LuxColors.stroke, 0.5)),
                FractionallySizedBox(alignment: AlignmentDirectional.centerStart, widthFactor: _c01(v01), child: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [LuxColors.alpha(c, 0.7), c])))),
              ]),
            ),
          ),
        ]),
      );

  // ───── بخش‌ها ─────
  Widget _header(WrResult r) {
    final total = r.people.length;
    final dropC = r.pDrop > 0.5 ? LuxColors.danger : (r.pDrop > 0.25 ? LuxColors.warn : LuxColors.ok);
    return Column(children: [
      Row(children: [
        _tile('رتبه‌ی الان', '${faDigits(r.rankNow)}/${faDigits(total)}', LuxColors.accent),
        const SizedBox(width: 10),
        _tile('احتمال اول‌شدن', _pct(r.pFirst), r.pFirst >= 0.5 ? LuxColors.ok : LuxColors.accent, foot: 'تا ${faDigits(r.horizon)} امتحانِ بعد'),
        const SizedBox(width: 10),
        _tile('خطرِ افت رتبه', _pct(r.pDrop), dropC),
      ]),
      if (r.lowData)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Text('داده هنوز کم است (کمتر از ۴ امتحان)؛ پیش‌بینی‌ها کم‌اطمینان‌ترند.', style: LuxText.caption.copyWith(color: LuxColors.warn)),
        ),
    ]);
  }

  Widget _alerts() {
    final s = RivalWatch.state.value;
    final list = (s?.alerts ?? const <WatchAlert>[]).take(3).toList();
    if (list.isEmpty) return const SizedBox.shrink();
    return _panel('هشدارهای فوری', null, Column(children: [for (final a in list) AlertTile(a)]),
        trailing: GestureDetector(onTap: () => pushPage<void>(context, const CommandRoomPage()), child: Text('اتاق فرمان ←', style: LuxText.caption.copyWith(color: LuxColors.accent, fontWeight: FontWeight.w700))));
  }

  Widget _horizonChips() => Row(children: [
        Text('افق پیش‌بینی:', style: LuxText.caption),
        const SizedBox(width: 10),
        for (final h in const [2, 4, 8])
          GestureDetector(
            onTap: () {
              Haptic.tap();
              _h = h;
              _recompute();
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              margin: const EdgeInsetsDirectional.only(end: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(color: _h == h ? LuxColors.accent : LuxColors.cardHi, borderRadius: BorderRadius.circular(16)),
              child: Text('${faDigits(h)} امتحان', style: LuxText.caption.copyWith(color: _h == h ? LuxColors.onAccent : LuxColors.text, fontWeight: FontWeight.w700)),
            ),
          ),
      ]);

  Widget _personChips(WrResult r) => SizedBox(
        height: 40,
        child: ListView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          children: [
            for (final p in r.people)
              GestureDetector(
                onTap: () {
                  Haptic.tap();
                  setState(() {
                    if (_shown.contains(p.id)) {
                      if (_shown.length > 1 && !p.isMe) _shown.remove(p.id);
                    } else {
                      _shown.add(p.id);
                    }
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  margin: const EdgeInsetsDirectional.only(end: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: _shown.contains(p.id) ? LuxColors.alpha(_colorOf(p), 0.18) : LuxColors.cardHi,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: _shown.contains(p.id) ? _colorOf(p) : Colors.transparent, width: 1.3),
                  ),
                  alignment: Alignment.center,
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(width: 9, height: 9, decoration: BoxDecoration(color: _colorOf(p), shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    Text(p.isMe ? 'من' : p.name, style: LuxText.caption.copyWith(color: LuxColors.text, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
          ],
        ),
      );

  Widget _timeline(WrResult r) {
    final xs = <DateTime>[...r.pastDates, ...r.futureDates];
    final lines = <_TLine>[];
    final ordered = [...r.people]..sort((a, b) => (a.isMe ? 1 : 0).compareTo(b.isMe ? 1 : 0));
    for (final p in ordered) {
      if (!_shown.contains(p.id)) continue;
      final idx = r.people.indexOf(p);
      final ys = <double?>[];
      final sd = <double>[];
      for (var i = 0; i < r.pastDates.length; i++) {
        ys.add(i < p.series.length ? p.series[i] : null);
        sd.add(0);
      }
      // اتصالِ آخرین نقطه‌ی گذشته به آینده
      if (ys.isNotEmpty) ys[ys.length - 1] = ys.last ?? r.fcMean[idx][0];
      for (var k = 1; k <= r.horizon; k++) {
        ys.add(r.fcMean[idx][k]);
        sd.add(r.fcSd[idx][k]);
      }
      lines.add(_TLine(p.isMe ? 'من' : p.name, _colorOf(p), ys, sd, p.isMe));
    }
    return _panel('مسیرِ نمره‌ها در زمان', 'خط‌چین = پیش‌بینی، سایه = بازه‌ی عدم‌قطعیت. برای دیدن عددها لمس کن.',
        Column(children: [
          _personChips(r),
          const SizedBox(height: 12),
          SizedBox(height: 280, child: _TimelineChart(xs: xs, pastCount: r.pastDates.length, lines: lines)),
          const SizedBox(height: 6),
          _horizonChips(),
        ]));
  }

  Widget _rankChart(WrResult r) {
    final ks = List<int>.generate(r.horizon, (i) => i + 1);
    return _panel('رتبه‌ی تو در زمان', 'خط‌چین = رتبه‌ی محتمل، سایه = از خوش‌بینانه تا بدبینانه',
        SizedBox(
          height: 190,
          child: _RankChart(
            dates: [...r.pastDates, ...r.futureDates],
            past: r.rankPast,
            pastCount: r.pastDates.length,
            nowRank: r.rankNow,
            meanF: [for (final k in ks) r.meanRank(k)],
            lowF: [for (final k in ks) r.rankQuantile(k, 0.15)],
            highF: [for (final k in ks) r.rankQuantile(k, 0.85)],
            total: r.people.length,
          ),
        ));
  }

  Widget _forecastTable(WrResult r) {
    final ks = <int>{1, math.max(1, (r.horizon / 2).round()), r.horizon}.toList()..sort();
    final cards = <Widget>[];
    for (final k in ks) {
      final order = List<int>.generate(r.people.length, (i) => i)..sort((a, b) => r.fcMean[b][k].compareTo(r.fcMean[a][k]));
      final rows = <Widget>[];
      for (var pos = 0; pos < order.length; pos++) {
        final i = order[pos];
        final p = r.people[i];
        if (pos >= 5 && !p.isMe) continue;
        final d = r.fcMean[i][k] - p.avg;
        rows.add(Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            SizedBox(width: 22, child: Text(faDigits(pos + 1), style: LuxText.caption.copyWith(fontWeight: FontWeight.w800, color: p.isMe ? LuxColors.accent : LuxColors.textDim))),
            Container(width: 8, height: 8, decoration: BoxDecoration(color: _colorOf(p), shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Expanded(child: Text(p.isMe ? 'تو' : p.name, style: LuxText.body.copyWith(fontWeight: p.isMe ? FontWeight.w800 : FontWeight.w500, color: p.isMe ? LuxColors.accent : LuxColors.text))),
            Text(_n(r.fcMean[i][k], 2), style: LuxText.body.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            SizedBox(width: 44, child: Text('${d >= 0 ? '+' : '−'}${_n(d.abs(), 2)}', style: LuxText.caption.copyWith(color: d >= 0 ? LuxColors.ok : LuxColors.danger), textAlign: TextAlign.end)),
          ]),
        ));
      }
      cards.add(Container(
        width: 250,
        margin: const EdgeInsetsDirectional.only(end: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(22))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(k == r.horizon ? 'پایانِ افق (${faDigits(k)} امتحان بعد)' : 'پس از ${faDigits(k)} امتحان', style: LuxText.heading),
          const SizedBox(height: 8),
          ...rows,
        ]),
      ));
    }
    return _panel('وضعیتِ کلاس در هر بازه', 'میانگینِ پیش‌بینی‌شده‌ی هر نفر و تغییرش نسبت به الان', SizedBox(height: 320, child: ListView(scrollDirection: Axis.horizontal, physics: const BouncingScrollPhysics(), children: cards)));
  }

  Widget _rankProb(WrResult r) {
    final d = r.rankDist[r.horizon];
    final show = math.min(6, d.length);
    return _panel('احتمالِ هر رتبه', 'در پایانِ ${faDigits(r.horizon)} امتحانِ بعد',
        Column(children: [
          for (var i = 0; i < show; i++) _hBar('رتبه‌ی ${faDigits(i + 1)}', d[i] / (d.reduce(math.max) == 0 ? 1 : d.reduce(math.max)), _pct(d[i]), i == 0 ? LuxColors.ok : (i == r.rankNow - 1 ? LuxColors.accent : LuxColors.silverDim), bold: i + 1 == r.rankNow),
        ]));
  }

  Widget _risk(WrResult r) {
    final threats = r.people.where((p) => !p.isMe).toList()..sort((a, b) => b.pAboveMe.compareTo(a.pAboveMe));
    final top = threats.isEmpty ? null : threats.first;
    final fragile = r.leadCourse != null && r.leadShare >= 0.5;
    final rep = _rep;
    final duels = (rep != null && top != null) ? WarRoom.duels(rep, top.id) : <WrDuel>[];
    final theyLead = duels.where((d) => d.diff < -0.2).toList()..sort((a, b) => a.diff.compareTo(b.diff));
    return _panel('خطر و شکنندگی', 'کی می‌تواند از تو جلو بزند و چرا',
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            SizedBox(width: 120, height: 76, child: CustomPaint(painter: _GaugePainter(r.pDrop, r.pDrop > 0.5 ? LuxColors.danger : (r.pDrop > 0.25 ? LuxColors.warn : LuxColors.ok)))),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${_pct(r.pDrop)} احتمالِ افتِ رتبه', style: LuxText.heading),
                const SizedBox(height: 4),
                Text('و ${_pct(r.pRise)} احتمالِ بهتر شدن تا ${faDigits(r.horizon)} امتحانِ بعد', style: LuxText.caption.copyWith(height: 1.6)),
              ]),
            ),
          ]),
          if (r.leadCourse != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: LuxColors.alpha(fragile ? LuxColors.warn : LuxColors.ok, 0.12), borderRadius: BorderRadius.circular(LuxColors.r(16))),
              child: Text(
                fragile ? 'برتری‌ات شکننده است: حدود ${_pct(r.leadShare)} از برتری‌ات روی «${r.leadCourse}» تکیه دارد.' : 'برتری‌ات روی چند درس پخش شده؛ بزرگ‌ترینش «${r.leadCourse}» است (${_pct(r.leadShare)}).',
                style: LuxText.caption.copyWith(color: LuxColors.text, height: 1.7),
              ),
            ),
          ],
          const SizedBox(height: 14),
          Text('احتمالِ سبقتِ هر رقیب', style: LuxText.heading),
          for (final p in threats.take(5)) _hBar(p.name, p.pAboveMe, _pct(p.pAboveMe), p.pAboveMe > 0.5 ? LuxColors.danger : (p.pAboveMe > 0.25 ? LuxColors.warn : LuxColors.silverDim)),
          if (top != null && top.pAboveMe > 0.15) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.danger, 0.10), borderRadius: BorderRadius.circular(LuxColors.r(18)), border: Border.all(color: LuxColors.alpha(LuxColors.danger, 0.3))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('زوم روی خطرناک‌ترین: ${top.name}', style: LuxText.heading.copyWith(color: LuxColors.danger)),
                const SizedBox(height: 6),
                Text('احتمالِ سبقتش ${_pct(top.pAboveMe)}${top.momentum == null ? '' : '، روندش ${top.momentum! >= 0 ? 'صعودی' : 'نزولی'} (${top.momentum! >= 0 ? '+' : '−'}${_n(top.momentum!.abs())})'}.', style: LuxText.caption.copyWith(color: LuxColors.text, height: 1.7)),
                if (theyLead.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('جاهایی که از تو جلوتر است: ${theyLead.take(3).map((d) => '${d.course} (${_n(-d.diff)}+)').join('، ')}', style: LuxText.caption.copyWith(color: LuxColors.text, height: 1.7)),
                  ),
              ]),
            ),
          ],
        ]));
  }

  Widget _sens(WrResult r) {
    final list = r.sensitivity.where((e) => e.value.abs() >= 0.05).take(6).toList();
    if (list.isEmpty) return const SizedBox.shrink();
    final mx = list.map((e) => e.value.abs()).reduce(math.max);
    return _panel('قدرتمندترین حرکت', '«یک نمره‌ی بیشتر» در کدام درس بیشترین اثر را روی اول‌شدنت دارد؟ (تخمینی)',
        Column(children: [for (final e in list) _hBar(e.key, e.value.abs() / mx, '${e.value >= 0 ? '+' : '−'}${faDigits(e.value.abs().toStringAsFixed(1))}٪', e.value >= 0 ? LuxColors.ok : LuxColors.danger)]));
  }

  Widget _dossiers(WrResult r) {
    final cards = <Widget>[];
    final rivals = r.people.where((p) => !p.isMe).toList()..sort((a, b) => b.pAboveMe.compareTo(a.pAboveMe));
    for (final p in rivals) {
      final idx = r.people.indexOf(p);
      cards.add(Container(
        width: 226,
        margin: const EdgeInsetsDirectional.only(end: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(22)), border: Border.all(color: LuxColors.alpha(_colorOf(p), 0.4))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 10, height: 10, decoration: BoxDecoration(color: _colorOf(p), shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Expanded(child: Text(p.name, style: LuxText.heading, maxLines: 2)),
            Text(_n(p.avg, 2), style: LuxText.title.copyWith(fontSize: 18, color: _colorOf(p))),
          ]),
          const SizedBox(height: 10),
          SizedBox(height: 56, width: double.infinity, child: CustomPaint(painter: _SparkPainter(p.series, r.fcMean[idx], _colorOf(p)))),
          const SizedBox(height: 10),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (final t in p.tags.take(2)) _chip(t, LuxColors.silverDim),
            _chip('سبقت ${_pct(p.pAboveMe)}', p.pAboveMe > 0.4 ? LuxColors.danger : LuxColors.silverDim),
          ]),
          const SizedBox(height: 10),
          Text('امتحانِ بعدی‌اش: ${_n(p.mu)} ± ${_n(p.sigma)}', style: LuxText.caption),
          const SizedBox(height: 4),
          Text('رودررو با تو: ${faDigits(p.wins)} برد، ${faDigits(p.draws)} مساوی، ${faDigits(p.losses)} باخت', style: LuxText.caption.copyWith(height: 1.6)),
          if (p.momentum != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(p.momentum! >= 0.5 ? '▲ در حالِ صعود (${_n(p.momentum!)})' : (p.momentum! <= -0.5 ? '▼ در حالِ افت (${_n(p.momentum!)})' : '● تقریباً ثابت'), style: LuxText.caption.copyWith(color: p.momentum! >= 0.5 ? LuxColors.danger : (p.momentum! <= -0.5 ? LuxColors.ok : LuxColors.textDim))),
            ),
        ]),
      ));
    }
    return _panel('پرونده‌ی رقبا', 'مرتب بر اساس خطر؛ بکش و ببین', SizedBox(height: 330, child: ListView(scrollDirection: Axis.horizontal, physics: const BouncingScrollPhysics(), children: cards)));
  }

  Widget _chip(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(color: LuxColors.alpha(c, 0.15), borderRadius: BorderRadius.circular(12)),
        child: Text(t, style: LuxText.caption.copyWith(color: LuxColors.text, fontSize: 11, fontWeight: FontWeight.w600)),
      );

  Widget _duels(WrResult r) {
    final rep = _rep;
    final id = _duelId;
    if (rep == null || id == null) return const SizedBox.shrink();
    final rival = r.byId(id);
    if (rival == null) return const SizedBox.shrink();
    final list = WarRoom.duels(rep, id);
    return _panel('نبردِ درس‌به‌درس', 'تو در برابر ${rival.name}؛ اسمِ هر درس کامل بالای میله‌هاست',
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
            height: 38,
            child: ListView(scrollDirection: Axis.horizontal, physics: const BouncingScrollPhysics(), children: [
              for (final p in r.people.where((x) => !x.isMe))
                GestureDetector(
                  onTap: () {
                    Haptic.tap();
                    setState(() => _duelId = p.id);
                  },
                  child: Container(
                    margin: const EdgeInsetsDirectional.only(end: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(color: _duelId == p.id ? _colorOf(p) : LuxColors.cardHi, borderRadius: BorderRadius.circular(18)),
                    alignment: Alignment.center,
                    child: Text(p.name, style: LuxText.caption.copyWith(color: _duelId == p.id ? LuxColors.onAccent : LuxColors.text, fontWeight: FontWeight.w700)),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 14),
          if (list.isEmpty) Text('درسِ مشترکی با نمره‌ی هر دو نیست.', style: LuxText.caption),
          for (final d in list)
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(d.course, style: LuxText.body.copyWith(fontWeight: FontWeight.w700))),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                    decoration: BoxDecoration(color: LuxColors.alpha(d.diff.abs() < 0.05 ? LuxColors.textDim : (d.diff > 0 ? LuxColors.ok : LuxColors.danger), 0.16), borderRadius: BorderRadius.circular(10)),
                    child: Text(d.diff.abs() < 0.05 ? 'مساوی' : '${d.diff > 0 ? '+' : '−'}${_n(d.diff.abs())}', style: LuxText.caption.copyWith(color: LuxColors.text, fontWeight: FontWeight.w800)),
                  ),
                ]),
                const SizedBox(height: 6),
                _duelBar(d.me / 20, _n(d.me, 2), LuxColors.accent),
                const SizedBox(height: 4),
                _duelBar(d.rival / 20, _n(d.rival, 2), _colorOf(rival)),
              ]),
            ),
        ]));
  }

  Widget _duelBar(double f, String t, Color c) => Row(children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: SizedBox(
              height: 9,
              child: Stack(children: [
                Container(color: LuxColors.alpha(LuxColors.stroke, 0.5)),
                FractionallySizedBox(alignment: AlignmentDirectional.centerStart, widthFactor: _c01(f), child: Container(color: c)),
              ]),
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(width: 44, child: Text(t, style: LuxText.caption.copyWith(color: LuxColors.text, fontWeight: FontWeight.w700), textAlign: TextAlign.end)),
      ]);

  Widget _lab(WrResult r) {
    final base = r.me.mu;
    final main = r.byId(r.mainRivalId);
    return _panel('آزمایشگاه سناریو', 'اگر در امتحان‌های بعد این نمره‌ها را بگیرید، چه می‌شود؟',
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('میانگینِ نمره‌ی تو: ${_n(_meMu ?? base)}', style: LuxText.body),
          Slider(
            value: (_meMu ?? base).clamp(0.0, 20.0).toDouble(),
            min: 0,
            max: 20,
            divisions: 80,
            activeColor: LuxColors.accent,
            inactiveColor: LuxColors.stroke,
            onChanged: (v) => setState(() => _meMu = v),
            onChangeEnd: (_) => _recompute(),
          ),
          if (main != null) ...[
            Text('میانگینِ نمره‌ی ${main.name}: ${_n(_rivalMu ?? main.mu)}', style: LuxText.body),
            Slider(
              value: (_rivalMu ?? main.mu).clamp(0.0, 20.0).toDouble(),
              min: 0,
              max: 20,
              divisions: 80,
              activeColor: _colorOf(main),
              inactiveColor: LuxColors.stroke,
              onChanged: (v) => setState(() => _rivalMu = v),
              onChangeEnd: (_) => _recompute(),
            ),
          ],
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(16))),
            child: Text('نتیجه: احتمالِ اول‌شدنِ تو ${_pct(r.pFirst)}، رتبه‌ی محتمل ${_n(r.meanRank(r.horizon), 1)} از ${faDigits(r.people.length)}.', style: LuxText.body.copyWith(fontWeight: FontWeight.w700, height: 1.7)),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: LuxButton(label: 'همه‌ی نمره‌هایم ۲۰', compact: true, filled: false, onPressed: () {
              _meMu = 20;
              _recompute();
            })),
            const SizedBox(width: 8),
            Expanded(child: LuxButton(label: 'بازنشانی', compact: true, filled: false, onPressed: () {
              _meMu = null;
              _rivalMu = null;
              _recompute();
            })),
          ]),
        ]));
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    final s = RivalWatch.state.value;
    final r = _r;
    final kids = <Widget>[];
    if (s == null) {
      kids.add(const Padding(padding: EdgeInsets.all(48), child: Center(child: CircularProgressIndicator())));
    } else if (r == null) {
      kids.add(LuxCard(
        child: Column(children: [
          Icon(Icons.public_rounded, color: LuxColors.accent, size: 44),
          const SizedBox(height: 12),
          Text(!s.rivalryOn ? 'رقابت هنوز روشن نیست' : (s.rivalCount == 0 ? 'هنوز رقیبی ثبت نکرده‌ای' : 'هنوز داده‌ی کافی نیست'), style: LuxText.title.copyWith(fontSize: 18), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text('میدان رقابت از نمره‌ی تو و رقبا ساخته می‌شود. رقابت را روشن کن، رقبا را اضافه کن و نمره‌ی چند امتحان را ثبت کن.', style: LuxText.caption.copyWith(height: 1.7), textAlign: TextAlign.center),
          const SizedBox(height: 16),
          LuxButton(label: 'رفتن به رقابت', onPressed: () => pushPage<void>(context, const RivalryPage())),
        ]),
      ));
    } else {
      kids.addAll([
        _header(r),
        const SizedBox(height: 16),
        _alerts(),
        _timeline(r),
        _rankChart(r),
        _forecastTable(r),
        _rankProb(r),
        _risk(r),
        _sens(r),
        _dossiers(r),
        _duels(r),
        _lab(r),
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Text('پیش‌بینی‌ها از نمره‌هایی ساخته می‌شوند که خودت وارد کرده‌ای و تقریبی‌اند؛ هر چه نمره‌ی بیشتری ثبت کنی دقیق‌تر می‌شوند.', style: LuxText.caption.copyWith(height: 1.7), textAlign: TextAlign.center),
        ),
        LuxButton(label: 'مرکز تحلیلِ کامل (جزئیات)', filled: false, onPressed: () => pushPage<void>(context, const RivalryPage())),
      ]);
    }
    return Scaffold(
      backgroundColor: LuxColors.bg,
      body: Stack(children: [
        const Positioned.fill(child: LuxBackdrop()),
        Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.fromLTRB(20 + pad.left, pad.top + 14, 20 + pad.right, 48 + pad.bottom),
              children: [
                Row(children: [
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      Haptic.tap();
                      Navigator.of(context).maybePop();
                    },
                    child: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(color: LuxColors.card, borderRadius: BorderRadius.circular(LuxColors.r(16)), border: Border.all(color: LuxColors.strokeColor, width: LuxColors.strokeW)),
                      child: Icon(Icons.arrow_back_rounded, color: LuxColors.silver, size: 22),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('میدانِ رقابت', style: LuxText.display.copyWith(fontSize: 30)),
                      Text('$kLuxVersionName · فضای اختصاصیِ اول‌شدن', style: LuxText.caption),
                    ]),
                  ),
                ]),
                const SizedBox(height: 20),
                for (var i = 0; i < kids.length; i++) LuxEntrance(index: i, child: kids[i]),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}

// ───────────────────────── نمودارها ─────────────────────────

class _TLine {
  final String name;
  final Color color;
  final List<double?> ys;
  final List<double> sd;
  final bool me;
  const _TLine(this.name, this.color, this.ys, this.sd, this.me);
}

class _TimelineChart extends StatefulWidget {
  final List<DateTime> xs;
  final int pastCount;
  final List<_TLine> lines;
  const _TimelineChart({required this.xs, required this.pastCount, required this.lines});

  @override
  State<_TimelineChart> createState() => _TimelineChartState();
}

class _TimelineChartState extends State<_TimelineChart> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..forward();
  int? _sel;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _pick(Offset p, Size s) {
    final xs = widget.xs;
    if (xs.length < 2) return;
    final plotL = 30.0, plotR = s.width - 10;
    final f = _c01((plotR - p.dx) / (plotR - plotL));
    final t0 = xs.first.millisecondsSinceEpoch.toDouble();
    final span = math.max(1.0, xs.last.millisecondsSinceEpoch - t0);
    final target = t0 + span * f;
    var best = 0;
    var bd = double.infinity;
    for (var i = 0; i < xs.length; i++) {
      final d = (xs[i].millisecondsSinceEpoch - target).abs();
      if (d < bd) {
        bd = d;
        best = i;
      }
    }
    Haptic.tap();
    setState(() => _sel = best);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, cons) {
      final size = Size(cons.maxWidth, cons.maxHeight);
      return GestureDetector(
        onTapDown: (d) => _pick(d.localPosition, size),
        onHorizontalDragUpdate: (d) => _pick(d.localPosition, size),
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => CustomPaint(
            size: size,
            painter: _TimelinePainter(widget.xs, widget.pastCount, widget.lines, _sel, Curves.easeOutCubic.transform(_c.value)),
          ),
        ),
      );
    });
  }
}

class _TimelinePainter extends CustomPainter {
  final List<DateTime> xs;
  final int pastCount;
  final List<_TLine> lines;
  final int? sel;
  final double t;
  _TimelinePainter(this.xs, this.pastCount, this.lines, this.sel, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    if (xs.length < 2 || lines.isEmpty) return;
    final plot = Rect.fromLTRB(30, 16, size.width - 10, size.height - 22);
    var lo = 20.0, hi = 0.0;
    for (final l in lines) {
      for (var i = 0; i < l.ys.length; i++) {
        final y = l.ys[i];
        if (y == null) continue;
        lo = math.min(lo, y - l.sd[i]);
        hi = math.max(hi, y + l.sd[i]);
      }
    }
    lo = math.max(0.0, (lo - 0.5).floorToDouble());
    hi = math.min(20.0, (hi + 0.5).ceilToDouble());
    if (hi - lo < 2) hi = math.min(20.0, lo + 2);
    final t0 = xs.first.millisecondsSinceEpoch.toDouble();
    final span = math.max(1.0, xs.last.millisecondsSinceEpoch - t0);
    double xAt(DateTime d) => plot.right - plot.width * _c01((d.millisecondsSinceEpoch - t0) / span);
    double yAt(double v) => plot.bottom - plot.height * _c01((v - lo) / (hi - lo));

    // شبکه و برچسب نمره
    final step = math.max(1, ((hi - lo) / 4).ceil());
    for (var v = lo; v <= hi + 0.001; v += step) {
      final y = yAt(v);
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), Paint()..color = LuxColors.alpha(LuxColors.stroke, 0.45)..strokeWidth = 1);
      final tp = _tp(faDigits(v.round()), 10, LuxColors.textDim);
      tp.paint(canvas, Offset(2, y - tp.height / 2));
    }

    // ماه‌ها
    final end = xs.last;
    var d = DateTime(xs.first.year, xs.first.month, xs.first.day);
    var lastMonth = Jalali.fromDateTime(d).month;
    var guard = 0;
    while (d.isBefore(end) && guard++ < 800) {
      d = d.add(const Duration(days: 1));
      final j = Jalali.fromDateTime(d);
      if (j.month != lastMonth) {
        lastMonth = j.month;
        final x = xAt(d);
        canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom), Paint()..color = LuxColors.alpha(LuxColors.stroke, 0.5)..strokeWidth = 1);
        final tp = _tp(_months[j.month - 1], 9.5, LuxColors.textDim);
        tp.paint(canvas, Offset(x - tp.width - 3, plot.bottom + 4));
      }
    }

    // امروز و ناحیه‌ی آینده
    final now = DateTime.now();
    final lastPast = xs[math.max(0, pastCount - 1)];
    final firstFut = pastCount < xs.length ? xs[pastCount] : xs.last;
    var today = now.isBefore(lastPast) ? lastPast : (now.isAfter(firstFut) ? firstFut : now);
    final tx = xAt(today);
    canvas.drawRect(Rect.fromLTRB(plot.left, plot.top, tx, plot.bottom), Paint()..color = LuxColors.alpha(LuxColors.accent, 0.05));
    final todayPaint = Paint()..color = LuxColors.alpha(LuxColors.text, 0.5)..strokeWidth = 1.2..style = PaintingStyle.stroke;
    _dash(canvas, Path()..moveTo(tx, plot.top)..lineTo(tx, plot.bottom), todayPaint, on: 4, off: 4);
    final todayTp = _tp('امروز', 10, LuxColors.text, w: FontWeight.w700);
    todayTp.paint(canvas, Offset(tx - todayTp.width / 2, 0));
    final futTp = _tp('پیش‌بینی', 10, LuxColors.accent, w: FontWeight.w700);
    if (tx - plot.left > futTp.width + 12) futTp.paint(canvas, Offset(plot.left + 6, plot.top + 2));

    // خطوط (با آشکارشدنِ تدریجی از راست)
    canvas.save();
    canvas.clipRect(Rect.fromLTRB(size.width - size.width * t, 0, size.width, size.height));
    for (final l in lines) {
      final past = <Offset>[];
      final fut = <Offset>[];
      final upper = <Offset>[];
      final lower = <Offset>[];
      for (var i = 0; i < l.ys.length && i < xs.length; i++) {
        final y = l.ys[i];
        if (y == null) continue;
        final o = Offset(xAt(xs[i]), yAt(y));
        if (i < pastCount) {
          past.add(o);
        } else {
          fut.add(o);
        }
        if (i >= pastCount - 1) {
          upper.add(Offset(o.dx, yAt(y + l.sd[i])));
          lower.add(Offset(o.dx, yAt(y - l.sd[i])));
        }
      }
      if (upper.length >= 2) {
        final band = Path()..moveTo(upper.first.dx, upper.first.dy);
        for (final o in upper.skip(1)) {
          band.lineTo(o.dx, o.dy);
        }
        for (final o in lower.reversed) {
          band.lineTo(o.dx, o.dy);
        }
        band.close();
        canvas.drawPath(band, Paint()..color = LuxColors.alpha(l.color, 0.13));
      }
      Path smooth(List<Offset> pts) {
        final p = Path()..moveTo(pts.first.dx, pts.first.dy);
        for (var i = 1; i < pts.length; i++) {
          final a = pts[i - 1], b = pts[i];
          final mx = (a.dx + b.dx) / 2;
          p.cubicTo(mx, a.dy, mx, b.dy, b.dx, b.dy);
        }
        return p;
      }

      final w = l.me ? 3.6 : 2.4;
      if (past.length >= 2) {
        if (l.me) canvas.drawPath(smooth(past), Paint()..style = PaintingStyle.stroke..strokeWidth = w + 5..color = LuxColors.alpha(l.color, 0.2)..strokeCap = StrokeCap.round);
        canvas.drawPath(smooth(past), Paint()..style = PaintingStyle.stroke..strokeWidth = w..color = l.color..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round);
      }
      for (final o in past) {
        canvas.drawCircle(o, l.me ? 3.6 : 2.6, Paint()..color = l.color);
        canvas.drawCircle(o, l.me ? 1.5 : 1.0, Paint()..color = LuxColors.bg);
      }
      if (fut.isNotEmpty) {
        final pts = <Offset>[if (past.isNotEmpty) past.last, ...fut];
        if (pts.length >= 2) {
          _dash(canvas, smooth(pts), Paint()..style = PaintingStyle.stroke..strokeWidth = w..color = l.color..strokeCap = StrokeCap.round);
        }
        canvas.drawCircle(fut.last, 4.2, Paint()..color = l.color);
        final y = l.ys.last;
        if (y != null) {
          final vt = _tp(faDigits(y.toStringAsFixed(1)), 10.5, l.color, w: FontWeight.w800);
          vt.paint(canvas, Offset(math.max(0.0, fut.last.dx - vt.width / 2), fut.last.dy - 18));
        }
      }
    }
    canvas.restore();

    // انتخاب
    final s = sel;
    if (s != null && s < xs.length) {
      final x = xAt(xs[s]);
      canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom), Paint()..color = LuxColors.alpha(LuxColors.text, 0.35)..strokeWidth = 1);
      final rows = <TextPainter>[_tp(_dateLabel(xs[s]) + (s >= pastCount ? ' (پیش‌بینی)' : ''), 10.5, LuxColors.textDim, w: FontWeight.w700)];
      for (final l in lines) {
        final y = s < l.ys.length ? l.ys[s] : null;
        if (y != null) rows.add(_tp('${l.name}  ${faDigits(y.toStringAsFixed(2))}', 11, l.color, w: FontWeight.w700));
      }
      var bw = 0.0, bh = 8.0;
      for (final r in rows) {
        bw = math.max(bw, r.width);
        bh += r.height + 3;
      }
      bw += 18;
      final left = (x + bw + 8 > size.width) ? x - bw - 8 : x + 8;
      final rect = RRect.fromRectAndRadius(Rect.fromLTWH(math.max(2.0, left), plot.top + 4, bw, bh), const Radius.circular(10));
      canvas.drawRRect(rect, Paint()..color = LuxColors.alpha(LuxColors.card, 0.96));
      canvas.drawRRect(rect, Paint()..style = PaintingStyle.stroke..color = LuxColors.alpha(LuxColors.stroke, 0.9));
      var y0 = rect.top + 6;
      for (final r in rows) {
        r.paint(canvas, Offset(rect.left + 9, y0));
        y0 += r.height + 3;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _TimelinePainter o) => o.t != t || o.sel != sel || o.lines != lines;
}

class _RankChart extends StatefulWidget {
  final List<DateTime> dates;
  final List<int?> past;
  final int pastCount;
  final int nowRank;
  final List<double> meanF;
  final List<double> lowF;
  final List<double> highF;
  final int total;
  const _RankChart({required this.dates, required this.past, required this.pastCount, required this.nowRank, required this.meanF, required this.lowF, required this.highF, required this.total});

  @override
  State<_RankChart> createState() => _RankChartState();
}

class _RankChartState extends State<_RankChart> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) => CustomPaint(
        size: Size.infinite,
        painter: _RankPainter(widget.dates, widget.past, widget.pastCount, widget.nowRank, widget.meanF, widget.lowF, widget.highF, widget.total, Curves.easeOutCubic.transform(_c.value)),
      ),
    );
  }
}

class _RankPainter extends CustomPainter {
  final List<DateTime> dates;
  final List<int?> past;
  final int pastCount;
  final int nowRank;
  final List<double> meanF;
  final List<double> lowF;
  final List<double> highF;
  final int total;
  final double t;
  _RankPainter(this.dates, this.past, this.pastCount, this.nowRank, this.meanF, this.lowF, this.highF, this.total, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    if (dates.length < 2) return;
    final plot = Rect.fromLTRB(26, 12, size.width - 10, size.height - 12);
    final top = 1.0;
    final bottom = math.max(3.0, total.toDouble());
    final t0 = dates.first.millisecondsSinceEpoch.toDouble();
    final span = math.max(1.0, dates.last.millisecondsSinceEpoch - t0);
    double xAt(DateTime d) => plot.right - plot.width * _c01((d.millisecondsSinceEpoch - t0) / span);
    double yAt(double r) => plot.top + plot.height * _c01((r - top) / (bottom - top));
    for (var r = 1; r <= bottom.toInt(); r += math.max(1, (bottom / 4).ceil())) {
      final y = yAt(r.toDouble());
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), Paint()..color = LuxColors.alpha(LuxColors.stroke, 0.45));
      _tp(faDigits(r), 10, LuxColors.textDim).paint(canvas, Offset(4, y - 6));
    }
    canvas.save();
    canvas.clipRect(Rect.fromLTRB(size.width - size.width * t, 0, size.width, size.height));
    final pts = <Offset>[];
    for (var i = 0; i < past.length && i < dates.length && i < pastCount; i++) {
      final r = past[i];
      if (r == null) continue;
      pts.add(Offset(xAt(dates[i]), yAt(r.toDouble())));
    }
    final c = LuxColors.accent;
    Path smooth(List<Offset> p) {
      final path = Path()..moveTo(p.first.dx, p.first.dy);
      for (var i = 1; i < p.length; i++) {
        final a = p[i - 1], b = p[i];
        final m = (a.dx + b.dx) / 2;
        path.cubicTo(m, a.dy, m, b.dy, b.dx, b.dy);
      }
      return path;
    }

    if (pts.length >= 2) canvas.drawPath(smooth(pts), Paint()..style = PaintingStyle.stroke..strokeWidth = 3.2..color = c..strokeCap = StrokeCap.round);
    for (final o in pts) {
      canvas.drawCircle(o, 3.4, Paint()..color = c);
    }
    final start = pts.isNotEmpty ? pts.last : Offset(xAt(dates[math.max(0, pastCount - 1)]), yAt(nowRank.toDouble()));
    final fut = <Offset>[];
    final up = <Offset>[start];
    final dn = <Offset>[start];
    for (var k = 0; k < meanF.length; k++) {
      final idx = pastCount + k;
      if (idx >= dates.length) break;
      final x = xAt(dates[idx]);
      fut.add(Offset(x, yAt(meanF[k])));
      up.add(Offset(x, yAt(lowF[k])));
      dn.add(Offset(x, yAt(highF[k])));
    }
    if (up.length >= 2) {
      final band = Path()..moveTo(up.first.dx, up.first.dy);
      for (final o in up.skip(1)) {
        band.lineTo(o.dx, o.dy);
      }
      for (final o in dn.reversed) {
        band.lineTo(o.dx, o.dy);
      }
      band.close();
      canvas.drawPath(band, Paint()..color = LuxColors.alpha(c, 0.16));
    }
    if (fut.isNotEmpty) {
      _dash(canvas, smooth([start, ...fut]), Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = c);
      canvas.drawCircle(fut.last, 4.5, Paint()..color = c);
      final vt = _tp('≈ ${faDigits(meanF.last.toStringAsFixed(1))}', 10.5, c, w: FontWeight.w800);
      vt.paint(canvas, Offset(math.max(0.0, fut.last.dx - vt.width / 2), fut.last.dy + 8));
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _RankPainter o) => o.t != t;
}

class _GaugePainter extends CustomPainter {
  final double v;
  final Color c;
  _GaugePainter(this.v, this.c);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(6, 6, size.width - 12, (size.height - 6) * 2);
    final base = Paint()..style = PaintingStyle.stroke..strokeWidth = 11..strokeCap = StrokeCap.round..color = LuxColors.alpha(LuxColors.stroke, 0.6);
    canvas.drawArc(rect, math.pi, math.pi, false, base);
    canvas.drawArc(rect, math.pi, math.pi * _c01(v), false, Paint()..style = PaintingStyle.stroke..strokeWidth = 11..strokeCap = StrokeCap.round..color = c);
    final tp = _tp(faDigits((v * 100).round()) + '٪', 17, c, w: FontWeight.w800);
    tp.paint(canvas, Offset(size.width / 2 - tp.width / 2, size.height - tp.height - 4));
  }

  @override
  bool shouldRepaint(covariant _GaugePainter o) => o.v != v;
}

class _SparkPainter extends CustomPainter {
  final List<double?> past;
  final List<double> fc; // fc[0] = الان
  final Color c;
  _SparkPainter(this.past, this.fc, this.c);

  @override
  void paint(Canvas canvas, Size size) {
    final vals = <double>[for (final v in past) if (v != null) v];
    final all = [...vals, ...fc.skip(1)];
    if (all.length < 2) return;
    final lo = all.reduce(math.min) - 0.3;
    final hi = all.reduce(math.max) + 0.3;
    final total = vals.length + fc.length - 1;
    double xAt(int i) => size.width - size.width * i / math.max(1, total - 1);
    double yAt(double v) => size.height - size.height * _c01((v - lo) / math.max(0.01, hi - lo));
    final pastPts = <Offset>[for (var i = 0; i < vals.length; i++) Offset(xAt(i), yAt(vals[i]))];
    if (pastPts.length >= 2) {
      final p = Path()..moveTo(pastPts.first.dx, pastPts.first.dy);
      for (final o in pastPts.skip(1)) {
        p.lineTo(o.dx, o.dy);
      }
      canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.4..color = c..strokeJoin = StrokeJoin.round);
    }
    final futPts = <Offset>[if (pastPts.isNotEmpty) pastPts.last, for (var k = 1; k < fc.length; k++) Offset(xAt(vals.length - 1 + k), yAt(fc[k]))];
    if (futPts.length >= 2) {
      final p = Path()..moveTo(futPts.first.dx, futPts.first.dy);
      for (final o in futPts.skip(1)) {
        p.lineTo(o.dx, o.dy);
      }
      _dash(canvas, p, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = LuxColors.alpha(c, 0.8), on: 4, off: 3);
    }
  }

  @override
  bool shouldRepaint(covariant _SparkPainter o) => true;
}
