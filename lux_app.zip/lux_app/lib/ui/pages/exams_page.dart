import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../widgets/lux_hub.dart';
import '../widgets/lux_kit.dart';
import '../widgets/page_frame.dart';
import '../widgets/profile_button.dart';
import 'calendar_page.dart';
import 'manage/overdue_page.dart';
import 'manage/week_plan_pages.dart';
import 'manage/editors.dart';
import 'manage/exam_pages.dart';
import 'manage/plan_pages.dart';
import 'manage/quick_add.dart';
import 'manage/task_pages.dart';

/// تبِ «برنامه»: چهار بخشِ کنار هم — پیش‌رو، امتحان‌ها، تکالیف، کلاس‌ها
class ExamsPage extends StatefulWidget {
  const ExamsPage({super.key});

  @override
  State<ExamsPage> createState() => _ExamsPageState();
}

class _ExamsPageState extends State<ExamsPage> {
  int _seg = 0;

  static const List<String> _names = <String>['پیش‌رو', 'امتحان‌ها', 'تکالیف', 'کلاس‌ها'];
  static const List<String> _subs = <String>[
    'امتحان‌ها و تکالیفِ روزهای آینده',
    'تاریخ، محدوده، یادآور و نمره',
    'کارهایی که باید انجام بدهی',
    'برنامه‌ی هفتگی کلاس‌ها',
  ];

  void _add() {
    switch (_seg) {
      case 1:
        showExamEditor(context);
        break;
      case 2:
        showTaskEditor(context);
        break;
      case 3:
        showSlotEditor(context);
        break;
      default:
        showQuickAdd(context);
    }
  }

  Widget _shortcuts() {
    void go(Widget w) => pushPage<void>(context, w);
    return LuxTileGrid(tiles: [
      LuxTile(icon: Icons.calendar_month_rounded, title: 'تقویم', sub: 'ماه و مناسبت‌ها', onTap: () => go(const CalendarPage())),
      LuxTile(icon: Icons.calendar_view_week_rounded, title: 'برنامه‌ی هفتگی', sub: 'چیدمانِ هفته', onTap: () => go(const WeekPlanPage())),
      LuxTile(icon: Icons.update_rounded, title: 'عقب‌افتاده‌ها', sub: 'کارهای مانده', tint: LuxColors.warn, onTap: () => go(const OverduePage())),
      LuxTile(icon: Icons.timer_rounded, title: 'تایمر تمرکز', sub: 'پومودورو', onTap: () => go(const PomodoroPage())),
    ]);
  }

  Widget _body() {
    switch (_seg) {
      case 1:
        return const ExamsBody();
      case 2:
        return const TasksBody();
      case 3:
        return const TimetableBody();
      default:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _shortcuts(),
            const SizedBox(height: 8),
            const AgendaBody(),
          ],
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'برنامه',
      subtitle: _subs[_seg],
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          LuxAddButton(onTap: _add),
          const SizedBox(width: 10),
          const ProfileButton(),
        ],
      ),
      children: [
        LuxSegmented(names: _names, index: _seg, onChanged: (i) => setState(() => _seg = i)),
        const SizedBox(height: 18),
        _body(),
      ],
    );
  }
}
