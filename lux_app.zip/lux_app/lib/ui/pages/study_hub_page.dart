import 'package:flutter/material.dart';
import '../widgets/lux_hub.dart';
import '../widgets/lux_kit.dart';
import '../widgets/page_frame.dart';
import '../widgets/profile_button.dart';
import 'analysis_page.dart';
import 'manage/pomodoro_page.dart';
import 'manage/review_pages.dart';
import 'reader/reader_library_page.dart';
import 'smart/cards_page.dart';
import 'smart/mock_exam_page.dart';
import 'smart/smart_plan_page.dart';
import 'smart/weakness_page.dart';
import 'smart/weekly_review_page.dart';
import 'study_stats_page.dart';

/// تبِ «مطالعه»: همه‌ی ابزارهای یادگیری یک‌جا + تحلیلِ پیشرفت.
class StudyHubPage extends StatefulWidget {
  const StudyHubPage({super.key});

  @override
  State<StudyHubPage> createState() => _StudyHubPageState();
}

class _StudyHubPageState extends State<StudyHubPage> {
  int _seg = 0;

  void _go(Widget page) => pushPage<void>(context, page);

  Widget _tools() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LuxHeroAction(
          icon: Icons.timer_rounded,
          title: 'تایمر تمرکز',
          sub: 'پومودورو و ثبتِ خودکارِ جلسه‌ها',
          cta: 'شروع',
          onTap: () => _go(const PomodoroPage()),
        ),
        const SizedBox(height: 22),
        const LuxGroupTitle('برنامه‌ریزی هوشمند'),
        LuxTileGrid(tiles: [
          LuxTile(icon: Icons.auto_awesome_rounded, title: 'برنامه‌ی هوشمند', sub: 'پیشنهادِ امروز', onTap: () => _go(const SmartPlanPage())),
          LuxTile(icon: Icons.insights_rounded, title: 'مرور هفته', sub: 'نتیجه و هدف', onTap: () => _go(const WeeklyReviewPage())),
          LuxTile(icon: Icons.map_rounded, title: 'نقشه‌ی ضعف', sub: 'کدام فصل‌ها؟', onTap: () => _go(const WeaknessPage())),
          LuxTile(icon: Icons.quiz_rounded, title: 'امتحان آزمایشی', sub: 'با تایمر', onTap: () => _go(const MockExamPage())),
        ]),
        const SizedBox(height: 12),
        const LuxGroupTitle('مرور و یادگیری'),
        LuxTileGrid(tiles: [
          LuxTile(icon: Icons.style_rounded, title: 'فلش‌کارت', sub: 'مرور فاصله‌دار', onTap: () => _go(const CardsPage())),
          LuxTile(icon: Icons.replay_rounded, title: 'مرورِ امروز', sub: 'موعدِ مرورها', onTap: () => _go(const ReviewPage())),
          LuxTile(icon: Icons.error_outline_rounded, title: 'دفترچه‌ی اشتباهات', sub: 'اشتباه‌ها را جمع کن', onTap: () => _go(const MistakesPage())),
          LuxTile(icon: Icons.picture_as_pdf_rounded, title: 'کتابخانه‌ی PDF', sub: 'کتاب‌ها و جزوه‌ها', onTap: () => _go(const ReaderLibraryPage())),
        ]),
        const SizedBox(height: 12),
        const LuxGroupTitle('گزارش'),
        LuxTileGrid(tiles: [
          LuxTile(icon: Icons.bar_chart_rounded, title: 'آمار مطالعه', sub: 'ساعت‌ها و جلسه‌ها', onTap: () => _go(const StudyStatsPage())),
          LuxTile(icon: Icons.show_chart_rounded, title: 'تحلیل پیشرفت', sub: 'نمودار نمره‌ها', onTap: () => setState(() => _seg = 1)),
        ]),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'مطالعه',
      subtitle: _seg == 0 ? 'تمرکز، مرور و یادگیری' : 'فقط با داده‌های خودت',
      trailing: const ProfileButton(),
      children: [
        LuxSegmented(names: const ['ابزارها', 'تحلیل'], index: _seg, onChanged: (i) => setState(() => _seg = i)),
        const SizedBox(height: 18),
        if (_seg == 0) _tools() else const AnalysisPage(embedded: true),
      ],
    );
  }
}
