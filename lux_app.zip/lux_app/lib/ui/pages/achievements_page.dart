import 'package:flutter/material.dart';
import '../../core/achievements.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../widgets/lux_card.dart';

/// کارنامه‌ی افتخارات: رتبه، امتیاز و همه‌ی نشان‌ها (حتی قفل‌ها با نوارِ پیشرفت).
class AchievementsPage extends StatefulWidget {
  const AchievementsPage({super.key});

  @override
  State<AchievementsPage> createState() => _AchievementsPageState();
}

class _AchievementsPageState extends State<AchievementsPage> {
  AchSummary? _s = Achievements.summary.value;

  @override
  void initState() {
    super.initState();
    Achievements.evaluate().then((v) {
      if (mounted) setState(() => _s = v);
    });
  }

  void _detail(AchState a) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: LuxColors.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(LuxColors.r(28)))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(a.def.icon, size: 44, color: achTierColor(a.tier)),
            const SizedBox(height: 10),
            Text(a.def.title, style: LuxText.title.copyWith(fontSize: 20)),
            const SizedBox(height: 4),
            Text('الان: ${a.value} ${a.def.unit}', style: LuxText.caption),
            const SizedBox(height: 18),
            for (var t = 1; t <= 3; t++)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  children: [
                    Icon(a.tier >= t ? Icons.check_circle_rounded : Icons.lock_outline_rounded, color: achTierColor(a.tier >= t ? t : 0), size: 22),
                    const SizedBox(width: 10),
                    Text('${kTierNames[t]}: ${a.def.targets[t - 1]} ${a.def.unit}', style: LuxText.body),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _hero(AchSummary s) => LuxCard(
        child: Column(
          children: [
            Text('رتبه‌ی تو', style: LuxText.caption),
            const SizedBox(height: 6),
            Text(kRankNames[s.rank], style: LuxText.title.copyWith(fontSize: 30, color: LuxColors.accent)),
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(value: s.rankProgress, minHeight: 10, backgroundColor: LuxColors.stroke, color: LuxColors.accent),
            ),
            const SizedBox(height: 8),
            Text(s.rankEnd == null ? 'بالاترین رتبه! ${s.xp} امتیاز' : '${s.xp} از ${s.rankEnd} امتیاز تا «${kRankNames[s.rank + 1]}»', style: LuxText.caption),
            const SizedBox(height: 10),
            Text('🔥 ${s.visitStreakNow} روزِ پشت‌سرهم سر زده‌ای', style: LuxText.body),
          ],
        ),
      );

  Widget _badge(AchState a) {
    final c = achTierColor(a.tier);
    final next = a.nextTarget;
    return LuxCard(
      padding: const EdgeInsets.all(14),
      onTap: () => _detail(a),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(shape: BoxShape.circle, color: c.withOpacity(a.tier == 0 ? 0.08 : 0.18), border: Border.all(color: c, width: a.tier == 0 ? 1 : 2.4)),
            child: Icon(a.def.icon, color: c, size: 28),
          ),
          const SizedBox(height: 10),
          Text(a.def.title, style: LuxText.body.copyWith(fontWeight: FontWeight.w700), textAlign: TextAlign.center),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var t = 1; t <= 3; t++)
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: a.tier >= t ? achTierColor(t) : LuxColors.stroke),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Text(next == null ? 'کامل شد' : '${a.value} از $next', style: LuxText.caption),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    return Scaffold(
      backgroundColor: LuxColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
              child: Row(
                children: [
                  IconButton(icon: Icon(Icons.arrow_forward_rounded, color: LuxColors.text), onPressed: () => Navigator.of(context).pop()),
                  Text('کارنامه‌ی افتخارات', style: LuxText.title.copyWith(fontSize: 20)),
                ],
              ),
            ),
            Expanded(
              child: s == null
                  ? const Center(child: CircularProgressIndicator())
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                      physics: const BouncingScrollPhysics(),
                      children: [
                        _hero(s),
                        const SizedBox(height: 18),
                        GridView.count(
                          crossAxisCount: 2,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 0.92,
                          children: [for (final a in s.items) _badge(a)],
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
