import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../services/rival_watch.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';
import 'rivalry_page.dart';

Color levelColor(int l) => l >= 3 ? LuxColors.danger : (l == 2 ? LuxColors.accent : LuxColors.textDim);

class AlertTile extends StatelessWidget {
  final WatchAlert a;
  const AlertTile(this.a, {super.key});

  @override
  Widget build(BuildContext context) {
    final c = levelColor(a.level);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(color: LuxColors.alpha(c, 0.15), shape: BoxShape.circle),
            child: Icon(a.icon, color: c, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(a.title, style: LuxText.body.copyWith(fontWeight: FontWeight.w700)),
                if (a.body.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 2), child: Text(a.body, style: LuxText.caption.copyWith(height: 1.6))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MissionCard extends StatelessWidget {
  final WatchState s;
  const MissionCard(this.s, {super.key});

  @override
  Widget build(BuildContext context) {
    final m = s.mission;
    if (m == null) return const SizedBox.shrink();
    return LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(Icons.flag_rounded, color: LuxColors.accent, size: 20),
            const SizedBox(width: 8),
            Text('مأموریتِ امروز', style: LuxText.caption.copyWith(color: LuxColors.accent, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 10),
          Text(m.title, style: LuxText.title.copyWith(fontSize: 18)),
          if (m.detail.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(m.detail, style: LuxText.caption.copyWith(height: 1.7))),
          const SizedBox(height: 14),
          if (s.missionDone)
            Row(children: [
              Icon(Icons.check_circle_rounded, color: LuxColors.accent),
              const SizedBox(width: 8),
              Text('انجام شد؛ فردا مأموریتِ تازه می‌آید', style: LuxText.caption),
            ])
          else
            LuxButton(
              label: 'انجامش دادم',
              onPressed: () {
                Haptic.heavy();
                RivalWatch.markMissionDone();
              },
            ),
        ],
      ),
    );
  }
}

/// «اتاق فرمانِ اول‌شدن»: رتبه، تهدیدها، مأموریت و همه‌ی هشدارها.
class CommandRoomPage extends StatefulWidget {
  const CommandRoomPage({super.key});

  @override
  State<CommandRoomPage> createState() => _CommandRoomPageState();
}

class _CommandRoomPageState extends State<CommandRoomPage> {
  bool _push = true;

  @override
  void initState() {
    super.initState();
    RivalWatch.refresh();
    RivalWatch.pushEnabled().then((v) {
      if (mounted) setState(() => _push = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<WatchState?>(
      valueListenable: RivalWatch.state,
      builder: (context, s, _) {
        final kids = <Widget>[];
        if (s == null) {
          kids.add(const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())));
        } else if (!s.rivalryOn || s.rivalCount == 0) {
          kids.add(LuxCard(
            child: Column(children: [
              Icon(Icons.groups_rounded, color: LuxColors.accent, size: 40),
              const SizedBox(height: 12),
              Text(!s.rivalryOn ? 'رقابت هنوز روشن نیست' : 'هنوز رقیبی ثبت نکرده‌ای', style: LuxText.title.copyWith(fontSize: 18), textAlign: TextAlign.center),
              const SizedBox(height: 8),
              Text('اتاق فرمان از نمره‌ی رقبا ساخته می‌شود. رقابت را روشن کن و رقبایت را اضافه کن.', style: LuxText.caption, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              LuxButton(label: 'رفتن به رقابت', onPressed: () => pushPage<void>(context, const RivalryPage())),
            ]),
          ));
        } else {
          kids.add(LuxCard(
            child: Column(children: [
              Text('رتبه‌ی کلیِ تو', style: LuxText.caption),
              const SizedBox(height: 6),
              Text(s.rank == 0 ? '—' : '${faDigits(s.rank)}${s.total > 0 ? ' از ${faDigits(s.total)}' : ''}', style: LuxText.title.copyWith(fontSize: 34, color: LuxColors.accent)),
              if (s.rankDelta != 0)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(s.rankDelta > 0 ? '▲ ${faDigits(s.rankDelta)} پله بهتر شدی' : '▼ ${faDigits(-s.rankDelta)} پله افت کردی', style: LuxText.caption.copyWith(color: s.rankDelta > 0 ? LuxColors.accent : LuxColors.danger)),
                ),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(child: _mini('رقیبِ اصلی', s.mainRival ?? '—')),
                Expanded(child: _mini('بزرگ‌ترین تهدید', s.threat ?? '—')),
              ]),
            ]),
          ));
          kids.add(const SizedBox(height: 14));
          kids.add(MissionCard(s));
          kids.add(const SizedBox(height: 14));
          kids.add(LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('هشدارها', style: LuxText.title.copyWith(fontSize: 16)),
                const SizedBox(height: 6),
                if (s.alerts.isEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('فعلاً هشدار تازه‌ای نیست. با ثبت هر نمره دوباره بررسی می‌شود.', style: LuxText.caption)),
                for (final a in s.alerts) AlertTile(a),
              ],
            ),
          ));
          kids.add(const SizedBox(height: 14));
          kids.add(LuxButton(label: 'مرکز تحلیلِ رقابت (جزئیات کامل)', filled: false, onPressed: () => pushPage<void>(context, const RivalryPage())));
        }
        kids.add(const SizedBox(height: 14));
        kids.add(LuxCard(
          child: Row(children: [
            Expanded(child: Text('اعلانِ هشدار و مأموریت\n(حداکثر ۲ تا در روز)', style: LuxText.body.copyWith(height: 1.6))),
            LuxSwitch(
              value: _push,
              onChanged: (v) {
                setState(() => _push = v);
                RivalWatch.setPush(v);
              },
            ),
          ]),
        ));
        return LuxSubPage(title: 'اتاق فرمان', subtitle: 'اول‌شدنِ کلاس', children: kids);
      },
    );
  }

  Widget _mini(String label, String v) => Column(children: [
        Text(label, style: LuxText.caption),
        const SizedBox(height: 4),
        Text(v, style: LuxText.body.copyWith(fontWeight: FontWeight.w800), textAlign: TextAlign.center),
      ]);
}
