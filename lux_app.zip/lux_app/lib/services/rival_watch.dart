import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';

import '../core/app_bus.dart';
import '../core/jalali_utils.dart';
import '../core/util.dart';
import '../data/calendar_repo.dart';
import '../data/database.dart';
import '../data/rivalry_repo.dart';
import '../data/study_repo.dart';
import '../engine/rival_intel.dart';
import '../engine/rivalry.dart';
import 'notification_service.dart';

class WatchAlert {
  final String key;
  final int level; // ۳ فوری، ۲ مهم، ۱ اطلاع
  final String title;
  final String body;
  final IconData icon;
  const WatchAlert(this.key, this.level, this.title, this.body, this.icon);
}

class WatchMission {
  final String title;
  final String detail;
  const WatchMission(this.title, this.detail);
}

class WatchState {
  final bool rivalryOn;
  final int rivalCount;
  final IntelReport? report;
  final List<WatchAlert> alerts;
  final WatchMission? mission;
  final bool missionDone;
  final String? mainRival;
  final String? threat;
  final int rank;
  final int total;
  final int rankDelta; // مثبت = بهتر شده
  const WatchState({
    required this.rivalryOn,
    required this.rivalCount,
    this.report,
    this.alerts = const <WatchAlert>[],
    this.mission,
    this.missionDone = false,
    this.mainRival,
    this.threat,
    this.rank = 0,
    this.total = 0,
    this.rankDelta = 0,
  });
}

/// دیده‌بانِ رقبا: تحلیلِ موجودِ برنامه را هر بار که داده عوض شد دوباره حساب می‌کند،
/// هشدار و «مأموریتِ امروز» می‌سازد و اعلانِ کم‌مزاحم می‌فرستد.
class RivalWatch {
  RivalWatch._();

  static final ValueNotifier<WatchState?> state = ValueNotifier<WatchState?>(null);
  static Timer? _debounce;
  static bool _inited = false;

  static const int _notifAlert = 710000;
  static const int _notifMission = 710001;

  static void init() {
    if (_inited) {
      unawaited(refresh());
      return;
    }
    _inited = true;
    AppBus.data.addListener(() {
      _debounce?.cancel();
      _debounce = Timer(const Duration(seconds: 2), () => refresh());
    });
    unawaited(refresh());
  }

  static String _today() => CalendarRepo.key(DateTime.now());

  // ───── بارگذاری (همان منطقِ صفحه‌ی رقابت، بدونِ رابط) ─────
  static Future<IntelReport?> _loadReport(List<Map<String, Object?>> rivals) async {
    final db = LuxDb.instance;
    final exams = <RivalExam>[];
    final coef = <int, double>{};
    final behavior = <int, Map<int, double>>{};
    final sc = await db.query('rival_scores');
    final byExam = <int, Map<int, double>>{};
    for (final r in sc) {
      byExam.putIfAbsent(asInt(r['exam_id']), () => <int, double>{})[asInt(r['rival_id'])] = asDouble(r['score']);
    }
    final rows = await db.rawQuery(
      'SELECT e.id, e.course_id, e.at_ts, e.max_score, e.weight, e.score, e.title, e.type_name, '
      'c.name AS cname, c.coef AS ccoef FROM exams e JOIN courses c ON c.id = e.course_id '
      "WHERE e.status = 'done' ORDER BY e.at_ts, e.id",
    );
    for (final r in rows) {
      final rv = byExam[asInt(r['id'])] ?? <int, double>{};
      final mine = r['score'] == null ? null : asDouble(r['score']);
      if (mine == null && rv.isEmpty) continue;
      final t = asStr(r['title']).isNotEmpty ? asStr(r['title']) : asStr(r['type_name']);
      final cname = asStr(r['cname']);
      final cid = asInt(r['course_id']);
      coef[cid] = asDouble(r['ccoef'], 1);
      exams.add(RivalExam(
        id: asInt(r['id']),
        courseId: cid,
        courseName: cname,
        title: t.isEmpty ? cname : '$cname · $t',
        at: fromTs(r['at_ts']),
        max: asDouble(r['max_score'], 20),
        weight: asDouble(r['weight'], 1),
        mine: mine,
        rivals: rv,
      ));
    }
    if (exams.isEmpty) return null;
    final rule = await StudyRepo.behaviorRule();
    (await StudyRepo.behaviorCounts()).forEach((cid, v) {
      (behavior[RivalryCalc.me] ??= <int, double>{})[cid] = rule.delta(v[0], v[1]);
    });
    (await RivalryRepo.behaviorCounts()).forEach((rid, byCourse) {
      byCourse.forEach((cid, v) {
        (behavior[rid] ??= <int, double>{})[cid] = rule.delta(v[0], v[1]);
      });
    });
    final policies = await RivalryRepo.policies([for (final r in rivals) asInt(r['id'])]);
    final adjusted = RivalryCalc.fillMissing(exams, policies);
    final now = DateTime.now();
    final up = <int, UpcomingExam>{};
    final upRows = await db.rawQuery(
      'SELECT e.course_id, e.title, e.type_name, e.at_ts FROM exams e WHERE e.status = ? AND e.at_ts >= ? ORDER BY e.at_ts',
      ['planned', now.millisecondsSinceEpoch],
    );
    for (final x in upRows) {
      final cid = asInt(x['course_id']);
      if (up.containsKey(cid)) continue;
      final t = asStr(x['title']).isNotEmpty ? asStr(x['title']) : asStr(x['type_name']);
      up[cid] = UpcomingExam(cid, t, fromTs(x['at_ts']));
    }
    return RivalIntel.analyze(
      exams: adjusted,
      coef: coef,
      behavior: behavior,
      rivals: [for (final r in rivals) IntelPerson(asInt(r['id']), asStr(r['name']), asInt(r['color'], 1))],
      upcoming: up,
      now: now,
    );
  }

  static String _name(IntelReport r, int? id) => id == null ? '؟' : (r.byId[id]?.who.name ?? '؟');

  static int? _days(UpcomingExam? n) {
    if (n == null) return null;
    final d = n.at.difference(DateTime.now());
    if (d.isNegative) return null;
    return (d.inHours / 24).ceil();
  }

  static String _sc(double v) => faDigits(v.toStringAsFixed(1));

  // ───── محاسبه ─────
  static Future<void> refresh() async {
    try {
      final db = LuxDb.instance;
      final on = await RivalryRepo.enabled();
      final rivals = await RivalryRepo.rivals();
      final done = (jsonDecode(await db.kvGet('mission_days') ?? '[]') as List).cast<String>().contains(_today());
      if (!on || rivals.isEmpty) {
        state.value = WatchState(rivalryOn: on, rivalCount: rivals.length, missionDone: done);
        return;
      }
      final rep = await _loadReport(rivals);
      final alerts = <WatchAlert>[];
      WatchMission? mission;
      var rank = 0, total = 0, delta = 0;
      if (rep != null) {
        rank = rep.myOverallRank;
        total = rep.rankTotals.isNotEmpty ? rep.rankTotals.last : 0;
        final s = rep.rankSeries.whereType<int>().toList();
        if (s.length >= 2) delta = s[s.length - 2] - s.last;
        if (delta != 0) {
          alerts.add(WatchAlert('rank:${s.last}', delta > 0 ? 2 : 3, delta > 0 ? 'رتبه‌ات بالا رفت' : 'رتبه‌ات افت کرد',
              'رتبه‌ی کلی‌ات الان ${faDigits(rank)}${total > 0 ? ' از ${faDigits(total)}' : ''} است.', delta > 0 ? Icons.trending_up_rounded : Icons.trending_down_rounded));
        }
        for (final a in rep.actions) {
          final d = _days(a.next);
          final when = d == null ? '' : (d <= 0 ? 'امتحانش امروز است. ' : 'امتحانش ${faDigits(d)} روز دیگر است. ');
          final tgt = a.targetId == null ? '' : _name(rep, a.targetId);
          final need = a.needScore == null ? '' : ' نمره‌ی لازم: ${_sc(a.needScore!)} از ۲۰.';
          if (a.kind == 'urgent') {
            alerts.add(WatchAlert('act:u:${a.courseId}', (d != null && d <= 3) ? 3 : 2, 'فوری: ${a.courseName}', '$when${tgt.isEmpty ? '' : 'از $tgt عقب‌تری. '}$need'.trim(), Icons.priority_high_rounded));
          } else if (a.kind == 'overtake') {
            alerts.add(WatchAlert('act:o:${a.courseId}', 2, 'فرصتِ جلوزدن: ${a.courseName}', '$when${tgt.isEmpty ? '' : 'می‌توانی $tgt را رد کنی. '}$need'.trim(), Icons.bolt_rounded));
          } else {
            alerts.add(WatchAlert('act:d:${a.courseId}', 2, 'مراقب باش: ${a.courseName}', '$when${tgt.isEmpty ? '' : '$tgt نزدیکت شده. '}$need'.trim(), Icons.shield_rounded));
          }
        }
        for (final f in rep.rivalsComeback.take(3)) {
          alerts.add(WatchAlert('cb:${f.personId}:${f.courseId}', 2, '${_name(rep, f.personId)} در ${f.courseName} صعود کرده',
              'میانگینش ${_sc(f.avg)} شده${f.delta == null ? '' : ' (${f.delta! >= 0 ? '+' : ''}${_sc(f.delta!)})'}.', Icons.north_east_rounded));
        }
        for (final f in rep.rivalsDeclining.take(2)) {
          alerts.add(WatchAlert('dc:${f.personId}:${f.courseId}', 1, '${_name(rep, f.personId)} در ${f.courseName} افت کرده', 'فرصتِ خوبی برای جلوزدن است.', Icons.south_east_rounded));
        }
        for (final f in rep.rivalsWeak.take(2)) {
          alerts.add(WatchAlert('wk:${f.personId}:${f.courseId}', 1, 'ضعفِ ${_name(rep, f.personId)}: ${f.courseName}', 'میانگینش در این درس ${_sc(f.avg)} است.', Icons.gps_fixed_rounded));
        }
        for (final f in rep.myFalling.take(2)) {
          alerts.add(WatchAlert('mf:${f.courseId}', 3, 'خودت در ${f.courseName} در حال افتی', 'امتحان‌های اخیرت از قبلی‌ها ضعیف‌تر است.', Icons.warning_amber_rounded));
        }
        for (final f in rep.myBecomingWeak.take(1)) {
          alerts.add(WatchAlert('mb:${f.courseId}', 2, '${f.courseName} دارد ضعیف می‌شود', 'قبل از اینکه عقب بیفتی مرورش کن.', Icons.report_problem_rounded));
        }
        if (rep.actions.isNotEmpty) {
          final a = rep.actions.first;
          final d = _days(a.next);
          final tgt = a.targetId == null ? '' : _name(rep, a.targetId);
          mission = WatchMission(
            'امروز: ۴۵ دقیقه ${a.courseName}',
            '${d == null ? '' : 'امتحانش ${faDigits(d)} روز دیگر است. '}${tgt.isEmpty ? '' : 'هدف: جلو زدن از $tgt. '}${a.needScore == null ? '' : 'در امتحان بعدی حداقل ${_sc(a.needScore!)} لازم داری.'}'.trim(),
          );
        }
      }
      // نمره‌ی ثبت‌نشده‌ی رقبا
      final cut = DateTime.now().subtract(const Duration(days: 10)).millisecondsSinceEpoch;
      final miss = await db.rawQuery(
        'SELECT e.id, e.title, c.name AS cname, (SELECT COUNT(*) FROM rival_scores rs WHERE rs.exam_id = e.id) AS k '
        "FROM exams e JOIN courses c ON c.id = e.course_id WHERE e.status = 'done' AND e.at_ts >= ? ORDER BY e.at_ts DESC LIMIT 4",
        [cut],
      );
      for (final r in miss) {
        if (asInt(r['k']) < (rivals.length / 2).ceil()) {
          final t = asStr(r['title']).isEmpty ? asStr(r['cname']) : '${asStr(r['cname'])} · ${asStr(r['title'])}';
          alerts.add(WatchAlert('miss:${asInt(r['id'])}', 2, 'نمره‌ی رقبا ثبت نشده', '«$t» تمام شده ولی نمره‌ی رقبایش کامل نیست؛ تحلیل بدونش ناقص می‌ماند.', Icons.edit_note_rounded));
          mission ??= const WatchMission('امروز: نمره‌ی رقبا را ثبت کن', 'فقط چند ثانیه وقت می‌برد و تحلیل را دقیق می‌کند.');
        }
      }
      alerts.sort((a, b) => b.level.compareTo(a.level));
      final top = alerts.take(8).toList();
      state.value = WatchState(
        rivalryOn: true,
        rivalCount: rivals.length,
        report: rep,
        alerts: top,
        mission: mission,
        missionDone: done,
        mainRival: rep == null ? null : _name(rep, rep.mainRivalId),
        threat: rep == null || rep.threatId == null ? null : _name(rep, rep.threatId),
        rank: rank,
        total: total,
        rankDelta: delta,
      );
      unawaited(_notify(top, mission, done));
    } catch (_) {}
  }

  // ───── مأموریت ─────
  static Future<void> markMissionDone() async {
    final db = LuxDb.instance;
    List<String> days = <String>[];
    try {
      days = (jsonDecode(await db.kvGet('mission_days') ?? '[]') as List).cast<String>();
    } catch (_) {}
    if (!days.contains(_today())) {
      days.add(_today());
      days.sort();
      if (days.length > 400) days = days.sublist(days.length - 400);
      await db.kvSet('mission_days', jsonEncode(days));
    }
    AppBus.bump();
    await refresh();
  }

  // ───── اعلان‌ها (کم‌مزاحم: حداکثر ۲ در روز، و فقط اگر کاربر خاموش نکرده) ─────
  static Future<bool> pushEnabled() async => (await LuxDb.instance.kvGet('watch_push')) != '0';

  static Future<void> setPush(bool v) async {
    await LuxDb.instance.kvSet('watch_push', v ? '1' : '0');
    await refresh();
  }

  static Future<void> _notify(List<WatchAlert> alerts, WatchMission? mission, bool done) async {
    final n = NotificationService.instance;
    try {
      await n.cancel(_notifAlert);
      await n.cancel(_notifMission);
    } catch (_) {}
    if (!await pushEnabled()) return;
    final db = LuxDb.instance;
    final now = DateTime.now();
    // هشدارِ مهم: عصر (۱۸:۰۰)، یا فردا صبح اگر دیر شده؛ فقط اگر سطحش ≥ ۲ و تازه است
    final last = await db.kvGet('watch_last_key') ?? '';
    WatchAlert? pick;
    for (final a in alerts) {
      if (a.level >= 2 && a.key != last) {
        pick = a;
        break;
      }
    }
    if (pick != null) {
      var at = DateTime(now.year, now.month, now.day, 18);
      if (!at.isAfter(now.add(const Duration(minutes: 2)))) at = DateTime(now.year, now.month, now.day + 1, 9);
      await n.schedule(id: _notifAlert, title: pick.title, body: pick.body, when: at);
      await db.kvSet('watch_last_key', pick.key);
    }
    // یادآورِ مأموریت: ۲۰:۳۰ اگر هنوز انجام نشده
    if (mission != null && !done) {
      final at = DateTime(now.year, now.month, now.day, 20, 30);
      if (at.isAfter(now.add(const Duration(minutes: 2)))) {
        await n.schedule(id: _notifMission, title: 'مأموریتِ امروز هنوز مانده', body: mission.title, when: at);
      }
    }
  }
}
