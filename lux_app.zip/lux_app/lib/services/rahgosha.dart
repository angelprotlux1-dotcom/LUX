import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';

import '../core/account.dart';
import '../core/achievements.dart';
import '../core/server.dart';
import '../data/database.dart';

class RgConfig {
  String nick;
  int preset; // ۰ دوستانه، ۱ حرفه‌ای، ۲ کوتاه‌گو، ۳ بامزه، ۴ رک، ۵ تحلیل‌گر
  double warmth, humor, emoji, length, formality;
  String custom;
  List<String> memories;
  bool proactive;
  int proactiveHours;
  int colorIdx;
  String signature;

  RgConfig({
    this.nick = '',
    this.preset = 0,
    this.warmth = 0.8,
    this.humor = 0.5,
    this.emoji = 0.5,
    this.length = 0.4,
    this.formality = 0.2,
    this.custom = '',
    List<String>? memories,
    this.proactive = true,
    this.proactiveHours = 12,
    this.colorIdx = 0,
    this.signature = '🤖',
  }) : memories = memories ?? <String>[];

  Map<String, Object?> toJson() => {
        'nick': nick,
        'preset': preset,
        'warmth': warmth,
        'humor': humor,
        'emoji': emoji,
        'length': length,
        'formality': formality,
        'custom': custom,
        'memories': memories,
        'proactive': proactive,
        'proactiveHours': proactiveHours,
        'colorIdx': colorIdx,
        'signature': signature,
      };

  static RgConfig fromJson(Map<String, dynamic> j) => RgConfig(
        nick: (j['nick'] ?? '') as String,
        preset: (j['preset'] ?? 0) as int,
        warmth: ((j['warmth'] ?? 0.8) as num).toDouble(),
        humor: ((j['humor'] ?? 0.5) as num).toDouble(),
        emoji: ((j['emoji'] ?? 0.5) as num).toDouble(),
        length: ((j['length'] ?? 0.4) as num).toDouble(),
        formality: ((j['formality'] ?? 0.2) as num).toDouble(),
        custom: (j['custom'] ?? '') as String,
        memories: ((j['memories'] ?? <dynamic>[]) as List).cast<String>(),
        proactive: (j['proactive'] ?? true) as bool,
        proactiveHours: (j['proactiveHours'] ?? 12) as int,
        colorIdx: (j['colorIdx'] ?? 0) as int,
        signature: (j['signature'] ?? '🤖') as String,
      );
}

class RgMsg {
  final bool user;
  final String text;
  final int at;
  RgMsg(this.user, this.text, this.at);
  Map<String, Object?> toJson() => {'u': user, 't': text, 'a': at};
  static RgMsg fromJson(Map<String, dynamic> j) => RgMsg(j['u'] == true, (j['t'] ?? '') as String, (j['a'] ?? 0) as int);
}

const List<String> kRgPresets = <String>['دوستانه', 'حرفه‌ای', 'کوتاه‌گو', 'بامزه', 'رک و روراست', 'تحلیل‌گر'];
const List<Color?> kRgColors = <Color?>[null, Color(0xFFFF8A65), Color(0xFFFFC53D), Color(0xFFB388FF), Color(0xFF69F0AE), Color(0xFFFF80AB)];
const List<String> kRgSignatures = <String>['🤖', '✨', '🌟', '🦊', '🐼', '🚀'];

class Rahgosha {
  Rahgosha._();

  static RgConfig cfg = RgConfig();
  static final List<RgMsg> history = <RgMsg>[];
  static bool _loaded = false;

  static final ValueNotifier<bool> chatOpen = ValueNotifier<bool>(false);
  static final ValueNotifier<bool> unread = ValueNotifier<bool>(false);
  static final ValueNotifier<bool> thinking = ValueNotifier<bool>(false);
  static final ValueNotifier<String?> bubble = ValueNotifier<String?>(null);
  static final ValueNotifier<Offset?> pointer = ValueNotifier<Offset?>(null);

  static bool get serverReady => Account.enforced;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    final db = LuxDb.instance;
    try {
      cfg = RgConfig.fromJson(jsonDecode(await db.kvGet('rg_cfg') ?? '{}') as Map<String, dynamic>);
    } catch (_) {}
    try {
      final l = jsonDecode(await db.kvGet('rg_chat') ?? '[]') as List;
      history
        ..clear()
        ..addAll(l.map((e) => RgMsg.fromJson(e as Map<String, dynamic>)));
    } catch (_) {}
  }

  static Future<void> saveCfg() => LuxDb.instance.kvSet('rg_cfg', jsonEncode(cfg.toJson()));

  static Future<void> saveHistory() async {
    if (history.length > 80) history.removeRange(0, history.length - 80);
    await LuxDb.instance.kvSet('rg_chat', jsonEncode(history.map((m) => m.toJson()).toList()));
  }

  static Future<void> clearHistory() async {
    history.clear();
    await saveHistory();
  }

  static Color color(Color accent) => kRgColors[cfg.colorIdx.clamp(0, kRgColors.length - 1).toInt()] ?? accent;

  // ───── ساختنِ پرامپت ─────

  static String _level(double v, List<String> words) => words[(v * (words.length - 0.001)).floor().clamp(0, words.length - 1).toInt()];

  static Future<String> _context() async {
    final db = LuxDb.instance;
    final now = DateTime.now().millisecondsSinceEpoch;
    final b = StringBuffer();
    try {
      final p = await db.rawQuery('SELECT name, level, grade, track, prev_gpa FROM profile LIMIT 1');
      if (p.isNotEmpty) {
        final r = p.first;
        b.writeln('نام کاربر: ${r['name']} | مقطع: ${r['level'] ?? '-'} | پایه: ${r['grade'] ?? '-'} | رشته: ${r['track'] ?? '-'} | معدل سال قبل: ${r['prev_gpa'] ?? '-'}');
      }
      final c = await db.rawQuery(
          'SELECT c.name AS n, AVG(g.score*1.0/g.max_score)*20 AS a, COUNT(g.id) AS k FROM courses c LEFT JOIN grades g ON g.course_id=c.id WHERE c.archived=0 GROUP BY c.id LIMIT 20');
      if (c.isNotEmpty) {
        b.writeln('درس‌ها (میانگین از ۲۰، تعداد نمره):');
        for (final r in c) {
          final a = r['a'] is num ? (r['a'] as num).toStringAsFixed(1) : 'بدون نمره';
          b.writeln('- ${r['n']}: $a (${r['k']})');
        }
      }
      final g = await db.rawQuery(
          'SELECT c.name AS n, g.score AS s, g.max_score AS m, g.at_ts AS t FROM grades g JOIN courses c ON c.id=g.course_id ORDER BY g.at_ts DESC LIMIT 10');
      if (g.isNotEmpty) {
        b.writeln('آخرین نمره‌ها (جدید به قدیم):');
        for (final r in g) {
          final days = ((now - (r['t'] as num).toInt()) / 86400000).round();
          b.writeln('- ${r['n']}: ${r['s']} از ${r['m']} ($days روز پیش)');
        }
      }
      final e = await db.rawQuery(
          'SELECT c.name AS n, e.title AS ti, e.at_ts AS t FROM exams e JOIN courses c ON c.id=e.course_id WHERE e.score IS NULL AND e.at_ts > ? ORDER BY e.at_ts LIMIT 5',
          [now]);
      if (e.isNotEmpty) {
        b.writeln('آزمون‌های پیش‌رو:');
        for (final r in e) {
          final days = (((r['t'] as num).toInt() - now) / 86400000).ceil();
          b.writeln('- ${r['n']} ${r['ti'] ?? ''}: $days روز دیگر');
        }
      }
      final rv = await db.rawQuery(
          'SELECT r.name AS n, AVG(rs.score*1.0/e.max_score)*20 AS a FROM rivals r JOIN rival_scores rs ON rs.rival_id=r.id JOIN exams e ON e.id=rs.exam_id GROUP BY r.id ORDER BY a DESC LIMIT 6');
      if (rv.isNotEmpty) {
        b.writeln('رقبا (میانگین از ۲۰):');
        for (final r in rv) {
          b.writeln('- ${r['n']}: ${(r['a'] as num).toStringAsFixed(1)}');
        }
      }
    } catch (_) {}
    final s = Achievements.summary.value;
    if (s != null) b.writeln('رتبه‌ی کاربر در لوکس: ${kRankNames[s.rank]} (${s.xp} امتیاز)، ${s.visitStreakNow} روزِ پشت‌سرهم سر زده.');
    return b.toString();
  }

  static Future<String> _system({bool proactive = false}) async {
    final c = cfg;
    final ctx = await _context();
    final nick = c.nick.trim();
    final b = StringBuffer()
      ..writeln('تو «رهگشا» هستی، دستیارِ هوشمند و شیرین‌زبانِ برنامه‌ی لوکس (مدیریت تحصیل). همیشه فارسیِ روان و طبیعی جواب بده.')
      ..writeln('شخصیت پایه: ${[
        'دوستانه و صمیمی، مثل یک رفیقِ باهوش',
        'مؤدب، منظم و حرفه‌ای',
        'خیلی کوتاه و مفید',
        'شوخ‌طبع و بامزه ولی هنوز باهوش',
        'رک و روراست ولی مهربان',
        'تحلیل‌گر و دقیق، با تکیه بر عدد و روند',
      ][c.preset.clamp(0, 5).toInt()]}.')
      ..writeln('گرمی: ${_level(c.warmth, ['کم‌احساس و جدی', 'معمولی', 'گرم', 'بسیار گرم و پر از انرژی'])}. شوخ‌طبعی: ${_level(c.humor, ['تقریباً بی‌شوخی', 'گاهی شوخی', 'شوخ‌طبع', 'خیلی شوخ'])}.')
      ..writeln('ایموجی: ${_level(c.emoji, ['استفاده نکن', 'کم', 'متوسط', 'زیاد'])}. طول جواب: ${_level(c.length, ['بسیار کوتاه (۱ تا ۲ جمله)', 'کوتاه', 'متوسط', 'مفصل'])}. لحن: ${_level(c.formality, ['خودمانی', 'نیمه‌رسمی', 'رسمی'])}.')
      ..writeln('گاهی (نه همیشه) می‌توانی با این نماد امضا کنی: ${c.signature}');
    if (nick.isNotEmpty) b.writeln('کاربر دوست دارد او را «$nick» صدا بزنی.');
    if (c.memories.isNotEmpty) {
      b.writeln('چیزهایی که کاربر خواسته به خاطر بسپاری:');
      for (final m in c.memories) {
        b.writeln('- $m');
      }
    }
    if (c.custom.trim().isNotEmpty) b.writeln('دستورِ سفارشیِ کاربر: ${c.custom.trim()}');
    b
      ..writeln('قوانین: فقط از داده‌های زیر استفاده کن و عدد یا واقعیتی نساز؛ اگر داده نیست، بگو ندارم. تحلیل بده، پیشنهادِ عملی بده و تشویق کن، ولی دروغِ خوشایند نگو.')
      ..writeln('اگر نموداری مفید است، فقط یک بلوکِ دقیقاً به این شکل بنویس (و کنارش توضیح کوتاه):')
      ..writeln('```chart')
      ..writeln('{"type":"line","title":"عنوان","labels":["a","b"],"values":[17,18.5]}')
      ..writeln('```')
      ..writeln('type می‌تواند line یا bar باشد. مقدارها باید عدد باشند.')
      ..writeln('--- داده‌های کاربر ---')
      ..write(ctx);
    if (proactive) b.writeln('این بار خودت گفتگو را شروع می‌کنی؛ فقط یک پیامِ کوتاه (حداکثر ۲ جمله)، شخصی و مفید از روی داده‌ها.');
    return b.toString();
  }

  // ───── ارسال ─────

  static String friendly(Object e) => e is ApiError ? e.message : 'خطای ناشناخته';

  static List<Map<String, String>> _recent() {
    final l = history.length > 14 ? history.sublist(history.length - 14) : List<RgMsg>.from(history);
    while (l.isNotEmpty && !l.first.user) {
      l.removeAt(0);
    }
    return l.map((m) => {'role': m.user ? 'user' : 'model', 'text': m.text}).toList();
  }

  /// پیامِ کاربر را می‌فرستد و جواب را برمی‌گرداند (در history هم ذخیره می‌شود).
  static Future<String> send(String text) async {
    history.add(RgMsg(true, text, DateTime.now().millisecondsSinceEpoch));
    await saveHistory();
    thinking.value = true;
    try {
      final r = await ServerApi.post('/ai/chat', {'system': await _system(), 'messages': _recent()}, token: Account.token);
      final reply = (r['text'] ?? '').toString();
      history.add(RgMsg(false, reply, DateTime.now().millisecondsSinceEpoch));
      await saveHistory();
      Account.track('rahgosha_chat');
      return reply;
    } finally {
      thinking.value = false;
    }
  }

  /// گاهی خودِ رهگشا اول پیام می‌دهد (وقتی برنامه باز می‌شود و زمانش رسیده).
  static Future<void> maybeProactive() async {
    await load();
    if (!cfg.proactive || !serverReady || Account.token == null || chatOpen.value) return;
    final db = LuxDb.instance;
    final last = int.tryParse(await db.kvGet('rg_last_pro') ?? '') ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - last < cfg.proactiveHours * 3600000) return;
    await db.kvSet('rg_last_pro', '$now');
    try {
      final r = await ServerApi.post(
        '/ai/chat',
        {
          'system': await _system(proactive: true),
          'messages': [
            {'role': 'user', 'text': '(پیامِ داخلی) گفتگو را خودت شروع کن.'}
          ],
          'proactive': true,
        },
        token: Account.token,
      );
      final t = (r['text'] ?? '').toString();
      if (t.isEmpty) return;
      history.add(RgMsg(false, t, now));
      await saveHistory();
      unread.value = true;
      bubble.value = t.length > 90 ? '${t.substring(0, 90)}…' : t;
      Timer(const Duration(seconds: 7), () {
        if (bubble.value != null) bubble.value = null;
      });
    } catch (_) {}
  }
}
