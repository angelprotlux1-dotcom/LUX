import 'dart:math' as math;
import 'dart:typed_data';

import 'rival_intel.dart';
import 'rivalry.dart';

/// موتورِ «میدان رقابت»: پیش‌بینی و شبیه‌سازی از روی همان نمره‌هایی که خودت وارد کرده‌ای.
/// خالص و بدون UI. وقتی داده کم باشد، عدد را تقریبی و کم‌اطمینان نشان می‌دهد، نه دقیق.

class WrPerson {
  final int id;
  final String name;
  final int colorIdx;
  final bool isMe;
  final List<double?> series; // سطح کلی پس از هر امتحان
  final List<double> scores; // نمره‌های ۲۰ تایی
  final double avg;
  final int n;
  final double mu; // نمره‌ی مورد انتظار در هر امتحان آینده
  final double sigma;
  final List<String> tags;
  final double? momentum;
  final int wins; // رودررو با من (برای رقبا)
  final int losses;
  final int draws;

  /// ریز نتیجه‌ی شبیه‌سازی (در پایانِ افق)
  double pFirst = 0;
  double pAboveMe = 0;

  WrPerson({
    required this.id,
    required this.name,
    required this.colorIdx,
    required this.isMe,
    required this.series,
    required this.scores,
    required this.avg,
    required this.n,
    required this.mu,
    required this.sigma,
    required this.tags,
    required this.momentum,
    this.wins = 0,
    this.losses = 0,
    this.draws = 0,
  });
}

class WrDuel {
  final String course;
  final double me;
  final double rival;
  const WrDuel(this.course, this.me, this.rival);
  double get diff => me - rival;
}

class WrResult {
  final int horizon;
  final List<WrPerson> people; // اولی: من
  final List<DateTime> pastDates;
  final List<String> pastLabels;
  final List<DateTime> futureDates;

  /// برای هر نفر: میانگینِ پیش‌بینی‌شده پس از k امتحانِ آینده (k = ۰..horizon) و انحراف معیار
  final List<List<double>> fcMean;
  final List<List<double>> fcSd;

  /// رتبه‌ی من تا الان (به ترتیب امتحان)، و توزیعِ رتبه در هر گامِ آینده [k][rank-1]
  final List<int?> rankPast;
  final List<List<double>> rankDist;
  final int rankNow;
  final double pFirst;
  final double pDrop;
  final double pRise;

  /// اثرِ +۱ نمره در هر درس بر احتمالِ اول شدن (درصدِ واحد)
  final List<MapEntry<String, double>> sensitivity;

  /// وابستگیِ برتری به یک درس
  final String? leadCourse;
  final double leadShare;
  final int? mainRivalId;
  final int? threatId;
  final bool lowData;

  const WrResult({
    required this.horizon,
    required this.people,
    required this.pastDates,
    required this.pastLabels,
    required this.futureDates,
    required this.fcMean,
    required this.fcSd,
    required this.rankPast,
    required this.rankDist,
    required this.rankNow,
    required this.pFirst,
    required this.pDrop,
    required this.pRise,
    required this.sensitivity,
    required this.leadCourse,
    required this.leadShare,
    required this.mainRivalId,
    required this.threatId,
    required this.lowData,
  });

  WrPerson get me => people.first;
  WrPerson? byId(int? id) {
    if (id == null) return null;
    for (final p in people) {
      if (p.id == id) return p;
    }
    return null;
  }

  /// چارک/صدکِ رتبه در گامِ k
  double rankQuantile(int k, double q) {
    final d = rankDist[k.clamp(0, rankDist.length - 1).toInt()];
    var c = 0.0;
    for (var i = 0; i < d.length; i++) {
      c += d[i];
      if (c >= q) return i + 1.0;
    }
    return d.length.toDouble();
  }

  double meanRank(int k) {
    final d = rankDist[k.clamp(0, rankDist.length - 1).toInt()];
    var s = 0.0;
    for (var i = 0; i < d.length; i++) {
      s += d[i] * (i + 1);
    }
    return s;
  }
}

class WarRoom {
  WarRoom._();

  static const int _sims = 3000;

  static double _mean(List<double> v) => v.isEmpty ? 0 : v.reduce((a, b) => a + b) / v.length;

  static double _std(List<double> v) {
    if (v.length < 2) return 2.0;
    final m = _mean(v);
    var s = 0.0;
    for (final x in v) {
      s += (x - m) * (x - m);
    }
    return math.sqrt(s / (v.length - 1)).clamp(0.9, 3.5).toDouble();
  }

  static double _ema(List<double> v) {
    var e = v.first;
    for (var i = 1; i < v.length; i++) {
      e = 0.45 * v[i] + 0.55 * e;
    }
    return e;
  }

  static double _normal(math.Random r) {
    final u1 = math.max(r.nextDouble(), 1e-12);
    final u2 = r.nextDouble();
    return math.sqrt(-2.0 * math.log(u1)) * math.cos(2 * math.pi * u2);
  }

  /// تحلیل کامل. [meMu] و [rivalMu] برای «آزمایشگاه سناریو»اند (نمره‌ی فرضیِ امتحان‌های بعد).
  static WrResult? build(IntelReport rep, {int horizon = 4, double? meMu, double? rivalMu, int? rivalOverrideId}) {
    final steps = rep.steps;
    if (steps.isEmpty || rep.people.length < 2) return null;
    final h = horizon.clamp(1, 12).toInt();

    // ── آدم‌ها ──
    final people = <WrPerson>[];
    for (final pi in rep.people) {
      final vals = <double>[];
      var w = 0, l = 0, d = 0;
      for (final st in steps) {
        final v = st.norm(pi.who.id);
        if (v != null) vals.add(v);
        if (!pi.who.isMe) {
          final mine = st.norm(RivalryCalc.me);
          if (v != null && mine != null) {
            if ((mine - v).abs() < 0.05) {
              d++;
            } else if (mine > v) {
              w++; // برد من
            } else {
              l++;
            }
          }
        }
      }
      final avg = pi.overall ?? _mean(vals);
      double mu;
      if (vals.isEmpty) {
        mu = avg == 0 ? 12.0 : avg;
      } else if (vals.length >= 3) {
        mu = 0.55 * _ema(vals) + 0.45 * _mean(vals);
      } else {
        mu = _mean(vals);
      }
      people.add(WrPerson(
        id: pi.who.id,
        name: pi.who.name,
        colorIdx: pi.who.colorIdx,
        isMe: pi.who.isMe,
        series: pi.series,
        scores: vals,
        avg: avg,
        n: vals.length,
        mu: mu.clamp(0.0, 20.0).toDouble(),
        sigma: _std(vals),
        tags: pi.tags,
        momentum: pi.momentum,
        wins: w,
        losses: l,
        draws: d,
      ));
    }
    final p = people.length;
    final mus = <double>[for (final x in people) x.mu];
    if (meMu != null) mus[0] = meMu;
    if (rivalMu != null) {
      final id = rivalOverrideId ?? rep.mainRivalId;
      for (var i = 1; i < p; i++) {
        if (people[i].id == id) mus[i] = rivalMu;
      }
    }

    // ── نمونه‌های تصادفیِ ثابت (برای مقایسه‌ی منصفانه‌ی سناریوها) ──
    var seed = 17;
    for (final st in steps) {
      seed = (seed * 31 + st.id) & 0x7fffffff;
    }
    final rnd = math.Random(seed);
    final z = Float64List(_sims * p * h);
    for (var i = 0; i < z.length; i++) {
      z[i] = _normal(rnd);
    }

    List<List<double>> distMe = <List<double>>[];
    List<double> firstP = <double>[], aboveMe = <double>[];

    void run(List<double> mu, {int sims = _sims}) {
      final dist = List<List<double>>.generate(h + 1, (_) => List<double>.filled(p, 0));
      final first = List<double>.filled(p, 0);
      final above = List<double>.filled(p, 0);
      final sums = List<double>.filled(p, 0);
      final avgs = List<double>.filled(p, 0);
      for (var s = 0; s < sims; s++) {
        for (var i = 0; i < p; i++) {
          sums[i] = 0;
        }
        for (var k = 1; k <= h; k++) {
          for (var i = 0; i < p; i++) {
            final x = (mu[i] + people[i].sigma * z[(s * p + i) * h + (k - 1)]).clamp(0.0, 20.0).toDouble();
            sums[i] += x;
            avgs[i] = (people[i].avg * people[i].n + sums[i]) / (people[i].n + k);
          }
          var rank = 1;
          for (var i = 1; i < p; i++) {
            if (avgs[i] > avgs[0]) rank++;
          }
          dist[k][rank - 1] += 1;
          if (k == h) {
            var best = 0;
            for (var i = 1; i < p; i++) {
              if (avgs[i] > avgs[best]) best = i;
              if (avgs[i] > avgs[0]) above[i] += 1;
            }
            first[best] += 1;
          }
        }
      }
      for (var k = 1; k <= h; k++) {
        for (var r = 0; r < p; r++) {
          dist[k][r] /= sims;
        }
      }
      for (var i = 0; i < p; i++) {
        first[i] /= sims;
        above[i] /= sims;
      }
      distMe = dist;
      firstP = first;
      aboveMe = above;
    }

    run(mus);

    // رتبه‌ی الان از روی میانگین‌ها
    var rankNow = 1;
    for (var i = 1; i < p; i++) {
      if (people[i].avg > people[0].avg) rankNow++;
    }
    distMe[0] = List<double>.generate(p, (r) => r == rankNow - 1 ? 1.0 : 0.0);
    for (var i = 0; i < p; i++) {
      people[i].pFirst = firstP[i];
      people[i].pAboveMe = aboveMe[i];
    }
    final pFirst = firstP[0];
    var pDrop = 0.0, pRise = 0.0;
    for (var r = 0; r < p; r++) {
      if (r + 1 > rankNow) pDrop += distMe[h][r];
      if (r + 1 < rankNow) pRise += distMe[h][r];
    }

    // ── خطِ پیش‌بینی ──
    final fcMean = <List<double>>[];
    final fcSd = <List<double>>[];
    for (var i = 0; i < p; i++) {
      final m = <double>[people[i].avg];
      final sd = <double>[0.0];
      for (var k = 1; k <= h; k++) {
        final n = people[i].n;
        m.add((people[i].avg * n + mus[i] * k) / (n + k));
        sd.add(people[i].sigma * math.sqrt(k) / (n + k));
      }
      fcMean.add(m);
      fcSd.add(sd);
    }

    // ── تاریخ‌ها ──
    final dates = <DateTime>[for (final st in steps) st.at];
    final labels = <String>[for (final st in steps) st.courseName];
    var gap = const Duration(days: 12);
    if (dates.length >= 2) {
      final span = dates.last.difference(dates.first);
      gap = Duration(milliseconds: (span.inMilliseconds / (dates.length - 1)).round().clamp(3 * 86400000, 40 * 86400000).toInt());
    }
    final now = DateTime.now();
    final startFrom = dates.last.isAfter(now) ? dates.last : now;
    final future = <DateTime>[for (var k = 1; k <= h; k++) startFrom.add(gap * k)];

    // ── حساسیت: +۱ نمره در هر درس ──
    final sens = <MapEntry<String, double>>[];
    final myCourses = people[0].id == RivalryCalc.me ? rep.byId[RivalryCalc.me]?.courses : null;
    if (myCourses != null && myCourses.isNotEmpty) {
      final totalN = myCourses.values.fold<int>(0, (a, b) => a + b.n);
      if (totalN > 0) {
        run(mus, sims: 700);
        final base = firstP[0];
        for (final c in myCourses.values) {
          final f = c.n / totalN;
          final m2 = List<double>.from(mus);
          m2[0] = (m2[0] + f).clamp(0.0, 20.0).toDouble();
          run(m2, sims: 700);
          sens.add(MapEntry(c.name, (firstP[0] - base) * 100));
        }
        sens.sort((a, b) => b.value.compareTo(a.value));
        run(mus); // برگرداندنِ حالتِ اصلی
        for (var i = 0; i < p; i++) {
          people[i].pFirst = firstP[i];
          people[i].pAboveMe = aboveMe[i];
        }
      }
    }

    // ── وابستگی به یک درس (در برابر رقیبِ اصلی یا نزدیک‌ترین) ──
    String? leadCourse;
    var leadShare = 0.0;
    final rid = rep.mainRivalId ?? rep.threatId;
    final meI = rep.byId[RivalryCalc.me];
    final rI = rid == null ? null : rep.byId[rid];
    if (meI != null && rI != null) {
      var pos = 0.0, top = 0.0;
      String? topName;
      for (final c in meI.courses.values) {
        final rc = rI.courses[c.courseId];
        if (rc == null) continue;
        final d = c.avg - rc.avg;
        if (d > 0) {
          pos += d;
          if (d > top) {
            top = d;
            topName = c.name;
          }
        }
      }
      if (pos > 0) {
        leadShare = top / pos;
        leadCourse = topName;
      }
    }

    return WrResult(
      horizon: h,
      people: people,
      pastDates: dates,
      pastLabels: labels,
      futureDates: future,
      fcMean: fcMean,
      fcSd: fcSd,
      rankPast: rep.rankSeries,
      rankDist: distMe,
      rankNow: rankNow,
      pFirst: pFirst,
      pDrop: pDrop,
      pRise: pRise,
      sensitivity: sens,
      leadCourse: leadCourse,
      leadShare: leadShare,
      mainRivalId: rep.mainRivalId,
      threatId: rep.threatId,
      lowData: steps.length < 4,
    );
  }

  /// نبردِ درس‌به‌درس با یک رقیب
  static List<WrDuel> duels(IntelReport rep, int rivalId) {
    final me = rep.byId[RivalryCalc.me];
    final r = rep.byId[rivalId];
    if (me == null || r == null) return <WrDuel>[];
    final out = <WrDuel>[];
    for (final c in me.courses.values) {
      final rc = r.courses[c.courseId];
      if (rc != null) out.add(WrDuel(c.name, c.avg, rc.avg));
    }
    out.sort((a, b) => b.diff.compareTo(a.diff));
    return out;
  }
}
