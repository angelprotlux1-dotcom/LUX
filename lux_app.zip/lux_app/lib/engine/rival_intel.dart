import 'dart:math' as math;
import 'rivalry.dart';

/// موتورِ تحلیلِ رقابت — خالص و بدون UI.
/// همه‌چیز از نمره‌های ثبت‌شده درمی‌آید؛ هیچ‌چیز حدسِ بی‌پشتوانه نیست و وقتی داده کم باشد، می‌گوید کم است.

class IntelPerson {
  final int id;
  final String name;
  final int colorIdx;
  const IntelPerson(this.id, this.name, this.colorIdx);
  bool get isMe => id == RivalryCalc.me;
}

class UpcomingExam {
  final int courseId;
  final String title;
  final DateTime at;
  const UpcomingExam(this.courseId, this.title, this.at);
}

/// آمارِ یک نفر در یک درس
class CourseStat {
  final int courseId;
  final String name;
  final double avg; // میانگینِ درس (با اثرِ مثبت و منفی)
  final int n; // تعدادِ امتحانِ دارای نمره
  final double? last;
  final double best;
  final double worst;
  final double? std;
  final double? earlier; // میانگینِ امتحان‌های قدیمی‌تر
  final double? recent; // میانگینِ امتحان‌های اخیر

  const CourseStat({
    required this.courseId,
    required this.name,
    required this.avg,
    required this.n,
    required this.last,
    required this.best,
    required this.worst,
    required this.std,
    required this.earlier,
    required this.recent,
  });

  double? get delta => (earlier == null || recent == null) ? null : recent! - earlier!;

  /// rise | fall | flat | unknown
  String get state {
    final d = delta;
    if (d == null) return 'unknown';
    if (d >= 1.0) return 'rise';
    if (d <= -1.0) return 'fall';
    return 'flat';
  }
}

/// آمارِ کلیِ یک نفر
class PersonIntel {
  final IntelPerson who;
  final double? overall;
  final int n;
  final double? momentum; // اخیر − قدیمی (روی مقیاس ۲۰)
  final double? std;
  final double? firstHalf;
  final double? secondHalf;
  final Map<int, CourseStat> courses;
  final List<double?> series; // سطحِ کلی پس از هر امتحان
  final List<String> tags; // سبکِ تحصیلی (از روی داده)

  const PersonIntel({
    required this.who,
    required this.overall,
    required this.n,
    required this.momentum,
    required this.std,
    required this.firstHalf,
    required this.secondHalf,
    required this.courses,
    required this.series,
    required this.tags,
  });

  bool isWeak(CourseStat c) {
    final o = overall;
    if (c.avg < 12) return true;
    return o != null && c.avg <= o - 1.5;
  }

  bool isStrong(CourseStat c) {
    final o = overall;
    if (c.avg >= 18.5) return true;
    return o != null && c.avg >= o + 1.5;
  }
}

class RankEntry {
  final int personId;
  final double avg;
  const RankEntry(this.personId, this.avg);
}

/// رتبه‌بندیِ یک درس
class CourseRank {
  final int courseId;
  final String name;
  final double coef;
  final List<RankEntry> order; // نزولی
  final int myRank; // ۱ بر پایه؛ ۰ = من نمره ندارم
  final int? aboveId; // نفرِ بالاترِ من (رقیبِ مستقیم)
  final int? belowId; // نفرِ پایین‌ترِ من (تهدید)
  final UpcomingExam? next;

  const CourseRank({
    required this.courseId,
    required this.name,
    required this.coef,
    required this.order,
    required this.myRank,
    required this.aboveId,
    required this.belowId,
    required this.next,
  });

  double? avgOf(int id) {
    for (final e in order) {
      if (e.personId == id) return e.avg;
    }
    return null;
  }
}

/// یک پیشنهادِ عملی («الان چه کنم»)
class IntelAction {
  /// urgent | overtake | defend
  final String kind;
  final int courseId;
  final String courseName;
  final double score;
  final int? targetId;
  final double? gap; // فاصله با هدف (نمره)
  final double? needScore; // نمره‌ی لازم در امتحانِ بعدی برای جلوزدن (از ۲۰)
  final double? delta; // روندِ خودم در درس
  final double coef;
  final UpcomingExam? next;
  const IntelAction({
    required this.kind,
    required this.courseId,
    required this.courseName,
    required this.score,
    this.targetId,
    this.gap,
    this.needScore,
    this.delta,
    required this.coef,
    this.next,
  });
}

/// نشانه‌ای از یک نفر در یک درس
class CourseFlag {
  final int personId;
  final int courseId;
  final String courseName;
  final double avg;
  final double? delta;
  final double? earlier;
  final double? recent;
  const CourseFlag(this.personId, this.courseId, this.courseName, this.avg, this.delta, this.earlier, this.recent);
}

class IntelReport {
  final List<PersonIntel> people; // اولی «من»
  final Map<int, PersonIntel> byId;
  final List<CourseRank> courseRanks;
  final List<IntelAction> actions;
  final int? mainRivalId; // نزدیک‌ترین نفرِ بالای من (یا اگر اولم، نزدیک‌ترین نفرِ زیرم)
  final int? threatId; // سریع‌ترین در حالِ نزدیک‌شدن
  final int myOverallRank; // ۰ = نامشخص
  final List<int?> rankSeries; // رتبه‌ی من پس از هر امتحان
  final List<int> rankTotals;
  final List<CourseFlag> myWeak;
  final List<CourseFlag> myFalling;
  final List<CourseFlag> myBecomingWeak;
  final List<CourseFlag> rivalsWeak;
  final List<CourseFlag> rivalsComeback;
  final List<CourseFlag> rivalsDeclining;
  final List<CourseRank> secondPlaces;
  final List<CourseRank> firstPlaces;
  final List<RivalExam> steps; // امتحان‌های غیرکنفرانس به ترتیب

  const IntelReport({
    required this.people,
    required this.byId,
    required this.courseRanks,
    required this.actions,
    required this.mainRivalId,
    required this.threatId,
    required this.myOverallRank,
    required this.rankSeries,
    required this.rankTotals,
    required this.myWeak,
    required this.myFalling,
    required this.myBecomingWeak,
    required this.rivalsWeak,
    required this.rivalsComeback,
    required this.rivalsDeclining,
    required this.secondPlaces,
    required this.firstPlaces,
    required this.steps,
  });

  PersonIntel get me => people.first;
}

class RivalIntel {
  RivalIntel._();

  static const Map<String, String> tagNotes = <String, String>{
    'ثابت و قابل‌اعتماد': 'نمره‌هایش کم‌نوسان است؛ کم‌تر غافلگیر می‌کند.',
    'پرنوسان': 'نمره‌هایش بالا و پایین زیاد دارد؛ روز خوب و روز بدش فرق می‌کند.',
    'در حال اوج‌گرفتن': 'امتحان‌های اخیرش از قبلی‌ها بهتر است.',
    'در حال افت': 'امتحان‌های اخیرش از قبلی‌ها ضعیف‌تر است.',
    'سلیقه‌ای': 'در بعضی درس‌ها خیلی قوی و در بعضی ضعیف است.',
    'همه‌فن‌حریف': 'تقریباً همه‌ی درس‌هایش هم‌سطح و بالاست.',
    'دیرگرم‌کن': 'نیمه‌ی دوم امتحان‌هایش به‌وضوح از نیمه‌ی اول بهتر است.',
    'شروع‌قوی': 'نیمه‌ی اول امتحان‌هایش از نیمه‌ی دوم بهتر بوده است.',
    'داده‌ی کم': 'نمره‌ی کافی ثبت نشده؛ تحلیلش تقریبی است.',
  };

  static double _mean(Iterable<double> v) {
    var s = 0.0;
    var n = 0;
    for (final x in v) {
      s += x;
      n++;
    }
    return n == 0 ? 0.0 : s / n;
  }

  static double? _std(List<double> v) {
    if (v.length < 2) return null;
    final m = _mean(v);
    var s = 0.0;
    for (final x in v) {
      s += (x - m) * (x - m);
    }
    return math.sqrt(s / (v.length - 1));
  }

  /// قدیمی‌تر و اخیر؛ با ≥۲ نمره
  static List<double>? _split(List<double> v, int recentN) {
    if (v.length < 2) return null;
    if (v.length == 2) return <double>[v[0], v[1]];
    final r = math.min(recentN, v.length - 1);
    return <double>[_mean(v.sublist(0, v.length - r)), _mean(v.sublist(v.length - r))];
  }

  static List<double> _values(List<RivalExam> exams, int person) {
    final out = <double>[];
    for (final e in exams) {
      if (e.isConference) continue;
      final v = e.norm(person);
      if (v != null) out.add(v);
    }
    return out;
  }

  static CourseStat? _courseStat(
    List<RivalExam> exams,
    int cid,
    String name,
    int person,
    Map<int, Map<int, double>> behavior,
  ) {
    final list = <RivalExam>[for (final e in exams) if (e.courseId == cid) e];
    final avg = RivalryCalc.courseAverage(list, cid, person, behavior: behavior);
    if (avg == null) return null;
    final vals = _values(list, person);
    final sp = _split(vals, 2);
    return CourseStat(
      courseId: cid,
      name: name,
      avg: avg,
      n: vals.length,
      last: vals.isEmpty ? null : vals.last,
      best: vals.isEmpty ? avg : vals.reduce(math.max),
      worst: vals.isEmpty ? avg : vals.reduce(math.min),
      std: _std(vals),
      earlier: sp == null ? null : sp[0],
      recent: sp == null ? null : sp[1],
    );
  }

  static PersonIntel _person(
    IntelPerson who,
    List<RivalExam> exams,
    Map<int, String> courseNames,
    Map<int, double> coef,
    Map<int, Map<int, double>> behavior,
  ) {
    final id = who.id;
    final courses = <int, CourseStat>{};
    courseNames.forEach((cid, name) {
      final s = _courseStat(exams, cid, name, id, behavior);
      if (s != null) courses[cid] = s;
    });
    final all = _values(exams, id);
    final sp = all.length >= 5 ? _split(all, 3) : _split(all, 2);
    final momentum = sp == null ? null : sp[1] - sp[0];
    double? first, second;
    if (all.length >= 4) {
      final h = all.length ~/ 2;
      first = _mean(all.sublist(0, h));
      second = _mean(all.sublist(h));
    }
    final overall = RivalryCalc.overall(exams, id, coef, behavior: behavior);
    final series = RivalryCalc.overallSeries(exams, id, coef, behavior: behavior);
    final std = _std(all);

    // سبکِ تحصیلی از روی داده
    final tags = <String>[];
    if (all.length < 3) {
      tags.add('داده‌ی کم');
    } else {
      if (std != null && std <= 1.3) tags.add('ثابت و قابل‌اعتماد');
      if (std != null && std >= 3.0) tags.add('پرنوسان');
      if (momentum != null && momentum >= 1.0) tags.add('در حال اوج‌گرفتن');
      if (momentum != null && momentum <= -1.0) tags.add('در حال افت');
      if (courses.length >= 3) {
        final avgs = [for (final c in courses.values) c.avg];
        final spread = avgs.reduce(math.max) - avgs.reduce(math.min);
        if (spread >= 5) tags.add('سلیقه‌ای');
        if (spread <= 2 && overall != null && overall >= 16) tags.add('همه‌فن‌حریف');
      }
      if (first != null && second != null) {
        if (second - first >= 1.5) tags.add('دیرگرم‌کن');
        if (first - second >= 1.5) tags.add('شروع‌قوی');
      }
    }
    return PersonIntel(
      who: who,
      overall: overall,
      n: all.length,
      momentum: momentum,
      std: std,
      firstHalf: first,
      secondHalf: second,
      courses: courses,
      series: series,
      tags: tags.take(3).toList(),
    );
  }

  /// [exams] باید قبلاً با سیاستِ «نمره‌ی ثبت‌نشده» اصلاح شده باشد.
  static IntelReport analyze({
    required List<RivalExam> exams,
    required Map<int, double> coef,
    required Map<int, Map<int, double>> behavior,
    required List<IntelPerson> rivals,
    Map<int, UpcomingExam> upcoming = const <int, UpcomingExam>{},
    DateTime? now,
  }) {
    final clock = now ?? DateTime.now();
    final meP = const IntelPerson(RivalryCalc.me, 'من', 0);
    final everyone = <IntelPerson>[meP, ...rivals];

    final courseNames = <int, String>{};
    for (final e in exams) {
      courseNames.putIfAbsent(e.courseId, () => e.courseName);
    }
    final steps = <RivalExam>[for (final e in exams) if (!e.isConference) e];

    final people = <PersonIntel>[for (final p in everyone) _person(p, exams, courseNames, coef, behavior)];
    final byId = <int, PersonIntel>{for (final p in people) p.who.id: p};
    final me = people.first;

    // ── رتبه‌ی هر درس ──
    final ranks = <CourseRank>[];
    courseNames.forEach((cid, name) {
      final order = <RankEntry>[
        for (final p in people)
          if (p.courses[cid] != null) RankEntry(p.who.id, p.courses[cid]!.avg),
      ]..sort((a, b) => b.avg.compareTo(a.avg));
      var my = 0;
      for (var i = 0; i < order.length; i++) {
        if (order[i].personId == RivalryCalc.me) my = i + 1;
      }
      ranks.add(CourseRank(
        courseId: cid,
        name: name,
        coef: coef[cid] ?? 1.0,
        order: order,
        myRank: my,
        aboveId: my > 1 ? order[my - 2].personId : null,
        belowId: (my > 0 && my < order.length) ? order[my].personId : null,
        next: upcoming[cid],
      ));
    });

    // ── رتبه‌ی کلی و مسیرِ رتبه ──
    final ranked = [for (final p in people) if (p.overall != null) p]..sort((a, b) => b.overall!.compareTo(a.overall!));
    var myRank = 0;
    for (var i = 0; i < ranked.length; i++) {
      if (ranked[i].who.isMe) myRank = i + 1;
    }
    int? mainRival;
    if (myRank > 1) {
      mainRival = ranked[myRank - 2].who.id;
    } else if (myRank == 1 && ranked.length > 1) {
      mainRival = ranked[1].who.id;
    }
    // تهدید: نزدیک (تا ۲ نمره عقب‌تر یا جلوتر) و با بیشترین شتابِ مثبت
    int? threat;
    double bestMomentum = 0.8;
    final myOverall = me.overall;
    if (myOverall != null) {
      for (final p in people) {
        if (p.who.isMe || p.overall == null || p.momentum == null) continue;
        if ((p.overall! - myOverall).abs() <= 2.0 && p.momentum! > bestMomentum) {
          bestMomentum = p.momentum!;
          threat = p.who.id;
        }
      }
    }

    final rankSeries = <int?>[];
    final rankTotals = <int>[];
    for (var i = 1; i <= exams.length; i++) {
      if (exams[i - 1].isConference) continue;
      final vals = <MapEntry<int, double>>[];
      for (final p in people) {
        final v = RivalryCalc.overallUpTo(exams, i, p.who.id, coef, behavior: behavior);
        if (v != null) vals.add(MapEntry(p.who.id, v));
      }
      vals.sort((a, b) => b.value.compareTo(a.value));
      final idx = vals.indexWhere((e) => e.key == RivalryCalc.me);
      rankSeries.add(idx < 0 ? null : idx + 1);
      rankTotals.add(vals.length);
    }

    // ── نشانه‌ها ──
    final myWeak = <CourseFlag>[];
    final myFalling = <CourseFlag>[];
    final myBecoming = <CourseFlag>[];
    final rivalsWeak = <CourseFlag>[];
    final comeback = <CourseFlag>[];
    final declining = <CourseFlag>[];
    for (final p in people) {
      for (final c in p.courses.values) {
        final f = CourseFlag(p.who.id, c.courseId, c.name, c.avg, c.delta, c.earlier, c.recent);
        final weak = p.isWeak(c);
        final d = c.delta;
        if (p.who.isMe) {
          if (weak) myWeak.add(f);
          if (d != null && d <= -1.0) myFalling.add(f);
          if (!weak && d != null && d <= -0.7 && (c.recent ?? c.avg) <= 14.5) myBecoming.add(f);
        } else {
          if (weak) rivalsWeak.add(f);
          final o = p.overall;
          final wasWeak = c.earlier != null && (c.earlier! < 14 || (o != null && c.earlier! <= o - 1.0));
          if (d != null && d >= 1.5 && wasWeak) comeback.add(f);
          if (d != null && d <= -1.2 && c.n >= 3) declining.add(f);
        }
      }
    }
    myWeak.sort((a, b) => a.avg.compareTo(b.avg));
    rivalsWeak.sort((a, b) => a.avg.compareTo(b.avg));
    comeback.sort((a, b) => b.delta!.compareTo(a.delta!));
    declining.sort((a, b) => a.delta!.compareTo(b.delta!));

    // ── پیشنهادهای عملی ──
    final cands = <IntelAction>[];
    for (final r in ranks) {
      final mine = me.courses[r.courseId];
      if (mine == null) continue;
      final days = r.next == null ? 999 : r.next!.at.difference(clock).inHours / 24.0;
      final bonus = (r.next != null && days >= 0 && days <= 14) ? 1.5 : 0.0;
      final d = mine.delta;
      final weak = me.isWeak(mine);
      if (weak || (d != null && d <= -1.0)) {
        cands.add(IntelAction(
          kind: 'urgent',
          courseId: r.courseId,
          courseName: r.name,
          score: r.coef * (1.0 + (d != null && d < 0 ? -d * 0.8 : 0.0) + (weak ? 1.5 : 0.0)) + bonus,
          delta: d,
          coef: r.coef,
          next: r.next,
        ));
      }
      if (r.aboveId != null) {
        final hisAvg = r.avgOf(r.aboveId!)!;
        final gap = hisAvg - mine.avg;
        // نمره‌ی لازم در امتحانِ بعدی: فرض می‌کنیم او هم همان میانگینش را بگیرد
        var sumW = 0.0;
        var cnt = 0;
        for (final e in exams) {
          if (e.courseId == r.courseId && !e.isConference && e.mine != null) {
            sumW += e.weight <= 0 ? 1.0 : e.weight;
            cnt++;
          }
        }
        if (sumW <= 0) sumW = 1.0;
        final w = cnt == 0 ? 1.0 : sumW / cnt;
        final need = (hisAvg * (sumW + w) - sumW * mine.avg) / w;
        cands.add(IntelAction(
          kind: 'overtake',
          courseId: r.courseId,
          courseName: r.name,
          score: r.coef * (1.2 / (1.0 + gap)) * (r.myRank == 2 ? 1.5 : 1.0) + bonus * 0.5,
          targetId: r.aboveId,
          gap: gap,
          needScore: need,
          delta: d,
          coef: r.coef,
          next: r.next,
        ));
      }
      if (r.belowId != null) {
        final below = byId[r.belowId!];
        final bc = below?.courses[r.courseId];
        final bd = bc?.delta;
        final gapDown = mine.avg - r.avgOf(r.belowId!)!;
        if (bd != null && bd >= 1.0 && gapDown <= 2.0) {
          cands.add(IntelAction(
            kind: 'defend',
            courseId: r.courseId,
            courseName: r.name,
            score: r.coef * (1.0 / (1.0 + gapDown)) * 1.3 + bonus * 0.3,
            targetId: r.belowId,
            gap: gapDown,
            delta: bd,
            coef: r.coef,
            next: r.next,
          ));
        }
      }
    }
    cands.sort((a, b) => b.score.compareTo(a.score));

    return IntelReport(
      people: people,
      byId: byId,
      courseRanks: ranks,
      actions: cands.take(6).toList(),
      mainRivalId: mainRival,
      threatId: threat,
      myOverallRank: myRank,
      rankSeries: rankSeries,
      rankTotals: rankTotals,
      myWeak: myWeak,
      myFalling: myFalling,
      myBecomingWeak: myBecoming,
      rivalsWeak: rivalsWeak,
      rivalsComeback: comeback,
      rivalsDeclining: declining,
      secondPlaces: [for (final r in ranks) if (r.myRank == 2) r],
      firstPlaces: [for (final r in ranks) if (r.myRank == 1 && r.order.length > 1) r],
      steps: steps,
    );
  }
}
