/// محاسبات رقابت — خالص و بدون وابستگی به UI.
///
/// همه‌ی نمره‌ها روی مقیاس ۲۰ برده می‌شوند تا امتحان‌هایی با بیشینه‌ی متفاوت قابل مقایسه باشند.
/// «من» با شناسه‌ی [RivalryCalc.me] (صفر) مشخص می‌شود؛ رقبا شناسه‌ی مثبتِ پایگاه‌داده را دارند.
class RivalExam {
  final int id;
  final int courseId;
  final String courseName;
  final String title;
  final DateTime at;
  final double max;
  final double weight;

  /// نمره‌ی خودِ کاربر (خام)؛ null اگر ثبت نشده
  final double? mine;

  /// رقیب → نمره‌ی خام (فقط رقبایی که نمره‌شان ثبت شده)
  final Map<int, double> rivals;

  /// آیتمِ «کنفرانس» (نه امتحان)
  final bool isConference;

  const RivalExam({
    required this.id,
    required this.courseId,
    required this.courseName,
    required this.title,
    required this.at,
    required this.max,
    required this.weight,
    required this.mine,
    required this.rivals,
    this.isConference = false,
  });

  double? raw(int person) => person == RivalryCalc.me ? mine : rivals[person];

  /// نمره روی مقیاس ۲۰ یا null
  double? norm(int person) {
    final r = raw(person);
    if (r == null || max <= 0) return null;
    return r / max * 20;
  }
}

class RivalryCalc {
  RivalryCalc._();

  static const int me = 0;

  /// فقط امتحان‌هایی که همه‌ی [persons] در آن نمره دارند.
  static List<RivalExam> common(List<RivalExam> exams, Iterable<int> persons) {
    final ps = persons.toList();
    return <RivalExam>[
      for (final e in exams)
        if (ps.every((p) => e.norm(p) != null)) e,
    ];
  }

  static double _w(double w) => w <= 0 ? 1.0 : w;

  static double? _weighted(Iterable<RivalExam> exams, int person) {
    var s = 0.0, w = 0.0;
    for (final e in exams) {
      final v = e.norm(person);
      if (v == null) continue;
      final wt = _w(e.weight);
      s += v * wt;
      w += wt;
    }
    return w == 0 ? null : s / w;
  }

  /// اثرِ مثبت و منفی: {شخص: {درس: اثر روی مقیاس ۲۰}}. فقط وقتی اعمال می‌شود که آن نفر در آن درس نمره دارد.
  static double? _courseAvg(Iterable<RivalExam> list, int courseId, int person, Map<int, Map<int, double>>? behavior) {
    final a = _weighted(list, person);
    if (a == null) return null;
    final v = a + (behavior?[person]?[courseId] ?? 0);
    return v < 0 ? 0.0 : (v > 20 ? 20.0 : v);
  }

  /// میانگینِ وزنی (وزنِ امتحان) یک نفر در یک درس (با اثرِ مثبت و منفی)
  static double? courseAverage(List<RivalExam> exams, int courseId, int person, {Map<int, Map<int, double>>? behavior}) =>
      _courseAvg(exams.where((e) => e.courseId == courseId), courseId, person, behavior);

  /// نمره‌ی هر امتحانِ یک درس برای یک نفر (null = ثبت نشده)
  static List<double?> courseSeries(List<RivalExam> examsOfCourse, int person) =>
      <double?>[for (final e in examsOfCourse) e.norm(person)];

  /// «سطح کلی» با اولین [count] امتحان: میانگینِ هر درس، سپس میانگینِ ضریب‌دارِ درس‌ها
  /// (همان منطقِ معدلِ برنامه). [coef] ضریب هر درس است؛ اگر نبود ۱.
  static double? overallUpTo(
    List<RivalExam> exams,
    int count,
    int person,
    Map<int, double> coef, {
    Map<int, Map<int, double>>? behavior,
  }) {
    final by = <int, List<RivalExam>>{};
    for (var i = 0; i < count && i < exams.length; i++) {
      by.putIfAbsent(exams[i].courseId, () => <RivalExam>[]).add(exams[i]);
    }
    var s = 0.0, w = 0.0;
    by.forEach((cid, list) {
      final a = _courseAvg(list, cid, person, behavior);
      if (a == null) return;
      final c = _w(coef[cid] ?? 1);
      s += a * c;
      w += c;
    });
    return w == 0 ? null : s / w;
  }

  static double? overall(List<RivalExam> exams, int person, Map<int, double> coef, {Map<int, Map<int, double>>? behavior}) =>
      overallUpTo(exams, exams.length, person, coef, behavior: behavior);

  /// سطح کلی پس از هر امتحان (قبل از اولین نمره‌ی آن نفر null است).
  static List<double?> overallSeries(List<RivalExam> exams, int person, Map<int, double> coef, {Map<int, Map<int, double>>? behavior}) =>
      <double?>[
        // کنفرانس امتحان نیست؛ در میانگین می‌آید ولی برای خودش «گام» نمی‌سازد.
        for (var i = 1; i <= exams.length; i++)
          if (!exams[i - 1].isConference) overallUpTo(exams, i, person, coef, behavior: behavior),
      ];

  /// چند امتحان برای این نفر نمره دارد
  static int count(List<RivalExam> exams, int person) => exams.where((e) => !e.isConference && e.norm(person) != null).length;

  // ───────── نمره‌ی ثبت‌نشده: خودِ کاربر تعیین می‌کند ─────────

  static const String missSkip = 'skip';
  static const String missAvg = 'avg';
  static const String missZero = 'zero';

  /// برای رقیبی که در امتحانی نمره ندارد (و من نمره دارم) طبقِ سیاستِ انتخابیِ کاربر عمل می‌کند:
  /// skip = نادیده (پیش‌فرض)، avg = میانگینِ خودِ او در همان درس، zero = صفر.
  /// [policy]: شناسه‌ی رقیب ← سیاست. رقیبِ بی‌سیاست مثل skip است. هرگز بی‌خبرِ کاربر صفر گذاشته نمی‌شود.
  static List<RivalExam> fillMissing(List<RivalExam> exams, Map<int, String> policy) {
    if (policy.values.every((p) => p != missAvg && p != missZero)) return exams;
    final avg = <int, Map<int, double>>{};
    for (final en in policy.entries) {
      if (en.value != missAvg) continue;
      final by = <int, List<RivalExam>>{};
      for (final e in exams) {
        if (!e.isConference && e.norm(en.key) != null) by.putIfAbsent(e.courseId, () => <RivalExam>[]).add(e);
      }
      for (final c in by.entries) {
        final a = _weighted(c.value, en.key);
        if (a != null) (avg[en.key] ??= <int, double>{})[c.key] = a;
      }
    }
    final out = <RivalExam>[];
    for (final e in exams) {
      if (e.isConference || e.mine == null) {
        out.add(e);
        continue;
      }
      Map<int, double>? extra;
      for (final en in policy.entries) {
        if (e.rivals.containsKey(en.key)) continue;
        double? v;
        if (en.value == missZero) {
          v = 0.0;
        } else if (en.value == missAvg) {
          final a = avg[en.key]?[e.courseId];
          if (a != null) v = a / 20 * e.max;
        }
        if (v != null) {
          extra ??= <int, double>{...e.rivals};
          extra[en.key] = v;
        }
      }
      final ex = extra;
      out.add(ex == null
          ? e
          : RivalExam(
              id: e.id,
              courseId: e.courseId,
              courseName: e.courseName,
              title: e.title,
              at: e.at,
              max: e.max,
              weight: e.weight,
              mine: e.mine,
              rivals: ex,
              isConference: e.isConference,
            ));
    }
    return out;
  }
}
