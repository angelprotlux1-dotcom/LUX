import 'dart:async';
import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart' as pdfrx;
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/app_gate.dart';
import 'core/app_theme.dart';
import 'core/account.dart';
import 'core/achievements.dart';
import 'core/features.dart';
import 'core/nav.dart';
import 'services/rahgosha.dart';
import 'services/rival_watch.dart';
import 'ui/widgets/achievement_banner.dart';
import 'ui/widgets/rahgosha_mascot.dart';
import 'core/license.dart';
import 'core/theme.dart';
import 'data/reminders.dart';
import 'data/smart_repo.dart';
import 'data/database.dart';
import 'data/backup.dart';
import 'data/calendar_repo.dart';
import 'data/profile_repo.dart';
import 'services/bag_reminders.dart';
import 'services/daily_brief.dart';
import 'services/focus_timer.dart';
import 'services/lock_service.dart';
import 'services/notification_service.dart';
import 'ui/lock/lock_screen.dart';
import 'ui/onboarding/onboarding_flow.dart';
import 'ui/widgets/karimi_credit.dart';
import 'ui/widgets/splash_intro.dart';
import 'ui/widgets/welcome_back.dart';
import 'ui/shell/app_shell.dart';
import 'ui/widgets/haptic.dart';

/// به‌جای «صفحه‌ی خاکستریِ» بی‌نام‌ونشان، متنِ خطا را نشان می‌دهد تا بشود علتش را پیدا کرد.
Widget _errorView(FlutterErrorDetails d) {
  final stack = (d.stack ?? StackTrace.empty).toString().split('\n').take(12).join('\n');
  return Directionality(
    textDirection: TextDirection.ltr,
    child: ColoredBox(
      color: const Color(0xFF111111),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 44, 14, 20),
        child: Text(
          'LUX error (send a screenshot of this):\n\n${d.exceptionAsString()}\n\n$stack',
          style: const TextStyle(color: Color(0xFFFFB4AB), fontSize: 11, height: 1.35, decoration: TextDecoration.none, fontWeight: FontWeight.normal),
        ),
      ),
    ),
  );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  ErrorWidget.builder = _errorView;
  try {
    // موتورِ PDF را از همان اول آماده می‌کنیم (بی‌خطر است؛ چندبار صدا زدنش مشکلی ندارد).
    final dynamic init = pdfrx.pdfrxFlutterInitialize;
    final r = init();
    if (r is Future) await r;
  } catch (_) {}
  // چرخشِ صفحه آزاد است (از تنظیمِ «چرخش خودکار» گوشی پیروی می‌کند).
  await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await LuxDb.instance.open();
  await AppTheme.instance.load();
  Haptic.enabled = (await LuxDb.instance.kvGet('haptics') ?? '1') == '1';
  try {
    await NotificationService.instance.init();
  } catch (_) {
    // اگر نوتیف راه نیفتاد، بقیه‌ی اپ باید کار کند.
  }
  unawaited(Reminders.resyncAsks());
  unawaited(FocusTimer.instance.init());
  unawaited(SmartRepo.load().then((_) {}).catchError((_) {}));
  final onboarded = await ProfileRepo.isOnboarded();
  final licensed = await License.isValid();
  final accountOk = !Account.enforced || await Account.hasSession();
  final locked = onboarded && licensed && accountOk && await LockService.hasPin();
  runApp(LuxApp(onboarded: onboarded, locked: locked, licensed: licensed, accountOk: accountOk));
  if (onboarded && accountOk) unawaited(Account.maybePush());
  if (onboarded) {
    DailyBrief.start();
    BagReminders.start();
    unawaited(CalendarRepo.resyncAll());
    // اگر مجوز اعلان/آلارم هنوز داده نشده، بعد از بالا آمدن اپ از خود اندروید می‌پرسد.
    unawaited(NotificationService.instance.ensurePermissions().catchError((_) => (false, false)));
  }
}

class LuxApp extends StatefulWidget {
  final bool onboarded;
  final bool locked;
  final bool licensed;
  final bool accountOk;
  const LuxApp({super.key, required this.onboarded, required this.locked, this.licensed = true, this.accountOk = true});

  @override
  State<LuxApp> createState() => _LuxAppState();
}

class _LuxAppState extends State<LuxApp> with WidgetsBindingObserver {
  Timer? _nightTimer;
  late bool _onboarded = widget.onboarded;
  late bool _locked = widget.locked;
  late bool _licensed = widget.licensed;
  late bool _accountOk = widget.accountOk;
  bool _showFinale = false;
  bool _showWelcome = false;
  String _welcomeName = '';
  late bool _showSplash = widget.onboarded && widget.licensed && widget.accountOk && AppTheme.instance.splash;
  DateTime? _pausedAt;
  DateTime? _sessionStart = DateTime.now();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppTheme.instance.addListener(_onTheme);
    _scheduleNight();
    if (widget.onboarded && widget.licensed && widget.accountOk) _startFeatures();
  }

  bool _featuresStarted = false;

  /// نشان‌ها و رهگشا؛ بعد از ورود به برنامه یک‌بار راه می‌افتند.
  void _startFeatures() {
    if (_featuresStarted) return;
    _featuresStarted = true;
    Achievements.init();
    RivalWatch.init();
    if (kShowRahgosha) Rahgosha.load().then((_) => Rahgosha.maybeProactive());
  }

  /// تغییرِ تم: رنگ‌ها در جا عوض می‌شوند؛ برنامه از نو ساخته نمی‌شود و صفحه‌ی باز و جای شما حفظ می‌ماند.
  void _onTheme() {
    if (!mounted) return;
    setState(() {});
    _rebuildAll();
    _scheduleNight();
  }

  /// همه‌ی ویجت‌ها را (بدونِ از دست رفتنِ وضعیتشان) دوباره می‌سازد تا رنگ‌های تازه را بخوانند.
  void _rebuildAll() {
    void visit(Element e) {
      e.markNeedsBuild();
      e.visitChildren(visit);
    }

    WidgetsBinding.instance.rootElement?.visitChildren(visit);
  }

  /// حالتِ «شب و روز»: سرِ ساعتِ تعیین‌شده، رنگ‌ها در جا عوض می‌شوند.
  void _tryNight() {
    final t = AppTheme.instance;
    if (!mounted || t.mode != 3) return;
    t.refreshSchedule();
  }

  void _scheduleNight() {
    _nightTimer?.cancel();
    final next = AppTheme.instance.nextScheduleChange();
    if (next == null) return;
    var wait = next.difference(DateTime.now()) + const Duration(seconds: 1);
    if (wait.isNegative) wait = const Duration(seconds: 1);
    _nightTimer = Timer(wait, () {
      _tryNight();
      _scheduleNight();
    });
  }

  @override
  void didChangePlatformBrightness() {
    AppTheme.instance.systemChanged(PlatformDispatcher.instance.platformBrightness);
  }

  @override
  void dispose() {
    _nightTimer?.cancel();
    AppTheme.instance.removeListener(_onTheme);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
      // فایل داده‌ی خودکار را به‌روز نگه می‌داریم.
      unawaited(Backup.autoSave());
      if (_sessionStart != null) {
        Account.track('session', '${DateTime.now().difference(_sessionStart!).inSeconds}');
        _sessionStart = null;
      }
      unawaited(Account.flush());

    } else if (state == AppLifecycleState.resumed) {
      _sessionStart = DateTime.now();
      Account.track('app_open');
      if (_featuresStarted) {
        Achievements.init();
        if (kShowRahgosha) unawaited(Rahgosha.maybeProactive());
      }
      unawaited(Account.maybePush());
      unawaited(AppTheme.instance.refreshWallpaper());
      unawaited(FocusTimer.instance.refresh().then((_) => FocusTimer.instance.drain()));
      _tryNight();
      _scheduleNight();
      final at = _pausedAt;
      _pausedAt = null;
      if (at != null && _onboarded && DateTime.now().difference(at).inSeconds > 20) {
        LockService.hasPin().then((has) {
          if (has && mounted) setState(() => _locked = true);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppTheme.instance;
    AppGate.blocked = _showSplash || _locked || _showFinale || _showWelcome;
    return MaterialApp(
      navigatorKey: luxNavKey,
      themeAnimationDuration: Duration.zero,
      title: 'LUX',
      debugShowCheckedModeBanner: false,
      theme: LuxTheme.build(),
      locale: const Locale('fa', 'IR'),
      supportedLocales: const [Locale('fa', 'IR')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final dark = t.brightness == Brightness.dark;
        final icons = dark ? Brightness.light : Brightness.dark;
        final mq = MediaQuery.of(context);
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            systemNavigationBarColor: Colors.transparent,
            statusBarIconBrightness: icons,
            systemNavigationBarIconBrightness: icons,
          ),
          child: MediaQuery(
            data: mq.copyWith(textScaler: TextScaler.linear(mq.textScaler.scale(1.0) * t.textScale)),
            // انیمیشن ورود و قفل روی کلِ Navigator می‌نشینند تا صفحه‌های بازِ داخلی هم پوشانده شوند.
            child: Stack(
              fit: StackFit.expand,
              children: [
                Listener(
                  behavior: HitTestBehavior.translucent,
                  onPointerDown: (e) => Rahgosha.pointer.value = e.position,
                  onPointerMove: (e) => Rahgosha.pointer.value = e.position,
                  child: child ?? const SizedBox.shrink(),
                ),
                if (_onboarded && _licensed && _accountOk && !_locked && !_showSplash && !_showFinale && !_showWelcome && kShowRahgosha) const RahgoshaFab(),
                if (_onboarded && _licensed && _accountOk && !_locked && !_showSplash && !_showFinale && !_showWelcome) const AchievementBanner(),
                if (_showSplash && !_locked)
                  Positioned.fill(
                    child: SplashIntro(key: const ValueKey('splash'), onDone: () => setState(() => _showSplash = false)),
                  ),
                if (_showWelcome)
                  Positioned.fill(
                    child: WelcomeBack(key: const ValueKey('welcome'), name: _welcomeName, onDone: () => setState(() => _showWelcome = false)),
                  ),
                if (_showFinale)
                  Positioned.fill(
                    child: CreditFinale(key: const ValueKey('finale'), onDone: () => setState(() => _showFinale = false)),
                  ),
                if (_locked)
                  Positioned.fill(
                    child: LockScreen(key: const ValueKey('lock'), onUnlocked: () => setState(() => _locked = false)),
                  ),
              ],
            ),
          ),
        );
      },
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 500),
        child: (_onboarded && (!_licensed || !_accountOk))
            ? OnboardingFlow(
                key: const ValueKey('license'),
                licenseOnly: true,
                onDone: () => setState(() {
                  _licensed = true;
                  _accountOk = true;
                  _startFeatures();
                }),
              )
            : _onboarded
                ? const AppShell(key: ValueKey('shell'))
                : OnboardingFlow(
                    key: const ValueKey('onboarding'),
                    onRestored: (n) => setState(() {
                      _onboarded = true;
                      _licensed = true;
                      _accountOk = true;
                      _showWelcome = true;
                      _welcomeName = n;
                      _startFeatures();
                    }),
                    onDone: () => setState(() {
                      _onboarded = true;
                      _licensed = true;
                      _accountOk = true;
                      _showFinale = true;
                      unawaited(Account.pushSnapshot());
                      _startFeatures();
                    }),
                  ),
      ),
    );
  }
}
